SOUND = ENT

ENT.Base = "base_entity"
ENT.Type = "point"

if SERVER then

	AddCSLuaFile( "shared.lua" )
	AddCSLuaFile( "sound.lua" )

end

include( "sound.lua" )


	-- No Saves / Dupes! --


local Old_gmsaveShouldSaveEntity = gmsave.ShouldSaveEntity

function gmsave.ShouldSaveEntity( Ent, T )

	if istable( T ) and T.classname == "ultrakill_soundsystem" then 
		
		return false

	else

		return Old_gmsaveShouldSaveEntity

	end


end



function SOUND:Initialize()

	self:DrawShadow( false )

	self:SetData( UltrakillBase.GetSoundScriptData( self:GetScriptName(), true ) ) -- Setup Script Variables.

	
		-- Variables --
	

	self.InitTime = CurTime()
	self.CanDie = isnumber( self.DieTime ) and self.DieTime >= 0 or false
	self.HasParent = IsValid( self:GetParent() )

	
		-- Initialize Sound Channel --
	

	if CLIENT then

		local Audio = CreateSound( self, tostring( self.Path ) )

		self:SetAudio( Audio )

		Audio:SetSoundLevel( 0 )
		Audio:PlayEx( self.Volume, math.min( self.Pitch * 100, 255 )  )

		self:AudioUpdate()

	end

	
		-- Debugging --
	

	local TextDieTime = self.CanDie and self.DieTime or 10

	debugoverlay.EntityTextAtPosition( self:GetPos(), 1, tostring( self ) .. " " .. self:GetScriptName(), TextDieTime )

end




function SOUND:Think()

	if SERVER and self.HasParent and not IsValid( self:GetParent() ) then

		self:Remove()

	end

	if self.StopUpdating or self:IsMarkedForDeletion() then 
		
		return false 
	
	end

	-- Update Entities --

	if CLIENT then

		self:AudioUpdate() -- Update Audio Per Tick.

	end

	if SERVER and self.CanDie and CurTime() - self.InitTime > self.DieTime then

		self:Remove()

	end

	if isfunction( self.Callback ) then

    	self.Callback( self, self:GetParent() )

  	end

	self:NextThink( CurTime() )

	return true

end



function SOUND:OnRemove()

	self.StopUpdating = true

	if CLIENT and self:GetAudio() ~= nil then

		self.Audio:Stop()

	end

end



function SOUND:Draw() end -- Do not Draw this entity.



function SOUND:SetupDataTables()

	self:NetworkVar( "String", 0, "ScriptName" ) -- Network String Var.
	self:NetworkVar( "Bool", 0, "IsServer" ) -- Network Bool Var.

end



function SOUND:UpdateTransmitState() return TRANSMIT_ALWAYS end -- Always Transmit. ( Ignore Player's PVS )




	-- Functions --


function SOUND:GetAudio()

  return self.Audio

end

function SOUND:SetAudio( Audio )

  self.Audio = Audio

end



function SOUND:SetData( Data )

  self.InitData = Data 

  for Key, Val in pairs( Data or {} ) do -- Auto Allocate Variables to Table Keys.

    self[ Key ] = Val

  end

end

