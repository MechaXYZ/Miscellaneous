SOUND = ENT

if not istable( SOUND ) or SERVER then return end


  -- Localize Libaries & Functions --


local math = math
local game = game
local gui = gui

local LocalPlayer = LocalPlayer



local VolumeConVar = CreateConVar( "drg_ultrakill_sound_volume", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "SFX Volume." )



local function IsPossessing( Entity )

  return IsValid( Entity:GetNW2Entity( "DrGBasePossessing" ) )

end



  -- Update the Audio Channel
  


function SOUND:AudioUpdate()
 
  if self:GetAudio() == nil or self.StopUpdating then return end

  
    -- Variables --
  

  local Audio = self:GetAudio()
  local Radius = self.Radius
  local Pitch = self.Pitch
  local Volume = self.Volume * VolumeConVar:GetFloat()

  
    -- Effects --
  

  local Timescale = self.TimeScale and game.GetTimeScale() or 1 -- Timescale Variable.

  
    -- Pitch --
  

  Audio:ChangePitch( math.min( ( Pitch * Timescale ) * 100, 255 ) )

  
    -- Mute when Unfocused --
  

  Volume = system.HasFocus() and Volume or 0

  
    -- Volume --
  

  Audio:ChangeVolume( Volume )

end



