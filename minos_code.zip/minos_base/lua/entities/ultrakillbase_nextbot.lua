if not DrGBase or not UltrakillBase then return end -- return if DrGBase isn't installed
ENT.Base = "drgbase_nextbot" -- DO NOT TOUCH (obviously)

-- Misc --

ENT.PrintName = "Ultrakill_Base"
ENT.Category = "ULTRAKILL"
ENT.Models = { "" }
ENT.ModelScale = 1
ENT.CollisionBounds = Vector( 16, 16, 54 )
ENT.BloodColor = DONT_BLEED

ENT.CanBleed = true

ENT.Phases = 1 -- Phase Segments -- Default is 1 which means no phase change.
ENT.Phase = 1

ENT.MinPhysDamage = 0

ENT.IsUltrakillNextbot = true

ENT.SightFOV = 90

ENT.WeightClass = "Light"
ENT.WeaknessTable = { } -- Key = Type, Value = Percentage.

-- AI --

ENT.BehaviourType = AI_BEHAV_CUSTOM

ENT.BehaviourStrafe = false
ENT.BehaviourStrafeUpdate = 2
ENT.BehaviourStrafeDirection = 1

ENT.AISight = true

-- Aiming --

ENT.PitchOrientation = { nil, nil, nil }
ENT.PitchBone = ""
ENT.PitchFollow = false

-- Possession --

ENT.ParticleTable = {}

ENT.ContinuousAttacksTable = {}

ENT.DynamLights = {}

ENT.EventTable = {}
ENT.AttackTable = {}

ENT.PreviouslyKilled = {}

ENT.HitGroupMultipliers = {

  [ HITGROUP_HEAD ] = { 2, "Ultrakill_HeadBreak" },
  [ HITGROUP_RIGHTARM ] = { 1.25, "Ultrakill_LimbBreak" },
  [ HITGROUP_LEFTARM ] = { 1.25, "Ultrakill_LimbBreak" },
  [ HITGROUP_RIGHTLEG ] = { 1.25, "Ultrakill_LimbBreak" },
  [ HITGROUP_LEFTLEG ] = { 1.25, "Ultrakill_LimbBreak" },
  [ HITGROUP_GEAR ] = { 0, "Ultrakill_Bullet_Ricochet" },

}

-- Include Files --

DrGBase.IncludeFolder( "ultrakillbase/Nextbot" )
DrGBase.IncludeFolder( "ultrakillbase/Shared" )

if SERVER then

  AddCSLuaFile()

function ENT:_BaseInitialize()

  self:DrawShadow( false )

  self:CalculateUpdateInterval()

  self:SetSpawnEffect( false )

  self.CanBleed = true

  self.UltrakillAimUpdateDelay = 0
  self.UltrakillUpdatePhaseDelay = 0
  self.UltrakillStrafeUpdateDelay = 0
  self.UltrakillContinuousAttackDelay = 0
  self.UltrakillAntiFallingDelay = 0

  for K, Seq in ipairs( self.AttackTable or {} ) do

    self:SetAttack( Seq, true )

  end

  for K, Seq in ipairs( self.IntroTable or {} ) do
    
    self:SetIntro( Seq, true )

  end

  if istable( self.EventTable ) then

    for Seq, Table in pairs( self.EventTable ) do

      if not istable( Table ) or not isstring( Seq ) then continue end

      for K, Event in ipairs( Table ) do

        self:AddAnimEvent( Seq, Event[1], Event[2] )

      end

    end

  end

  self:SetPitchFollow( self.PitchFollow )

  self:SetSandable( true )
  self:SetSand( false )

  self:SetPhase( self.Phase or 1 )
  self:SetTotalPhases( self.Phases or 1 )

  UltrakillBase.SetWeightClass( self, self.WeightClass )

  self.loco:SetGravity( UltrakillBase.GetWeightData( self ).Gravity )

  if isfunction( self.SetSurroundingBounds ) then

    if isvector( self.SurroundingBounds ) then

      self:SetSurroundingBounds( -Vector( self.SurroundingBounds.x, self.SurroundingBounds.y, 0 ), self.SurroundingBounds )

    else

      local Min, Max = self:GetCollisionBounds()

      self:SetSurroundingBounds( Min * 3, Max * 3 )
    
    end

  end

  self:InitializeFlying()
  self:InitializeAiming()

end


function ENT:_BaseThink()

  if self:GetFlying() and self:IsAIDisabled() then

    self:SetVelocity( vector_origin )

  end

  if CurTime() > self.UltrakillUpdatePhaseDelay and self:GetTotalPhases() > 1 and self:GetPhase() ~= self:GetTotalPhases() then -- Check to Update Phase every 0.01s

    self.UltrakillUpdatePhaseDelay = CurTime() + 0.01

    self:PhaseCheck()

  end

  if CurTime() > self.UltrakillStrafeUpdateDelay then

    self.UltrakillStrafeUpdateDelay = CurTime() + self.BehaviourStrafeUpdate

    local Random = math.random( 1, 2 )

    if Random == 1 then

      self.BehaviourStrafeDirection = 1

    else

      self.BehaviourStrafeDirection = -1

    end

  end

  if self:GetContinuousAttack() and self:IsAttacking() and CurTime() > self.UltrakillContinuousAttackDelay then

    self.UltrakillContinuousAttackDelay = CurTime() + 0.01

    if istable( self.ContinuousAttacksTable ) and not table.IsEmpty( self.ContinuousAttacksTable ) then

      self:Attack( self.ContinuousAttacksTable )

    end

  end

  if self:GetPitchFollow() and isnumber( self:DrG_SearchBone( self.PitchBone ) ) then

    self:ApproachPitchFollow( self.PitchBone, self.PitchOrientation, self:GetAimAngles(), self.MaxYawRate )

  elseif not self:GetPitchFollow() and isnumber( self:DrG_SearchBone( self.PitchBone ) ) then

    self:ResetPitchFollow( self.PitchBone )

  end

end


function ENT:PossessionControls( F, B, R, L )

  local Direction = self:GetPos()

  if F then

    Direction = Direction + self:GetAimVector()

  elseif B then

    Direction = Direction - self:GetAimVector()

  end

  if R then

    Direction = Direction + self:PossessorRight()

  elseif L then

    Direction = Direction - self:PossessorRight()

  end

  if Direction ~= self:GetPos() then

    if not self:GetFlying() then

      self:MoveTowards( Direction )

    else

      self:ApproachFlying( Direction )

    end

    self:PossessionFaceForward()

  else

    if self:GetFlying() then

      self:SetVelocity( vector_origin )

    end

    self:PossessionFaceForward()

  end

end


function ENT:OnChaseEnemy( Enemy )

  self:AimTowards( Enemy )

end


function ENT:OnCombineBall( CBall )

  CBall:Fire( "Explode", 0 )

  return false
  
end


function ENT:DamageMultiplier( Dmg, HitGroup )

  local Attacker = Dmg:GetAttacker()
  local Inflictor = Dmg:GetInflictor()

  UltrakillBase.SoundScript( "Ultrakill_Impact_S_03", self:GetPos() )

  if self:IsSand() then UltrakillBase.SoundScript( "Ultrakill_SandHit", self:GetPos() ) end

  if IsValid( Inflictor ) and Inflictor:GetClass() == "prop_combine_ball" then

    Dmg:ScaleDamage( 0.05 )
    Dmg:SetDamageType( DMG_BLAST )

  end

  -- HitGroup --

  local HitGroupData = self.HitGroupMultipliers[ HitGroup ] or {}

  Dmg:ScaleDamage( HitGroupData[ 1 ] or 1 )

  if isstring( HitGroupData[ 2 ] ) then

    UltrakillBase.SoundScript( HitGroupData[ 2 ], self:GetPos() )

  end

  -- Weakness --

  for K, V in pairs( self.WeaknessTable ) do

    if not isnumber( K ) or not isnumber( V ) then continue end

    if Dmg:IsDamageType( K ) and ( not Dmg:IsDamageType( DMG_DIRECT ) and V >= 1 ) then

      Dmg:ScaleDamage( V )

    end

  end

  -- ConVars --

  if IsValid( Attacker ) and Attacker:IsPlayer() then

    Dmg:ScaleDamage( UltrakillBase.ConVars.PlyDmgMult:GetFloat() * 10 )

  elseif IsValid( Attacker ) and not Attacker:IsPlayer() and not Attacker.IsUltrakillNextbot and not Attacker.IsUltrakillProjectile then

    Dmg:ScaleDamage( UltrakillBase.ConVars.TakeDmgMult:GetFloat() )

  elseif IsValid( Attacker ) and ( Attacker.IsUltrakillNextbot or Attacker.IsUltrakillProjectile ) then

    Dmg:ScaleDamage( 20 )

  end

end


function ENT:OnOtherKilled( Victim, CInfo )

  if not Victim:IsPlayer() or not IsValid( Victim ) then return end

  self.PreviouslyKilled[ Victim:EntIndex() ] = true

end


function ENT:OnNewEnemy( Enemy )

  if self.PreviouslyKilled[ Enemy:EntIndex() ] == true then

    local LineID = self.RestartVoiceLine

    if istable( self.RestartVoiceLine ) then

      LineID = self.RestartVoiceLine[ math.random( #self.RestartVoiceLine ) ]

    end

    UltrakillBase.SoundScript( LineID, self:GetPos(), self )

    self:SetCooldown( "Attack", 2 )

    self.PreviouslyKilled[ Enemy:EntIndex() ] = nil

  end

end


function ENT:OnUpdateAnimation()

  if self:IsDown() or self:IsDead() then return end

  if self:IsClimbingUp() then return self.ClimbUpAnimation, self.ClimbAnimRate * self:CalculateAnimRate( self:GetSequence() )

  elseif self:IsClimbingDown() then return self.ClimbDownAnimation, self.ClimbAnimRate * self:CalculateAnimRate( self:GetSequence() )

  elseif self:IsJumping() or self:IsLeaping() or self:IsGliding() or ( not self:IsOnGround() and self.FallingAnimation == nil ) then return self.JumpAnimation, self.JumpAnimRate * self:CalculateAnimRate( self:GetSequence() )

  elseif not self:IsOnGround() and self.FallingAnimation ~= nil then return self.FallingAnimation, self.FallingAnimRate * self:CalculateAnimRate( self:GetSequence() )

  elseif self:IsRunning() then return self.RunAnimation, self.RunAnimRate * self:CalculateAnimRate( self:GetSequence() )

  elseif self:IsMoving() then return self.WalkAnimation, self.WalkAnimRate * self:CalculateAnimRate( self:GetSequence() )

  else return self.IdleAnimation, self.IdleAnimRate * self:CalculateAnimRate( self:GetSequence() ) end

end


function ENT:OnUpdateSpeed()

  if self:IsClimbing() then return self.ClimbSpeed * self:CalculateAnimRate( self:GetSequence() )

  elseif self.UseWalkframes then return -1

  elseif self:IsRunning() then return self.RunSpeed * self:CalculateAnimRate( self:GetSequence() )

  else return self.WalkSpeed * self:CalculateAnimRate( self:GetSequence() ) end

end


function ENT:OnComputePath( FromArea, Area )

 return 0 

end


function ENT:OnComputePathStep( FromArea, Area, Height )

 return 0

end


function ENT:OnComputePathJump( FromArea, Area, Height )

 return 5

end


function ENT:OnComputePathDrop( FromArea, Area, Drop )

 return 1

end


function ENT:OnComputePathFlat( FromArea, Area )

 return 0 

end


function ENT:OnComputePathUnderwater( FromArea, Area )

 return 1

end


else


function ENT:_BaseInitialize()

  self:CalculateUpdateInterval()

end


function ENT:_BaseThink()


  self:CalculateUpdateInterval()


  if self:GetPitchFollow() and isnumber( self:DrG_SearchBone( self.PitchBone ) ) then

    self:ApproachPitchFollow( self.PitchBone, self.PitchOrientation, self:GetAimAngles(), self.MaxYawRate )

  elseif not self:GetPitchFollow() and isnumber( self:DrG_SearchBone( self.PitchBone ) ) then

    self:ResetPitchFollow( self.PitchBone )

  end


  if istable( self:GetVibrate() ) and not table.IsEmpty( self:GetVibrate() ) then

    local Data = self:GetVibrate()
    local Duration = Data.Time

    if CurTime() < Duration then

      self:ManipulateBonePosition( 0, UltrakillBase.VectorNoise( Data.Amp, Data.Freq, 5 ), false )

    else

      self:ManipulateBonePosition( 0, vector_origin, false )

      table.Empty( self.VibrateData )
      
    end

  end


end


local SandMaterial = Material( "models/ultrakill/vfx/Sand" )


function ENT:_BaseDraw()

  if self:IsSand() then

    render.MaterialOverride( SandMaterial )

    self:DrawModel()

  end

  if self:IsRadiant() then

    self:DrawRadiant()

  end

  render.MaterialOverride()

end


function ENT:DrawTranslucent()

  self:Draw()

end


function ENT:GetSecondaryBarValues()

  return math.min( self:GetStamina() / self:GetStaminaMax(), 1 ), UltrakillBase.DefaultSecondaryBarColor

end


end

-- DO NOT TOUCH --
AddCSLuaFile()
-- DrGBase.AddNextbot( ENT )