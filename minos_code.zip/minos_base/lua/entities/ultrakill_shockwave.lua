if not DrGBase or not UltrakillBase then return end -- return if DrGBase or UltrakillBase isn't installed
ENT.Base = "ultrakillbase_projectile"

-- Misc --

ENT.PrintName = "Shockwave_Projectile"
ENT.Category = "UltrakillBase"
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
ENT.Models = { "models/ultrakill/mesh/effects/shockwave/Shockwave.mdl" }
ENT.ModelScale = 0
ENT.Spawnable = false

-- Physics --

ENT.Gravity = false
ENT.Physgun = false
ENT.Gravgun = false

-- Sounds --

ENT.LoopSounds = {""}
ENT.Damage = 250

-- Parry --

ENT.Ultrakill_Parryable = false

-- Shockwave --

ENT.HitTable = {}

local SphereRadius = 2400

if SERVER then

  AddCSLuaFile()

function ENT:CustomInitialize()

  self.InitTime = CurTime()

  self:SetCollisionGroup( COLLISION_GROUP_WORLD )

  self:DrawShadow( false )

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then

    Phys:Sleep()

  end

  SafeRemoveEntityDelayed( self, ( self:GetTime() / self:CalculateRate() ) )

end

function ENT:CustomThink()

  local ModelSize = Lerp( ( CurTime() - self.InitTime ) / ( self:GetTime() / self:CalculateRate() ), 0, self:GetRadius() )

  self:SetModelScale( ModelSize )

  local Owner = self:GetOwner()

  local Radius = ModelSize * 22
  local Range = Radius * 0.625

  local ZAxis = self:GetUp()

  local Sphere = ents.FindInSphere( self:GetPos(), SphereRadius * ModelSize * 0.01 )

  for I = 1, #Sphere do

    local Ent = Sphere[ I ]

    if not UltrakillBase.CanAttack( Ent ) or self.HitTable[ Ent:EntIndex() ] or self.IgnoreFilter[ Ent:EntIndex() ] then

      continue

    end

    local SelfDot = self:GetPos():Dot( ZAxis )
    local EntDot = Ent:GetPos():Dot( ZAxis )
    local DotDifference = math.abs( SelfDot - EntDot )
    local ZLimit = ( 8 * self:GetScaleZ() ) * 50

    if DotDifference > ZLimit then

      continue

    end

    if self:GetPos():DistToSqr( Ent:GetPos() ) <= ( Range ^ 2 ) or self:GetPos():DistToSqr( Ent:GetPos() ) > ( Radius ^ 2 ) then

      continue

    end

    self:DealDamage( Ent, self:GetDamage(), Vector( 0, 0, 400 ), DMG_BLAST )

    self.HitTable[ Ent:EntIndex() ] = true

  end

end

else


  -- Localize Libaries & Functions --


local Matrix = Matrix
local render = render
local Vector = Vector

local Shockwave = Material( "particles/ultrakill/Shockwave" )

function ENT:CustomDraw()

  local SMatrix = Matrix()

  local ScaleZ = ( 1 / ( self:GetModelScale() / self:GetRadius() ) ) * self:GetScaleZ()

  SMatrix:SetScale( Vector( 1, 1, ScaleZ ) )

  self:EnableMatrix( "RenderMultiply", SMatrix )

  render.SetMaterial( Shockwave )

  local Max = Vector( 1, 1, 0 ) * self:GetModelScale() * 25

  render.DrawBox( self:GetPos() + self:GetUp() * ( 15 / ( 0.125 / self:GetScaleZ() ) ), self:GetAngles(), -Max, Max, Color( 255, 255, 255, 100 ) )

end 

end

  -- Network Vars --

function ENT:SetupDataTables()

  self:NetworkVar( "Int", 0, "Damage" )
  self:NetworkVar( "Float", 0, "Time" )
  self:NetworkVar( "Int", 1, "Radius" )
  self:NetworkVar( "Float", 1, "ScaleZ" )

end