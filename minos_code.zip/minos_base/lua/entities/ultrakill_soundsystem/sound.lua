SOUND = ENT

if not istable( SOUND ) or SERVER then return end


  -- Localize Libaries & Functions --


local math = math
local game = game
local gui = gui

local LocalPlayer = LocalPlayer

local VolumeConVar = CreateConVar( "drg_ultrakill_sound_volume", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "SFX Volume." )
local DyingConVar = CreateConVar( "drg_ultrakill_sound_dying_pitch", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Lowers Pitch when Dead." )

local function ProcessDoppler( self, Listener, DopplerLevel )

  if DopplerLevel <= 0 then return 1 end

  if IsValid( self:GetParent() ) then self = self:GetParent() end

  local SpeedOfSound = 18005.2493438 * DopplerLevel -- Speed of Sound is 343 m/s. This is converted to Hammer Units.

  local Pos, ListenerPos = self:GetPos(), Listener:GetPos()

  local Velocity = self:GetVelocity()
  local ListenerVelocity = Listener:GetVelocity()

  local RelativePos = Pos - ListenerPos

  if Velocity:Zero() and ListenerVelocity:Zero() or RelativePos:IsZero() then return 1 end

  local RelativeVelocity = RelativePos:Dot( Velocity ) / RelativePos:Length()
  local RelativeListenerVelocity = RelativePos:Dot( ListenerVelocity ) / RelativePos:Length()

  return ( SpeedOfSound + RelativeListenerVelocity ) / ( SpeedOfSound + RelativeVelocity )

end

local function ProcessPanning( self, Listener )

  local Pos, ListenerPos = self:GetPos(), Listener:GetPos()
  local ListenerAngle = Listener:GetAimVector():Angle()

  return ( Pos - ListenerPos ):GetNormalized():Dot( ListenerAngle:Right() )

end

local function ProcessPausing( Audio )

  if Audio:GetState() ~= GMOD_CHANNEL_PAUSED then

    if game.SinglePlayer() and gui.IsGameUIVisible() then 

      Audio:Pause()

    end

  elseif Audio:GetState() ~= GMOD_CHANNEL_PLAYING then

    if game.SinglePlayer() and not gui.IsGameUIVisible() then 

      Audio:Play()

    end

  end

end

local function Process3D( self, Audio, Radius, Volume, Listener )

  if Radius > 0 then

    local DistSqr = self:GetPos():DistToSqr( Listener:GetPos() )

    Audio:SetPan( ProcessPanning( self, Listener ) )

    if DistSqr <= Radius ^ 2 then

      Audio:SetVolume( Volume * ( math.Clamp( 1 - DistSqr / Radius ^ 2, 0, 1 ) ^ 1.2 ) )

    else

      Audio:SetVolume( 0 )

    end

  else

    Audio:SetVolume( Volume )

  end

end

local DyingInitTime = 0

local function ProcessDying( Listener )

  if not DyingConVar:GetBool() then return 1 end

  if Listener:Alive() then

    DyingInitTime = SysTime()

  end

  local DyingDelta = ( SysTime() - DyingInitTime ) / 10

  local Pitch = Lerp( DyingDelta, 1, 0.0000000001 )

  return Pitch

end

function SOUND:AudioUpdate()

  if not IsValid( self:GetAudio() ) or self.StopUpdating then return end

  local Audio = self:GetAudio()
  local Listener = LocalPlayer()
  local Radius = self.Radius
  local Pitch = self.Pitch
  local Volume = self.Volume * VolumeConVar:GetFloat()
  local Timescale = self.TimeScale and game.GetTimeScale() or 1

  Audio:SetPlaybackRate( Pitch * Timescale * ProcessDoppler( self, Listener, self.DopplerLevel ) * ProcessDying( Listener ) )

  Volume = system.HasFocus() and Volume or 0

  Process3D( self, Audio, Radius, Volume, Listener )

  ProcessPausing( Audio )

end



