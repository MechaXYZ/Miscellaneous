SOUND = ENT

ENT.Base = "base_entity"
ENT.Type = "point"

if SERVER then

	AddCSLuaFile( "shared.lua" )
	AddCSLuaFile( "sound.lua" )

end

include( "sound.lua" )

local ClientNoBlockConVar = CreateClientConVar( "drg_ultrakill_sound_noblock", 0, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enable NoBlock Setting on SoundSystem." )


	-- No Saves / Dupes! --


local Old_gmsaveShouldSaveEntity = gmsave.ShouldSaveEntity

function gmsave.ShouldSaveEntity( Ent, T )

	if istable( T ) and T.classname == "ultrakill_soundsystem" then 
		
		return false

	end

	return Old_gmsaveShouldSaveEntity

end



function SOUND:Initialize()

	self:DrawShadow( false )

	self:SetData( UltrakillBase.GetSoundScriptData( self:GetScriptName(), true ) ) -- Setup Script Variables.

	
		-- Variables --
	

	self.InitTime = CurTime()
	self.CanDie = isnumber( self.DieTime ) and self.DieTime >= 0 or false
	self.HasParent = IsValid( self:GetParent() )

	
		-- Initialize Sound Channel --
	

	if CLIENT then

		sound.PlayFile( "sound/" .. tostring( self.Path ), "noplay" .. ( ClientNoBlockConVar:GetBool() and " noblock" or "" ), function( Audio, ErrorCode, ErrorName )

			if not IsValid( self ) then return false end

			if not IsValid( Audio ) then

				if GetConVar( "developer" ):GetInt() >= 1 then

					DrGBase.Error( "UltrakillBase.Sound has failed to play Audio: " .. self.Path .. " ErrorCode: " .. tostring( ErrorCode ) .. " ErrorString: " .. ErrorName, { chat = true } )

				end

				return false

			end

			Audio:SetPos( self:GetPos(), self:GetAngles():Forward() )

			Audio:EnableLooping( self.Looping or false )

			self:SetAudio( Audio ) -- Cache the Channel so it doesn't get garbage collected.

			self:AudioUpdate() -- Force the Audio to Update on Initalize. Fixes some issues.

			Audio:Play() -- After Updating, Play the Audio.

		end )

	end

	
		-- Debugging --
	

	local TextDieTime = self.CanDie and self.DieTime or 10

	debugoverlay.EntityTextAtPosition( self:GetPos(), 1, tostring( self ) .. " " .. self:GetScriptName(), TextDieTime )

end




function SOUND:Think()

	if self.StopUpdating or self:IsMarkedForDeletion() then 
		
		return false 
	
	end

	-- Update Entities --

	if CLIENT then

		self:AudioUpdate() -- Update Audio Per Tick.

	end

	if SERVER and self.CanDie and CurTime() - self.InitTime > self.DieTime then

		self:Remove()

	end

	if isfunction( self.Callback ) then

    	self.Callback( self, self:GetParent() )

  	end

	self:NextThink( CurTime() )

	return true

end



function SOUND:OnRemove()

	self.StopUpdating = true

	if CLIENT and IsValid( self:GetAudio() ) then

		self.Audio:SetVolume( 0 )
		self.Audio:Stop()

	end

end



function SOUND:Draw() end -- Do not Draw this entity.



function SOUND:SetupDataTables()

	self:NetworkVar( "String", 0, "ScriptName" ) -- Network String Var.

end



function SOUND:UpdateTransmitState() return TRANSMIT_ALWAYS end -- Always Transmit. ( Ignore Player's PVS )




	-- Functions --


function SOUND:GetAudio()

  return self.Audio

end

function SOUND:SetAudio( Audio )

  self.Audio = Audio

end



function SOUND:SetData( Data )

  self.InitData = Data 

  for Key, Val in pairs( Data or {} ) do -- Auto Allocate Variables to Table Keys.

    self[ Key ] = Val

  end

end

