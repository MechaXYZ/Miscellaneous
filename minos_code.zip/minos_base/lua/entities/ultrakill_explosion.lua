if not DrGBase or not UltrakillBase then return end -- return if DrGBase or UltrakillBase isn't installed
ENT.Base = "ultrakillbase_projectile"

-- Misc --

ENT.PrintName = "Explosion"
ENT.Category = "UltrakillBase"
ENT.Models = { "" }
ENT.ModelScale = 0
ENT.Spawnable = false

-- Physics --

ENT.Gravity = false
ENT.Physgun = false
ENT.Gravgun = false

-- Sounds --

ENT.LoopSounds = { "" }

-- Parry --

ENT.Ultrakill_Parryable = false

-- Explosion --

ENT.HitTable = {}

if SERVER then

  AddCSLuaFile()

function ENT:CustomInitialize()

  self.InitTime = CurTime()

  self:SetCollisionGroup( COLLISION_GROUP_WORLD )

  self:DrawShadow( false )
  self:SetNoDraw( true )

  self.DamageType = DMG_BLAST

  if self.IsParry == true then

    self.DamageType = bit.bor( self.DamageType, DMG_DIRECT )

  end
  
  SafeRemoveEntityDelayed( self, self:GetTime() )

end

function ENT:CustomThink()

  local Radius = Lerp( ( CurTime() - self.InitTime ) / ( self:GetTime() * 0.7 ), 0, self:GetRadius() )

  local Sphere = ents.FindInSphere( self:GetPos(), Radius )

  for X = 1, #Sphere do

    local Ent = Sphere [ X ]

    if not UltrakillBase.CanAttack( Ent ) or not self:Visible( Ent ) or self.HitTable[ Ent:EntIndex() ] or self.IgnoreFilter[ Ent:EntIndex() ] then

      continue

    end

    self:DealDamage( Ent, self:GetDamage(), self:GetForce(), self.DamageType )

    self.HitTable[ Ent:EntIndex() ] = true

  end

end

end

  -- Network Vars --

function ENT:SetupDataTables()

  self:NetworkVar( "Int", 0, "Damage" )
  self:NetworkVar( "Float", 0, "Time" )
  self:NetworkVar( "Int", 1, "Radius" )
  self:NetworkVar( "Vector", 0, "Force" )

end