if not DrGBase or not UltrakillBase then return end -- return if DrGBase or UltrakillBase isn't installed
ENT.Base = "proj_drg_default"

-- Misc --
ENT.PrintName = "Ultrakill_Projectiles"
ENT.Category = "UltrakillBase"
ENT.Models = { "" }
ENT.ModelScale = 1

ENT.IsUltrakillProjectile = true

-- Physics --

ENT.Gravity = false
ENT.Physgun = false
ENT.Gravgun = false

-- Contact --

ENT.OnContactDelay = 0
ENT.OnContactDelete = -1
ENT.OnContactDecals = {}

-- Sounds --

ENT.LoopSounds = { "" }
ENT.OnContactSounds = {}
ENT.OnRemoveSounds = {}

-- Parry --

ENT.Ultrakill_Parryable = true

-- Homing --

ENT.UseHoming = false
ENT.HomingTurnRate = 400
ENT.HomingSpeed = 1000
ENT.HomingType = 1

-- Collision --

ENT.UseCustomCollision = false
ENT.CustomCollisionMask = MASK_SHOT
ENT.CustomDispCollisions = {
  [ D_NU ] = false,
  [ D_FR ] = true,
  [ D_ER ] = true,
  [ D_HT ] = true,
  [ D_LI ] = false,
}

ENT.CustomCollisionRadius = 200

-- Damage --

ENT.Damage = 0
ENT.DamageRelationship = {
  [ D_NU ] = false,
  [ D_FR ] = true,
  [ D_ER ] = true,
  [ D_HT ] = true,
  [ D_LI ] = false,
}

ENT.DynamLights = {}

DrGBase.IncludeFolder("ultrakillbase/Projectile")
DrGBase.IncludeFolder("ultrakillbase/Shared")


if SERVER then

  AddCSLuaFile()

function ENT:_BaseInitialize()

  self:DrawShadow( false )

  self:CalculateUpdateInterval()

  self:SetSpawnEffect( false )

  self.UltrakillEnemyUpdate = 0
  self.UltrakillCollisionUpdate = 0

  if self.UseCustomCollision then

    self:SetCollisionGroup( COLLISION_GROUP_WORLD )

    if isvector( self.CustomCollisionBounds ) then

      self.CollisionMins, self.CollisionMaxs = -self.CustomCollisionBounds, self.CustomCollisionBounds

    else

      self.CollisionMins, self.CollisionMaxs = self:GetCollisionBounds()

    end

    self:SetCollisionBounds( self.CollisionMins, self.CollisionMaxs )

  end

  self:HomingInitialize()

  self:SetParryable( self.Ultrakill_Parryable )
  self:SetParried( false )

  self:NextThink( CurTime() ) -- Start Thinking right away!

end

function ENT:_BaseThink()

  self:CalculateUpdateInterval()

  if CurTime() > self.UltrakillEnemyUpdate then -- Update Enemy.

    self.UltrakillEnemyUpdate = CurTime() + 0.1
    self:UpdateEnemy()

  end

  if self.UseCustomCollision and self:CollisionOptimization( self.CustomCollisionRadius ) and CurTime() > self.UltrakillCollisionUpdate then

    self.UltrakillCollisionUpdate = CurTime() + 0.01

    local CollisionTrace = self:TraceHull( nil, {

      start = self:GetPos(),
      endpos = self:GetPos() + self:GetVelocity() * self:GetUpdateInterval(),
      collisiongroup = COLLISION_GROUP_PROJECTILE,
      mask = MASK_SHOT,
      filter = { self, self:GetOwner() },
      mins = self.CollisionMins,
      maxs = self.CollisionMaxs,

    } )

    if CollisionTrace.Hit and self:ProjectileShouldCollide( CollisionTrace.Entity ) then

      self:Contact( CollisionTrace.Entity )

    end

  end

  local Owner = self:GetOwner()

  if self:GetHoming() and IsValid( Owner ) and Owner.IsUltrakillNextbot then

    self:HandleHoming()

  end

end

else

  function ENT:_BaseInitialize()

    self:CalculateUpdateInterval()

  end

  function ENT:_BaseThink()
  
    self:CalculateUpdateInterval()

  end

  function ENT:DrawTranslucent()

    self:Draw()

  end

end