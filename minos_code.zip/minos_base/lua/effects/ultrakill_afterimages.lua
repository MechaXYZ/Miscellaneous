
  -- Localize Libaries & Functions --


local render = render
local CurTime = CurTime
local Lerp = Lerp



function EFFECT:Init( Data )

	self.Ent = Data:GetEntity()

	if not self.Ent or not IsValid( self.Ent ) then return end

	self.Pos = Data:GetOrigin()
	self.Ang = Data:GetAngles()

	self.Cycle = self.Ent:GetCycle()
	self.Seq = self.Ent:GetSequence()

	self.LifeTime = ( Data:GetMagnitude() ) or 1

	self.Col = Data:GetStart() / 10 or Color(0,0.6,1)

	self.Model, self.ModelScale = self.Ent:GetModel(), self.Ent:GetModelScale()

	self.InitTime = CurTime()

	local Min, Max = self.Ent:GetCollisionBounds()

	self:SetRenderBounds( Min, Max )
	self:SetPos( self.Pos ) -- Set the Effect Pos. This makes it not be at world origin, making the models stop rendering when not looking at the world origin.

	self.Alpha = 0

	self.ImageFresnel = ClientsideModel( self.Model, RENDERGROUP_TRANSLUCENT )
	self.Image = ClientsideModel( self.Model, RENDERGROUP_TRANSLUCENT )

	self.Image:SetPos( self.Pos )
	self.Image:SetModelScale( self.ModelScale )
	self.Image:SetAngles( self.Ang )
	self.Image:ResetSequence( self.Seq )
	self.Image:SetSequence( self.Seq )
	self.Image:SetCycle( self.Cycle )
	self.Image:SetSkin( self.Ent:GetSkin() )

	self.ImageFresnel:SetPos( self.Pos )
	self.ImageFresnel:SetModelScale( self.ModelScale )
	self.ImageFresnel:SetAngles( self.Ang )
	self.ImageFresnel:ResetSequence( self.Seq )
	self.ImageFresnel:SetSequence( self.Seq )
	self.ImageFresnel:SetCycle( self.Cycle )
	self.ImageFresnel:SetSkin( self.Ent:GetSkin() )

	-- Copy Bodygroups --

	local Bodygroups = self.Ent:GetBodyGroups()

	for K, V in ipairs( Bodygroups ) do

		self.Image:SetBodygroup( V.id, self.Ent:GetBodygroup( V.id ) )

		self.ImageFresnel:SetBodygroup( V.id, self.Ent:GetBodygroup( V.id ) )

	end

	-- Copy Bone Manipulations --

	if self.Ent:HasBoneManipulations() then

		for X = 0, self.Ent:GetBoneCount() - 1 do

			self.Image:ManipulateBoneAngles( X, self.Ent:GetManipulateBoneAngles( X ), false )
			self.Image:ManipulateBonePosition( X, self.Ent:GetManipulateBonePosition( X ), false )
			self.Image:ManipulateBoneScale( X, self.Ent:GetManipulateBoneScale( X ) )
			self.Image:ManipulateBoneJiggle( X, self.Ent:GetManipulateBoneJiggle( X ) )

			self.ImageFresnel:ManipulateBoneAngles( X, self.Ent:GetManipulateBoneAngles( X ), false )
			self.ImageFresnel:ManipulateBonePosition( X, self.Ent:GetManipulateBonePosition( X ), false )
			self.ImageFresnel:ManipulateBoneScale( X, self.Ent:GetManipulateBoneScale( X ) )
			self.ImageFresnel:ManipulateBoneJiggle( X, self.Ent:GetManipulateBoneJiggle( X ) )

		end

	end

  	self.Image:AddEffects( EF_NODRAW )
	self.ImageFresnel:AddEffects( EF_NODRAW )

end

function EFFECT:Think()

	if not self.Ent or not IsValid( self.Ent ) then return false end

  	if CurTime() - self.InitTime > self.LifeTime then

		SafeRemoveEntity( self.Image )
		SafeRemoveEntity( self.ImageFresnel )

		return false

	end

	self.Alpha = Lerp( ( CurTime() - self.InitTime ) / self.LifeTime , 1, 0 )

   return IsValid( self.Image )

end

local Mat = Material( "models/ULTRAKILL/vfx/White" )
local FresnelMat = Material( "models/ULTRAKILL/vfx/Afterimage" )

function EFFECT:Render()

	if not self.Ent or not IsValid( self.Ent ) then return false end

   	-- AfterImage Render --

   	render.SetBlend( 0.4 * self.Alpha )
   	render.MaterialOverride( Mat )
   	render.SetColorModulation( self.Col.r * 0.75, self.Col.g * 0.75, self.Col.b * 0.75 )

   	self.Image:DrawModel()

	render.MaterialOverride( FresnelMat )

	self.ImageFresnel:DrawModel()

   	render.SetBlend( 1 )
   	render.MaterialOverride( )
   	render.SetColorModulation( 1, 1, 1 )

end
