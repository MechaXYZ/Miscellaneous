
  -- Localize Libaries & Functions --


local render = render
local CurTime = CurTime
local Lerp = Lerp
local Matrix = Matrix

local DieTime = 0.53
local ScaleTime = 0.53

local Colors = {

	Vector( 0.3, 0.85, 1 ),
	Vector( 0.85, 0.3, 1 ),
	Vector( 1, 0.7, 0 ),
	Vector( 0, 1, 0.8 ),
	Vector( 1, 0.1, 0.1 )

}

local Materials = {

	"models/ultrakill/vfx/Portal_Light",
	"models/ultrakill/vfx/Portal_Heavy",
	"models/ultrakill/vfx/Portal_Superheavy",
	"models/ultrakill/vfx/Portal_Mindflayer",
	"models/ultrakill/vfx/Portal_Red",
	"models/ultrakill/vfx/Portal_Light",
	"models/ultrakill/vfx/Portal_Light",
	"models/ultrakill/vfx/Portal_Light"

}



function EFFECT:Init( data )

	self.Pos = data:GetOrigin()
	self.Ang = data:GetAngles()
	self.Ent = data:GetEntity()
	self.Flag = data:GetColor()
	self.Max = data:GetStart()

	self.PortalMaterial = Material( Materials[ self.Flag ] )

	self.InitTime = CurTime()

	self.Scaling = 0

	self.Max = self.Max / 25

	self.Portal = ClientsideModel( "models/ultrakill/mesh/effects/sphere/Sphere_16.mdl", RENDERGROUP_OPAQUE )
	self.Portal:SetPos( self.Pos )
	self.Portal:SetAngles( self.Ang )
	self.Portal:SetModelScale( 1 )
   	self.Portal:AddEffects( EF_NODRAW )

end

function EFFECT:Think()

   	if CurTime() - self.InitTime > DieTime then

		return SafeRemoveEntity( self.Portal )

	end

	self.Scaling = Lerp( ( CurTime() - self.InitTime ) / ScaleTime, 1, 0 )

   	return IsValid( self.Portal )

end

function EFFECT:Render()

	local SMatrix = Matrix()
	SMatrix:SetScale( Vector( 1.3 * self.Max.x * self.Scaling, 1.3 * self.Max.y * self.Scaling, self.Max.z * self.Scaling ) )

	self.Portal:EnableMatrix( "RenderMultiply", SMatrix )

   	render.MaterialOverride( self.PortalMaterial )

   	self.Portal:DrawModel()

   	render.MaterialOverride( )
   
end
