if SERVER then return end

 -- God i just wish BASS.dll worked on Linux then i wouldn't have to make this dumb as fuck hack to fix this bug. --
 -- I believe i could also just further improve the system by adding a js audio engine into the mix. it'll be a lot weirder to manage, but i might experiment with this later --
 -- I ain't gonna support this that much, it's just some hacky code meant to cover linux os bullshit --
 -- It should mount this code instead of the previous code in the main file, if the user is on linux! --

local table = table
local math = math
local net = net
 
local istable = istable
local Empty = table.Empty
local IsEmpty = table.IsEmpty
local Lerp = Lerp
local pairs = pairs

local MusicStack = {}
local CurrentChannel = {}
local PreviousChannel = {}

local function CheckConVarTable( String )

  if not isstring( String ) then return end

  for I, V in pairs( UltrakillBase.MusicTable ) do

    if String == I and V.ConVar ~= nil then

      return V.ConVar:GetBool()

    end

  end

  return true

end

local function IsChannelValid( Channel )

  return not IsEmpty( Channel ) and istable( Channel ) and Channel.Audio

end

local function IsNextMusicValid()

  if #MusicStack <= 0 then return false end

  local Data = MusicStack[ 1 ]

  return IsValid( Data[ 1 ] ) and #MusicStack > 0

end

function UltrakillBase.PlayMusic( self, Name, Time, Fade )

    if not CheckConVarTable( Name ) or not IsValid( self ) or ( IsValid( self ) and self.IsDrGNextbot and self:IsDead() ) or not istable( UltrakillBase.MusicTable[ Name ] ) then return false end

    if IsChannelValid( CurrentChannel, true ) then

        table.insert( MusicStack, { self, Name, Time } )

        return true

    end

    local Audio = CreateSound( game.GetWorld(), UltrakillBase.MusicTable[ Name ].String )

    Audio:SetSoundLevel( 0 )

    if Fade then

        Audio:PlayEx( 0, 100 )
        Audio:ChangeVolume( GetConVar( "drg_ultrakill_music_volume" ):GetFloat(), 1 )

    else

        Audio:PlayEx( GetConVar( "drg_ultrakill_music_volume" ):GetFloat(), 100 )

    end

    CurrentChannel = { Audio = Audio, Ent = self, Name = Name }

end

local function PlayNextMusic()

  if #MusicStack <= 0 then return end -- Is it Empty?

  local Data = table.remove( MusicStack, 1 )

  if not IsValid( Data[1] ) or not isstring( Data[2] ) then
  
    return PlayNextMusic()
  
  end
  
  UltrakillBase.PlayMusic( Data[1], Data[2], Data[3], true ) -- Call Play Func

end

function UltrakillBase.TransferOwnershipMusic( self, Owner )

  if IsEmpty( CurrentChannel ) or not IsValid( Owner ) or self ~= CurrentChannel.Ent then return end

  CurrentChannel.Ent = Owner

end

function UltrakillBase.StopMusic( self, Name, BypassStack, Fade )

  local Data = MusicStack[ 1 ]

  if istable( Data ) and Data[ 1 ] == self and Data[ 2 ] == Name then

    table.remove( MusicStack, 1 )

  end

  if not CurrentChannel.Audio or IsValid( CurrentChannel.Ent ) and CurrentChannel.Ent ~= self then return end

  Fade = Fade or IsNextMusicValid()

  if not Fade then

    CurrentChannel.Audio:Stop()

  else

    CurrentChannel.Audio:FadeOut( 1 )

  end

  Empty( CurrentChannel )

  if BypassStack ~= true then

    PlayNextMusic() -- Check MusicStack for Next music?

  end

end

function UltrakillBase.ChangeMusic( self, From, To, Fading )

  if CurrentChannel.Name ~= From and IsValid( CurrentChannel.Audio ) then 

    return UltrakillBase.PlayMusic( self, To, 0, Fading )

  end

  UltrakillBase.StopMusic( self, From, true, Fading )
  UltrakillBase.PlayMusic( self, To, 0, Fading )

end

local PitchUpInitTime = nil
local PitchUpEntityAttach = nil

local function ResetPitchUp()

  if isnumber( PitchUpInitTime ) and not IsValid( PitchUpEntityAttach ) then

    PitchUpInitTime = nil
    PitchUpEntityAttach = nil

  end

end

local HoldTime = 3.5

local function ProcessFleshPrison2Music ()

  if not IsChannelValid( CurrentChannel ) or ( IsValid( CurrentChannel.Ent ) and CurrentChannel.Ent.IsUltrakillNextbot and not CurrentChannel.Ent:IsDead() and not CurrentChannel.Ent:IsDying() ) then return 1 end

  PitchUpEntityAttach = CurrentChannel.Ent
  PitchUpInitTime = PitchUpInitTime or CurTime()

  local Pitch = 0.01
  local TimeDiff = CurTime() - PitchUpInitTime

  if TimeDiff > HoldTime and TimeDiff < HoldTime + 2 then

    Pitch = 0.5

  elseif TimeDiff > HoldTime + 2 then

    Pitch = Lerp( ( CurTime() - ( PitchUpInitTime + HoldTime + 2 ) ) / 3, 0.5, 2 )

  end

  return Pitch

end

local function ProcessFleshPrisonMusic( )

  if not IsChannelValid( CurrentChannel ) or ( IsValid( CurrentChannel.Ent ) and CurrentChannel.Ent.IsUltrakillNextbot and not CurrentChannel.Ent:IsDead() and not CurrentChannel.Ent:IsDying() ) then return 1 end
  if not UltrakillBase.MusicTable[ CurrentChannel.Name ].MusicType then return 1 end

  PitchUpEntityAttach = CurrentChannel.Ent

  local Type = UltrakillBase.MusicTable[ CurrentChannel.Name ].MusicType

  if Type == 2 then return ProcessFleshPrison2Music() end

  PitchUpInitTime = PitchUpInitTime or CurTime()

  local Pitch = Lerp( ( CurTime() - PitchUpInitTime ) / 5, 1, 2 )

  return Pitch

end

hook.Add( "Tick", "UltrakillBase_Music_Update", function()

  local Audio = CurrentChannel.Audio
  local PrevAudio = PreviousChannel.Audio

  local Pitch = CurrentChannel.Pitch or 1
  local PrevPitch = PreviousChannel.Pitch or 1
  local Timescale = game.GetTimeScale() or 1

  -- Update Audio --

  ResetPitchUp()

  local FleshPrisonPitch = ProcessFleshPrisonMusic()

  if IsValid( Audio ) then

    Audio:ChangePitch( Pitch * Timescale * FleshPrisonPitch )

  end

  if IsValid( PrevAudio ) then

    PrevAudio:ChangePitch( PrevPitch * Timescale )

  end

end )