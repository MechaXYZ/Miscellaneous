

if CLIENT then return end

local function IsPlayerFlying( Ply )

  return Ply:IsFlagSet( FL_FLY ) or Ply:IsEFlagSet( EFL_NOCLIP_ACTIVE ) or Ply:WaterLevel() >= 2 or Ply:IsOnGround()

end

local function CalculatePlayerValues( Ply )

  local G = Ply:GetGravity() * GetConVar( "sv_gravity" ):GetFloat()
  local V = Ply:GetVelocity()
  local M = MASK_PLAYERSOLID

  if IsPlayerFlying( Ply ) then

    Gravity = 0

  end

  return V, G, M

end

local function CalculateNextbotValues( Nextbot )

  local G = Nextbot.loco:GetGravity()
  local V = Nextbot.loco:GetVelocity()
  local M = Nextbot:GetSolidMask()

  if Nextbot.loco:IsOnGround() then

    Gravity = 0

  end

  return V, G, M

end

local function CalculateNPCValues( Npc )

  local G = Npc:GetGravity() * GetConVar( "sv_gravity" ):GetFloat()
  local V = Npc:GetGroundSpeedVelocity()
  local M = MASK_NPCSOLID

  if Npc:IsFlagSet( FL_FLY ) or Npc:IsOnGround() then

    Gravity = 0

  end

  return V, G, M

end

local function CalculateOtherValues( Other )

  local G = Vector( 0, 0, -1 ) * physenv.GetGravity()
  local V = Other:GetVelocity()
  local M = MASK_SOLID

  return V, G, M

end

local function CalculatePredictTrace( Start, End, Ent )

  local Mins, Maxs = Ent:GetCollisionBounds()

  local Trace = util.TraceHull( {

    start = Start,
    endpos = End,
    collisiongroup = Ent:GetCollisionGroup(),
    mask = PredictMask,
    mins = Mins,
    maxs = Maxs,
    filter = Ent,

  } )

  return Trace

end

local function PredictDebug( Trace )

  debugoverlay.Cross( Trace.StartPos, 30, 2, Color( 255, 0, 0 ) )
  debugoverlay.Text( Lerp( 0.5, Trace.StartPos, Trace.HitPos ), "UltrakillBase.Predict", 2, true )
  debugoverlay.Line( Trace.StartPos, Trace.HitPos, 2, Color( 166, 255, 0) )
  debugoverlay.Cross( Trace.HitPos, 30, 2, Color( 25, 0, 255) )

end

function UltrakillBase.Predict( PredictEntity, PredictTime, UseFeet, NoZ )

  if not isentity( PredictEntity ) or not IsValid( PredictEntity ) then return end

  local Pos = UseFeet and PredictEntity:GetPos() or PredictEntity:WorldSpaceCenter()

  local Trajectory
  local PredictMask
  local Gravity
  local Velocity

  if PredictEntity:IsPlayer() then
    
    Velocity, Gravity, PredictMask = CalculatePlayerValues( PredictEntity )

  elseif PredictEntity.IsNextBot() then
    
    Velocity, Gravity, PredictMask = CalculateNextbotValues( PredictEntity )

  elseif PredictEntity:IsNPC() then

    Velocity, Gravity, PredictMask = CalculateNPCValues( PredictEntity )

  else

    Velocity, Gravity, PredictMask = CalculateOtherValues( PredictEntity )

  end

  local PredictedPos = Velocity * PredictTime

  PredictedPos.z = NoZ and 0 or Velocity.z * PredictTime - ( Gravity * PredictTime ^ 2 ) * 0.5

  Trajectory = Pos + PredictedPos

  local PredictTrace = CalculatePredictTrace( Pos, Trajectory, PredictEntity )

  PredictDebug( PredictTrace )

  if PredictTrace.Hit then

    Trajectory = PredictTrace.HitPos

  end

  return Trajectory, PredictTrace

end

