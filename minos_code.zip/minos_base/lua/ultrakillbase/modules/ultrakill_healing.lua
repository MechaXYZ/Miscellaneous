if SERVER then

local HealingEnabled = CreateConVar( "drg_ultrakill_healing", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enables Healing" )
local HealingMax = CreateConVar( "drg_ultrakill_healing_maxheal", 25, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Set the Maximum amount of Health that can be healed in one shot." )
local HealingRange = CreateConVar( "drg_ultrakill_healing_range", 200, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Set Range required to gain health." )

local UltrakillOnly = CreateConVar( "drg_ultrakill_healing_ultrakillonly", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Should Healing only be considered for Ultrakill Nextbots." )

local HardDamageEnabled = CreateConVar( "drg_ultrakill_healing_harddamage", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enables Hard Damage." )
local HardDamageMult = CreateConVar( "drg_ultrakill_healing_harddamage_multiplier", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Multiplies the amount of Hard Damage you receive." )
local HardDamageRecoveryMult = CreateConVar( "drg_ultrakill_healing_harddamage_recovery_multiplier",1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Multiplies the amount of Hard Damage you receive." )
local HardDamageEnforce = CreateConVar( "drg_ultrakill_healing_harddamage_enforce", 0, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enforces Hard Damage. May cause issues with other addons." )

hook.Add( "PostEntityTakeDamage", "UltrakillBase_Healing", function( Ent, CDamageInfo, Took )

    if not HealingEnabled:GetBool() or ( UltrakillOnly:GetBool() and not Ent.IsUltrakillNextbot ) then return end

    local Attacker = CDamageInfo:GetAttacker()

    if Took and IsValid( Attacker ) and Attacker:IsPlayer() and Attacker ~= Ent then

        if Ent:IsNPC() or Ent:IsPlayer() or Ent:IsNextBot() then

            if not Ent:GetNW2Bool( "UltrakillBase_Sand" ) and Attacker:GetPos():DistToSqr( Ent:GetPos() ) <= HealingRange:GetFloat() ^ 2 then

                local Healing = math.Clamp( Attacker:Health() + math.Clamp( CDamageInfo:GetDamage(), 0, HealingMax:GetInt() ), 0, Attacker:GetMaxHealth() - Attacker:GetNW2Int( "UltrakillBase_HardDamage" ) )
                local Pitch = math.Clamp( ( Attacker:Health() + Healing ) / Attacker:GetMaxHealth(), 0.6, 0.7 )

                if Attacker:Health() < Attacker:GetMaxHealth() then

                    Attacker:SetHealth( Healing )

                end

            end

        end

    end

end )

hook.Add( "PlayerHurt", "UltrakillBase_HardDamage", function( Ent, Attacker, Remaining, Taken )

    if not HardDamageEnabled:GetBool() or Attacker == Ent or not IsValid( Attacker ) or ( UltrakillOnly:GetBool() and not Attacker.IsUltrakillNextbot and not Attacker.IsUltrakillProjectile ) then return end

    if Taken > 0 then

        if math.floor( Remaining + Taken ) > Ent:GetMaxHealth() then return end

        local Percentage = UltrakillBase.DifficultyGetInformation( "Healing" ).Percentage
        local HardDamage = Taken * Percentage * HardDamageMult:GetFloat()
        local Time = math.Clamp( ( Taken / 20 ) + UltrakillBase.DifficultyGetInformation( "Healing" ).Delay, 0, 5 ) / HardDamageRecoveryMult:GetFloat()

        Ent:SetNW2Int( "UltrakillBase_HardDamage", math.Clamp( Ent:GetNW2Int( "UltrakillBase_HardDamage" ) + HardDamage, 0, Ent:GetMaxHealth() - 1 ) )
        Ent:SetNW2Float( "UltrakillBase_HardDamage_Time", Time + CurTime() )

    end

end )

hook.Add( "PlayerPostThink", "UltrakillBase_HardDamage", function( Ply )

    local HardDamage = Ply:GetNW2Int( "UltrakillBase_HardDamage" )
    local Time = Ply:GetNW2Float( "UltrakillBase_HardDamage_Time" )

    if HardDamage > 0 and Ply:Health() > Ply:GetMaxHealth() - HardDamage and HardDamageEnforce:GetBool() then

        Ply:SetHealth( Ply:GetMaxHealth() - math.Clamp( HardDamage, 0, Ply:GetMaxHealth() - 1 ) )

    end

    if not Ply:Alive() then

        Ply:SetNW2Int( "UltrakillBase_HardDamage", 0 )
        Ply:SetNW2Float( "UltrakillBase_HardDamage_Time", 0 )

    end

    if CurTime() > Time then

        Ply:SetNW2Int( "UltrakillBase_HardDamage", HardDamage - 14 * engine.TickInterval() )

    end

end )

end