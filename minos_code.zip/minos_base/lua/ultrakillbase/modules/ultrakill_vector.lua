function UltrakillBase.VectorNoise( Amp, Freq, Offset )

  local Vec = Vector()

  for X = 1, 3 do
    
    Vec[ X ] = math.sin( ( math.Rand(-Offset, Offset) + CurTime() ) * Freq ) * Amp

  end

  return Vec

end

function UltrakillBase.VectorApproach( self, TargetVec, Rate )

  for X = 1, 3 do

    self[ X ] = math.Approach( self[X], TargetVec[X], Rate )

  end

end


