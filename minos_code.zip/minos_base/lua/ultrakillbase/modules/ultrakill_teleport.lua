local EmptyAngle = Angle()
local EmptyVec = Vector()
local RayMasks = { MASK_NPCSOLID }


function UltrakillBase.TraceSetPos( self, Pos )

    local Min, Max = self:GetCollisionBounds()

    local TraceInfo = {

        start = self:GetPos(),
        endpos = Pos,
        mins = Min,
        maxs = Max,
        filter = self,

    }

    if self:IsNextBot() then

        TraceInfo.mask = self:GetSolidMask()

    else

        TraceInfo.collisiongroup = self:GetCollisionGroup()

    end

    local TraceResult = util.TraceHull( TraceInfo )

    if not util.IsInWorld( TraceResult.HitPos ) then return end

    return self:SetPos( TraceResult.HitPos )

end


local function CalculateCollisionRadius( self )

    local Mins = self:GetCollisionBounds()

    return math.sqrt( ( math.abs( Mins.x ) ^ 2 ) * 2 )

end


local function RayCast( Origin, Endpos, Mask, IgnoreWorld, Ignore )

    if istable( Mask ) then

        Mask = bit.bor( unpack( Mask ) )

    end

    local TraceInfo = {

        start = Origin,
        endpos = Endpos,
        mask = Mask,
        ignoreworld = IgnoreWorld,
        filter = Ignore,

    }

    return util.TraceLine( TraceInfo )

end


local function HullRayCast( self, Origin, Endpos, Mask, IgnoreWorld, Ignore, Ground )

    if istable( Mask ) then

        Mask = bit.bor( unpack( Mask ) )

    end

    local Min, Max = self:GetCollisionBounds()

    if Min.z == 0 and self.IsDrGNextbot and Ground then

        Min.z = Min.z + self:GetStepHeight()

    end

    local TraceInfo = {

        start = Origin,
        endpos = Endpos,
        mask = Mask,
        ignoreworld = IgnoreWorld,
        mins = Min,
        maxs = Max,
        filter = Ignore,

    }

    return util.TraceHull( TraceInfo )

end


local function IsBadVector( self, Vec, Step )

    local CollisionTrace = self:DrG_TraceHull( nil, {

        start = Vec,
        endpos = Vec,
        step = Step,

    } )

    return CollisionTrace.Hit, CollisionTrace.HitWorld

end


local GroundOffset = Vector( 0, 0, 10000 )

local function GroundTeleport( self, Vec )

    local GroundRay = HullRayCast( self, Vec + self:OBBCenter(), Vec - GroundOffset, MASK_NPCSOLID_BRUSHONLY, false, { self }, true )

    return GroundRay.HitPos

end


local AngleSplits = 6
local MaxRecursions = 4
local MaxSearch = 5000
local ResolverCurrentVector = Vector()
local ResolverRotation = Angle()


local function Resolver( self, Pos, Grounded, SearchDistance, Recursion )


    if not IsValid( self ) or not isvector( Pos ) then return end
    if not isnumber( SearchDistance ) then SearchDistance = 25 + CalculateCollisionRadius( self ) * 2.5 end
    if not isnumber( Recursion ) then Recursion = 1 end


    for X = 0, AngleSplits do


      ResolverCurrentVector:Zero()
      ResolverCurrentVector.x = 1


      ResolverRotation:Zero()
      ResolverRotation.y = ( 360 / AngleSplits ) * X


      ResolverCurrentVector:Rotate( ResolverRotation )


      local OutRay = HullRayCast( self, Pos + self:OBBCenter(), Pos + ResolverCurrentVector * SearchDistance, MASK_NPCWORLDSTATIC, false, { self }, Grounded )
      local InRay = HullRayCast( self, OutRay.HitPos, Pos, RayMasks, true, { self }, Grounded )


      UltrakillBase.Debug( self, "Resolver Iteration:", X .. "/" .. AngleSplits, "Recursion:", Recursion .. "/" .. MaxRecursions )


      if IsBadVector( self, InRay.HitPos, Grounded ) and X < AngleSplits then continue
      elseif IsBadVector( self, InRay.HitPos, Grounded ) and X >= AngleSplits and Recursion < MaxRecursions then return Resolver( self, Pos, Grounded, SearchDistance * ( Recursion + 1 ), Recursion + 1 )
      else return InRay.HitPos end


    end
    

end


local BlackListedNavs = {}


local function NavMeshResolver( self, Pos, Grounded )

    if not IsValid( self ) or not isvector( Pos ) or not navmesh.IsLoaded() then return Resolver( self, Pos, Grounded ) end

    local CNavArea = navmesh.GetNearestNavArea( Pos, false, MaxSearch, false, true )

    if not IsValid( CNavArea ) then return Resolver( self, Pos, Grounded ) end

    local NavPos = CNavArea:GetClosestPointOnArea( Pos )

    UltrakillBase.Debug( self, "NavMeshResolver Found a Valid NavArea:", CNavArea )

    return NavPos

end


function UltrakillBase.CalculateTeleportOffsets( self, Vec, Offset, ShouldRayCast )

    if not isvector( Vec ) and not isentity( Vec ) then return end

    local VecOffset = Vec + Offset
    local RayCastOrigin = Vec

    if isentity( Vec ) then

        VecOffset = Vec:GetForward() * Offset.x + Vec:GetRight() * Offset.y + Vec:GetUp() * Offset.z
        RayCastOrigin = Vec:WorldSpaceCenter()

    end

    if ShouldRayCast then

        VecOffset = HullRayCast( self, RayCastOrigin, VecOffset, MASK_NPCSOLID_BRUSHONLY, { self } ).HitPos

    end

    return VecOffset

end


function UltrakillBase.RandomInSphere( self, Origin, Radius )

    local RadiusDirection = Vector()

    RadiusDirection:Random( 100 )

    RadiusDirection:Normalize()

    local RandomRadiusEdge = Vector()

    RandomRadiusEdge:Random( Radius )

    local Ray = HullRayCast( self, Origin, Origin + RadiusDirection * RandomRadiusEdge, MASK_NPCSOLID_BRUSHONLY, { self } )

    return Ray.HitPos - Origin

end


function UltrakillBase.Teleport( self, Vec, RotOffset, Ground, Callback )

    if not isentity( self ) or not IsValid( self ) then return false end

    if ( not isentity( Vec ) or not IsValid( Vec ) ) and not isvector( Vec ) then

        Vec = self:WorldSpaceCenter() + self:GetAimVector() * 50

    end

    local Origin = self:WorldSpaceCenter()

    if isentity( Vec ) and IsValid( Vec ) then Vec = Vec:WorldSpaceCenter() end
    
    local Direction = ( Vec - Origin ):GetNormalized()
    local OriginVec = Vec - Direction * CalculateCollisionRadius( self ) * 4

    local HullRay = HullRayCast( self, OriginVec, Vec, RayMasks, false, { self }, Ground )
    local Pos = HullRay.HitPos - HullRay.Normal * CalculateCollisionRadius( self ) * 1.75
    local LocalOffsetByRayCast = Pos - Vec

    LocalOffsetByRayCast:Rotate( RotOffset or EmptyAngle )

    if self:WorldSpaceCenter():DistToSqr( Vec ) <= CalculateCollisionRadius( self ) * 2 then return false end

    Pos = LocalOffsetByRayCast + Vec

    if Ground then

        Pos = GroundTeleport( self, Pos )

    end

    local Hit, HitWorld = IsBadVector( self, Pos, Ground )

    if Hit and not HitWorld then

        Pos = Resolver( self, Pos, Ground )

    elseif Hit and HitWorld then

        Pos = NavMeshResolver( self, Pos, Ground )

    end

    self:SetPos( Pos )
    self:SetVelocity( EmptyVec )

    if isfunction( Callback ) then

        Callback( self, HullRay, Pos )

    end

    return true, HullRay, Pos

end


function UltrakillBase.BypassRayCastTeleport( self, Vec, Callback )

    if not isentity( self ) or not IsValid( self ) then return false end

    if ( not isentity( Vec ) or not IsValid( Vec ) ) and not isvector( Vec ) then

        Vec = self

    end

    if isentity( Vec ) and IsValid( Vec ) then Vec = Vec:WorldSpaceCenter() end

    local Pos = Vec

    if self:WorldSpaceCenter():DistToSqr( Vec ) <= CalculateCollisionRadius( self ) * 2 then return false end

    local Hit, HitWorld = IsBadVector( self, Pos, Ground )

    if Hit and not HitWorld then

        Pos = Resolver( self, Pos, Ground )

    elseif Hit and HitWorld then

        Pos = NavMeshResolver( self, Pos, Ground )

    end

    self:SetPos( Pos )
    self:SetVelocity( EmptyVec )

    if isfunction( Callback ) then

        Callback( self, HullRay, Pos )

    end

    return true, HullRay, Pos

end