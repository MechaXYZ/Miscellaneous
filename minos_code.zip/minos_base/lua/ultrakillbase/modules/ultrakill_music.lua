
  -- Localize Libaries & Functions --


local table = table
local math = math
local net = net

local istable = istable
local Empty = table.Empty
local IsEmpty = table.IsEmpty
local Lerp = Lerp
local pairs = pairs



local function EulerCurve( x )

  return math.exp( -2 * x )

end


local function InSqrRoot( x )

  return math.sqrt( math.Clamp( x, 0, 1 ) )

end

local function OutSqrRoot( x )

  return math.sqrt( 1 - math.Clamp( x, 0, 1 ) )

end

local function LerpIn( Delta, From, To )

  return Lerp( InSqrRoot( Delta ), From, To )

end

local function LerpOut( Delta, From, To )

  return Lerp( OutSqrRoot( Delta ), From, To )

end

  -- UltrakillBase Global Functions --


if SERVER then

  function UltrakillBase.PlayMusic( self, ... )

    UltrakillBase.CallOnClient( "PlayMusic", self, ... )

  end

  function UltrakillBase.ChangeMusic( self, ... )

    UltrakillBase.CallOnClient( "ChangeMusic", self, ... )

  end

  function UltrakillBase.StopMusic( self, ... )

    UltrakillBase.CallOnClient( "StopMusic", self, ... )

  end

  function UltrakillBase.TransferMusic( self, ... )

    UltrakillBase.CallOnClient( "TransferMusic", self, ... )

  end

end

function UltrakillBase.AddMusic( ID, MusicPath, ConVar, Looping, MusicType )

  if not isstring( ID ) then return false end

  if SERVER then

    UltrakillBase.CallOnClient( "AddMusic", ID, MusicPath, ConVar, Looping, MusicType )

  end

  UltrakillBase.MusicTable[ ID ] = { String = MusicPath, ConVar = ConVar, Loop = Looping, MusicType = MusicType }

  return true

end

if CLIENT then

local VolumeConVar = CreateConVar( "drg_ultrakill_music_volume", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Music Volume." )
local MinosMusicConVar = CreateConVar( "drg_ultrakill_minosmusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Minos Prime Music" )
local SisyphusMusicConVar = CreateConVar( "drg_ultrakill_sisyphusmusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Sisyphus Prime Music" )
local CerberusMusicConVar = CreateConVar( "drg_ultrakill_cerberusmusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Cerberus Music" )
local SwordsMachineMusicConVar = CreateConVar( "drg_ultrakill_swordsmachinemusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables SwordsMachine Music" )
local MaliciousFaceMusicConVar = CreateConVar( "drg_ultrakill_maliciousfacemusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Malicious Face Music" )
local HideousMassMusicConVar = CreateConVar( "drg_ultrakill_hideousmassmusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Hideous Mass Music" )
local GabrielMusicConVar = CreateConVar( "drg_ultrakill_gabrielmusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Gabriel Music" )
local FleshPanMusicConVar = CreateConVar( "drg_ultrakill_fleshpanopticonmusic", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Flesh Panopticon Music" )

UltrakillBase.MusicTable = UltrakillBase.MusicTable or {}

UltrakillBase.AddMusic( "ORDER", "ultrakill/music/Minos Prime.wav", MinosMusicConVar )
UltrakillBase.AddMusic( "ORDER_Intro", "ultrakill/music/Minos Prime Intro.wav", MinosMusicConVar, false )

UltrakillBase.AddMusic( "PANDEMONIUM", "ultrakill/music/Flesh Panopticon.wav", FleshPanMusicConVar, nil, 2 )

UltrakillBase.AddMusic( "WAR", "ultrakill/music/Sisyphus Prime.wav", SisyphusMusicConVar )
UltrakillBase.AddMusic( "WAR_Intro", "ultrakill/music/Sisyphus Prime Intro.wav", SisyphusMusicConVar, false )

UltrakillBase.AddMusic( "CerberusA", "ultrakill/music/Cerberus A.wav", CerberusMusicConVar )
UltrakillBase.AddMusic( "CerberusB", "ultrakill/music/Cerberus B.wav", CerberusMusicConVar )

UltrakillBase.AddMusic( "0-2", "ultrakill/music/0-2.wav", SwordsMachineMusicConVar )
UltrakillBase.AddMusic( "0-1", "ultrakill/music/0-1.wav", MaliciousFaceMusicConVar )

UltrakillBase.AddMusic( "1-3", "ultrakill/music/1-3.wav", HideousMassMusicConVar )

UltrakillBase.AddMusic( "3-2", "ultrakill/music/Gabriel 3-2.wav", GabrielMusicConVar )

UltrakillBase.AddMusic( "P-2", "ultrakill/music/P-2.wav" )
UltrakillBase.AddMusic( "P-2 Clean", "ultrakill/music/P-2 Clean.wav" )

DrGBase.IncludeFolder( "ultrakillbase/Includes/CustomMusic" )

if UltrakillBase.IsLinux then

  return DrGBase.IncludeFile( "ultrakillbase/Includes/CustomCode/Ultrakill_Music/Linux.lua" ) -- Linux Compatibility, probably.

end

local MusicStack = {}
local CurrentChannel = {}
local PreviousChannel = {}
local CurrentFadeInTrack = {}
local CurrentFadeOutTrack = {}

local function CheckConVarTable( String )

  if not isstring( String ) then return end

  for I, V in pairs( UltrakillBase.MusicTable ) do

    if String == I and V.ConVar ~= nil then

      return V.ConVar:GetBool()

    end

  end

  return true

end

local function IsChannelValid( Channel )

  return not IsEmpty( Channel ) and istable( Channel ) and IsValid( Channel.Audio )

end

local function IsNextMusicValid()

  if #MusicStack <= 0 then return false end

  local Data = MusicStack[ 1 ]

  return IsValid( Data[ 1 ] ) and #MusicStack > 0

end

local function FadeInMusic( Audio ) -- Internal function.

  if not IsEmpty( CurrentFadeInTrack ) then return false end -- Already Fading in a track.

  CurrentFadeInTrack = {

    Audio = Audio,
    InitTime = CurTime(),

  }

  return true

end

local function FadeOutMusic( Audio ) -- Internal function.

  if not IsEmpty( CurrentFadeOutTrack ) then return false end -- Already Fading out a track.

  CurrentFadeOutTrack = {

    Audio = Audio,
    InitTime = CurTime(),

  }

  return true

end

function UltrakillBase.PlayMusic( self, Name, Time, Fade )

  if not CheckConVarTable( Name ) or not IsValid( self ) or ( IsValid( self ) and self.IsDrGNextbot and self:IsDead() ) or not istable( UltrakillBase.MusicTable[ Name ] ) then return false end

  if IsChannelValid( CurrentChannel, true ) then

    table.insert( MusicStack, { self, Name, Time } )

    return true

  end

  local Looping = UltrakillBase.MusicTable[ Name ].Loop
  local SoundParm = ( isnumber( Time ) and Time <= 0 ) and "noblock" or ""

  sound.PlayFile( "sound/" .. UltrakillBase.MusicTable[ Name ].String, SoundParm .. "noplay", function( Audio, ErrorCode, ErrorName )

    if not IsValid( Audio ) then

      if GetConVar( "developer" ):GetInt() >= 1 then

        DrGBase.Error( "UltrakillBase.Music has failed to play Music: " .. UltrakillBase.MusicTable[ Name ].String .. " ErrorCode: " .. tostring( ErrorCode ) .. " ErrorString: " .. ErrorName, { chat = true } ) 

      end

      return false

    end

    Audio:SetVolume( 0 )
    Audio:EnableLooping( Looping or true )
    Audio:SetTime( Time or 0, true )
    Audio:Play()

    CurrentChannel = { Audio = Audio, Ent = self, Name = Name, PauseTime = 0 }

    if Fade and IsEmpty( CurrentFadeInTrack ) then

      FadeInMusic( CurrentChannel.Audio )

    end

  end )

end

local function PlayNextMusic()

  if #MusicStack <= 0 then return end -- Is it Empty?

  local Data = table.remove( MusicStack, 1 )

  if not IsValid( Data[1] ) or not isstring( Data[2] ) then
  
    return PlayNextMusic()
  
  end
  
  UltrakillBase.PlayMusic( Data[1], Data[2], Data[3], true ) -- Call Play Func

end

function UltrakillBase.TransferOwnershipMusic( self, Owner )

  if IsEmpty( CurrentChannel ) or not IsValid( Owner ) or self ~= CurrentChannel.Ent then return end

  CurrentChannel.Ent = Owner

end

function UltrakillBase.StopMusic( self, Name, BypassStack, Fade )

  local Data = MusicStack[ 1 ]

  if istable( Data ) and Data[ 1 ] == self and Data[ 2 ] == Name then

    table.remove( MusicStack, 1 )

  end

  if not IsValid( CurrentChannel.Audio ) or IsValid( CurrentChannel.Ent ) and CurrentChannel.Ent ~= self then return end

  Fade = Fade or IsNextMusicValid()

  if not Fade or not IsEmpty( CurrentFadeOutTrack ) then

    CurrentChannel.Audio:Stop()

  else

    PreviousChannel = table.Copy( CurrentChannel )
    FadeOutMusic( PreviousChannel.Audio )

  end

  Empty( CurrentChannel )

  if BypassStack ~= true then

    PlayNextMusic() -- Check MusicStack for Next music?

  end

end

function UltrakillBase.ChangeMusic( self, From, To, Fading )

  if CurrentChannel.Name ~= From and IsValid( CurrentChannel.Audio ) then 

    return UltrakillBase.PlayMusic( self, To, 0, Fading )

  end

  UltrakillBase.StopMusic( self, From, true, Fading )
  UltrakillBase.PlayMusic( self, To, 0, Fading )

end

local function ProcessFadeIn()

  if not IsChannelValid( CurrentChannel ) or IsEmpty( CurrentFadeInTrack ) then return 1 end

  local Delta = ( CurTime() - CurrentFadeInTrack.InitTime ) / 1.5

  local Volume = LerpIn( Delta, 0, 1 )

  if Delta >= 1 then

    Empty( CurrentFadeInTrack )

  end

  return Volume

end

local function ProcessFadeOut()

  if not IsChannelValid( PreviousChannel ) or IsEmpty( CurrentFadeOutTrack ) then return 1 end

  local Delta = ( CurTime() - CurrentFadeOutTrack.InitTime ) / 1.5

  local Volume = LerpOut( Delta, 0, 1 )

  if Delta >= 1 then

    Empty( CurrentFadeOutTrack )
    PreviousChannel.Audio:Stop() -- Delete Audio when FadeOut is finished.
    Empty( PreviousChannel )

  end

  return Volume

end

local MufflingInitTime = 0

local function ProcessMuffling()
  
  if game.SinglePlayer() and ( gui.IsGameUIVisible() or gui.IsConsoleVisible() ) then

    MufflingInitTime = SysTime()

  end

  local MufflingDelta = ( SysTime() - MufflingInitTime ) / 1

  local MufflingVolume = Lerp( MufflingDelta, 0.2, 1 )
  local MufflingPitch = Lerp( MufflingDelta, 0.6, 1 )

  return MufflingVolume, MufflingPitch

end

local TypeEnums = {

  [ 1 ] = "FleshPrison",
  [ 2 ] = "FleshPanopticon"

}

local PitchUpInitTime = nil
local PitchUpEntityAttach = nil

local function ResetPitchUp()

  if isnumber( PitchUpInitTime ) and not IsValid( PitchUpEntityAttach ) then

    PitchUpInitTime = nil
    PitchUpEntityAttach = nil

  end

end

local HoldTime = 3.5

local function ProcessFleshPrison2Music ()

  if not IsChannelValid( CurrentChannel ) or ( IsValid( CurrentChannel.Ent ) and CurrentChannel.Ent.IsUltrakillNextbot and not CurrentChannel.Ent:IsDead() and not CurrentChannel.Ent:IsDying() ) then return 1 end

  PitchUpEntityAttach = CurrentChannel.Ent
  PitchUpInitTime = PitchUpInitTime or CurTime()

  local Pitch = 0.01
  local TimeDiff = CurTime() - PitchUpInitTime

  if TimeDiff > HoldTime and TimeDiff < HoldTime + 2 then

    Pitch = 0.5

  elseif TimeDiff > HoldTime + 2 then

    Pitch = Lerp( ( CurTime() - ( PitchUpInitTime + HoldTime + 2 ) ) / 3, 0.5, 2 )

  end

  return Pitch

end

local function ProcessFleshPrisonMusic( )

  if not IsChannelValid( CurrentChannel ) or ( IsValid( CurrentChannel.Ent ) and CurrentChannel.Ent.IsUltrakillNextbot and not CurrentChannel.Ent:IsDead() and not CurrentChannel.Ent:IsDying() ) then return 1 end
  if not UltrakillBase.MusicTable[ CurrentChannel.Name ].MusicType then return 1 end

  PitchUpEntityAttach = CurrentChannel.Ent

  local Type = UltrakillBase.MusicTable[ CurrentChannel.Name ].MusicType

  if Type == 2 then return ProcessFleshPrison2Music() end

  PitchUpInitTime = PitchUpInitTime or CurTime()

  local Pitch = Lerp( ( CurTime() - PitchUpInitTime ) / 5, 1, 2 )

  return Pitch

end

hook.Add( "Tick", "UltrakillBase_Music_Update", function()

  local Audio = CurrentChannel.Audio
  local PrevAudio = PreviousChannel.Audio

  local Volume = system.HasFocus() and VolumeConVar:GetFloat() * 1 or 0
  local Pitch = CurrentChannel.Pitch or 1
  local PrevPitch = PreviousChannel.Pitch or 1
  local Timescale = game.GetTimeScale() or 1

  -- CrossFading --

  local FadeInVolume = ProcessFadeIn()
  local FadeOutVolume = ProcessFadeOut()

  local MuffleAudioVolume, MuffleAudioPitch = ProcessMuffling()

  ResetPitchUp()

  local FleshPrisonPitch = ProcessFleshPrisonMusic()

  -- Update Audio --

  if IsValid( Audio ) then

    Audio:SetVolume( Volume * FadeInVolume * MuffleAudioVolume )
    Audio:SetPlaybackRate( Pitch * Timescale * MuffleAudioPitch * FleshPrisonPitch )

  end

  if IsValid( PrevAudio ) then

    PrevAudio:SetVolume( Volume * FadeOutVolume * MuffleAudioVolume )
    PrevAudio:SetPlaybackRate( PrevPitch * Timescale * MuffleAudioPitch )

  end

end )

end