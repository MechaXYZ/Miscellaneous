
  -- Localize Libaries & Functions --


local table = table
local math = math
local game = game
local net = net

local istable = istable
local Lerp = Lerp
local SysTime = SysTime
local GetTimeScale = game.GetTimeScale
local SetTimeScale = game.SetTimeScale



if SERVER then

local SlowMotionConVar = CreateConVar( "drg_ultrakill_slowmo", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enables Slow Motion Effect." )
local HitStopConVar = CreateConVar( "drg_ultrakill_hitstop", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enables Parry HitStop Effect." )

local TimeManipulationOperation = {}
local TimeMult = 0.1
local OldTimeScale = 1


function UltrakillBase.HitStop( Time )

  if not HitStopConVar:GetBool() then return end

  TimeManipulationOperation = { InitTime = SysTime(), Time = Time, Type = 2 }

end



function UltrakillBase.SlowMotion( Time, HoldTime )

  if not SlowMotionConVar:GetBool() then return end
  if not isnumber( HoldTime ) then HoldTime = 0 end

  TimeManipulationOperation = { InitTime = SysTime() + HoldTime, Time = Time, Type = 1 }

end



local function ShouldDilate()

  return not table.IsEmpty( TimeManipulationOperation )

end



local function CheckTime( InitTime, Time )

  return Lerp( ( SysTime() - InitTime ) / Time, 0, 1 ) >= 1

end


local function ProcessTimeManipulation()

  if not istable( TimeManipulationOperation ) or table.IsEmpty( TimeManipulationOperation ) then return 1 end

  local Type = TimeManipulationOperation.Type
  local Time = TimeManipulationOperation.Time
  local InitTime = TimeManipulationOperation.InitTime

  if Type == 2 then -- HitStop

    return Lerp( ( SysTime() - ( InitTime + Time ) ) / engine.TickInterval(), TimeMult, 1 )

  end

  return Lerp( ( SysTime() - InitTime ) / Time, TimeMult, 1 ) -- SlowMotion

end




hook.Add( "Think", "UltrakillBase_TimeDilation", function()

  local TimeManip = math.max( ProcessTimeManipulation(), TimeMult )

  if ShouldDilate() then

    SetTimeScale( TimeManip )

  end

  if istable( TimeManipulationOperation ) and not table.IsEmpty( TimeManipulationOperation ) and CheckTime( TimeManipulationOperation.InitTime + 0.1, TimeManipulationOperation.Time ) then

    table.Empty( TimeManipulationOperation )

  end

end )



end -- SERVER END

