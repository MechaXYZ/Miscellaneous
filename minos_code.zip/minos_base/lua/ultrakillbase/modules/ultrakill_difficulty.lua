UltrakillBase.ConVars = UltrakillBase.ConVars or {}

UltrakillBase.ConVars.Difficulty = CreateConVar( "drg_ultrakill_difficulty", "VIOLENT", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Ultrakill Difficulty( Enemy Speed )" )

local DifficultyEnums = {

  [ "HARMLESS" ] = 1,
  [ "LENIENT" ] = 2,
  [ "STANDARD" ] = 3,
  [ "VIOLENT" ] = 4,
  [ "BRUTAL" ] = 5,
  [ "ULTRAKILL MUST DIE" ] = 6,
  [ "HIDDEN MANSION" ] = 7,

}

-- Massive Data Dump --
-- This Data is Global --

local DifficultyInformation = {

  Rate = {

    0.75,
    0.85,
    0.9,
    1,
    1,
    1.1,
    9000

  },

  Healing = {

    { Percentage = 0, Delay = 1 },
    { Percentage = 0, Delay = 1 },
    { Percentage = 0.35, Delay = 1 },
    { Percentage = 0.35, Delay = 2 },
    { Percentage = 0.5, Delay = 2.5 },
    { Percentage = 0.75, Delay = 2.5 }

  },

  MaliciousFace = {

    { Barrage = 3, ChargeTime = 5 },
    { Barrage = 4, ChargeTime = 3.5 },
    { Barrage = 6, ChargeTime = 3.5 },
    { Barrage = 6, ChargeTime = 2 },
    { Barrage = 8, ChargeTime = 1.5 },
    { Barrage = 10, ChargeTime = 1.5 }

  },

  MinosPrime = {

    { Stamina = 6, Phase2Mult = 1, ParryablePhase2 = true, StaminaRecovery = 4 },
    { Stamina = 6, Phase2Mult = 1, ParryablePhase2 = true, StaminaRecovery = 3 },
    { Stamina = 6, Phase2Mult = 2, ParryablePhase2 = true, StaminaRecovery = 2 },
    { Stamina = 10, Phase2Mult = 10000, ParryablePhase2 = false, StaminaRecovery = 2 },
    { Stamina = 20, Phase2Mult = 10000, ParryablePhase2 = false, StaminaRecovery = 1 },
    { Stamina = 10000, Phase2Mult = 2, ParryablePhase2 = false, StaminaRecovery = 1 }

  },

  SisyphusPrime = {

    { Stamina = 6, Phase2Mult = 1, StaminaRecovery = 4, ParryablePhase2 = true },
    { Stamina = 6, Phase2Mult = 1, StaminaRecovery = 3, ParryablePhase2 = true },
    { Stamina = 6, Phase2Mult = 1.66666667, StaminaRecovery = 2, ParryablePhase2 = true },
    { Stamina = 8, Phase2Mult = 2, StaminaRecovery = 2, ParryablePhase2 = true },
    { Stamina = 12, Phase2Mult = 2, StaminaRecovery = 1, ParryablePhase2 = false },
    { Stamina = 18, Phase2Mult = 10000, StaminaRecovery = 1, ParryablePhase2 = false }

  },

  Gabriel = {

    { Taunt = 3, MaxFollowUps = 2 },
    { Taunt = 3, MaxFollowUps = 2 },
    { Taunt = 3, MaxFollowUps = 2 },
    { Taunt = 4, MaxFollowUps = 2 },
    { Taunt = 5, MaxFollowUps = 3 },
    { Taunt = 6, MaxFollowUps = 4 }

  },

  Soldier = {

    { Shotgun = {
      Vector( 0, 0, 0 ),
      Vector( 0, 1, 0 ),
      Vector( 0, -1, 0 ),
      Vector( 0, 0, 1 ),
      Vector( 0, 0, -1 )
    } },

    nil,

    nil,

    { Shotgun = {
      Vector( 0, 0, 0 ),
      Vector( 0, 0.951057, -0.309017 ),
      Vector( 0, 0.587785, 0.809017 ),
      Vector( 0, -0.587785, 0.809017 ),
      Vector( 0, -0.951057, -0.309017 ),
      Vector( 0, 0, -1 )
    } },

    { Shotgun = {
      Vector( 0, 0, 0 ),
      Vector( 0, 0.707107, 0.707107 ),
      Vector( 0, 0, 1 ),
      Vector( 0, -0.707107, 0.707107 ),
      Vector( 0, -1, 0 ),
      Vector( 0, -0.707107, -0.707107 ),
      Vector( 0, 0, -1 ),
      Vector( 0, 0.707107, -0.707107 ),
      Vector( 0, 1, 0 )
    } }

  },

}

function UltrakillBase.DifficultyGetInformation( Class, ForceEnum )

  local DifficultyEnum = isnumber( ForceEnum ) and ForceEnum or UltrakillBase.DifficultyToEnum( UltrakillBase.ConVars.Difficulty:GetString() )

  local Information = DifficultyInformation[ Class ][ DifficultyEnum ]

  if not Information and DifficultyEnum > 0 then

    return UltrakillBase.DifficultyGetInformation( Class, DifficultyEnum - 1 )

  end

  return Information

end

function UltrakillBase.DifficultyToEnum( String )
  
  return DifficultyEnums[ String ] or 3 -- VIOLENT is default.

end

function UltrakillBase.DifficultyCompare( Compare )

  if not isnumber( Compare ) and not isstring( Compare ) then return end

  local Current = UltrakillBase.DifficultyToEnum( UltrakillBase.ConVars.Difficulty:GetString() )

  if isstring( Compare ) then Compare = UltrakillBase.DifficultyToEnum( Compare ) end

  return Current >= Compare

end