
  -- Localize Libaries & Functions --


local draw = draw
local surface = surface
local table = table
local math = math
local net = net
local Insert = table.insert

local Lerp = Lerp
local ipairs = ipairs
local ScrH = ScrH
local ScrW = ScrW
local InCubic = math.ease.InCubic
local OutCubic = math.ease.OutCubic

local HoldTimePerChar = 0.11
local FadeInPerChar = 0.0025
local FadeOutPerChar = 0.005
local BaseFadeIn = 0.2
local BaseHoldTime = 1.5
local BaseFadeOut = 2
local SubtitlesPerRender = 12

local SubtitleBGColor = Color( 0, 0, 0, 130 )
local SubtitleTextColor = Color( 255, 255, 255, 255 )

UltrakillBase.SubtitlesTable = UltrakillBase.SubtitlesTable or {}

local Subtitles = UltrakillBase.SubtitlesTable

function UltrakillBase.Subtitle( Text, HoldTime )

  if not isstring( Text ) then return end

  if CLIENT then

    Insert( Subtitles, 1, { String = Text, Now = CurTime(), HoldTime = HoldTime } )

    return

  end

  UltrakillBase.CallOnClient( "Subtitle", Text, HoldTime )

end


if CLIENT then


local SubtitleConVar = CreateConVar( "drg_ultrakill_subtitles", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Subtitles." )

  
hook.Add( "HUDPaint", "UltrakillBase_Subtitles", function()
  
  if not SubtitleConVar:GetBool() then return end

  for Index, Data in ipairs( Subtitles ) do
  
    local Text = Data.String
    local Now = Data.Now

    local HoldTime = Data.HoldTime and Data.HoldTime or BaseHoldTime + #Text * HoldTimePerChar
    local FadeIn = BaseFadeIn + #Text * FadeInPerChar
    local FadeOut = BaseFadeOut + #Text * FadeOutPerChar

    local LerpFadeOut = Lerp( OutCubic( ( CurTime() - ( Now + HoldTime + FadeIn ) ) / FadeOut ), 1, 0 )
    local LerpFadeIn = Lerp( InCubic( ( CurTime() - Now ) / FadeIn ), 0, 1 )

    local SmoothAlpha = LerpFadeOut * LerpFadeIn

    if SmoothAlpha <= 0 and CurTime() - Now > FadeIn then

      table.remove( Subtitles, Index )

      continue

    end

    if Index > SubtitlesPerRender then continue end

    surface.SetFont( "Ultrakill_SubFont" )

    local TextWidth, TextHeight = surface.GetTextSize( Text )

    local PosX = ScrW() * 0.5
    local PosY = ( ScrH() * 0.860215054 ) - ( ( Index - 1 ) * ScrH() * 0.0714285714 )

    local ScaleW = ( TextWidth / #Text * 1.5 ) + TextWidth * 1.05
    local ScaleH = ScrH() * 0.0625 * 0.925

    SubtitleBGColor.a = 130 * SmoothAlpha
    SubtitleTextColor.a = 255 * SmoothAlpha

    draw.RoundedBox( 8, PosX - ScaleW * 0.5, PosY - ScaleH * 0.881057269, ScaleW, ScaleH, SubtitleBGColor )
    draw.DrawText( Text, "Ultrakill_SubFont", PosX, PosY - ScaleH * 0.606060606, SubtitleTextColor, TEXT_ALIGN_CENTER )

  end

end )
  

  
end

