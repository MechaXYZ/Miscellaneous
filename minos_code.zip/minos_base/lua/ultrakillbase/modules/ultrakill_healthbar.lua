
  -- Localize Libaries & Functions --


local table = table
local math = math
local net = net
local draw = draw
local surface = surface

local istable = istable
local Lerp = Lerp
local ipairs = ipairs
local OutCubic = math.ease.OutCubic

local HealthLostColor = Color( 255, 161, 0, 255 )
local HealthColor = Color( 255, 0, 0, 255 )
local HealthGainedColor = Color( 0, 255, 0, 255)
local BackgroundColor = Color( 0, 0, 0, 99.45 )
local HealthBackgroundColor = Color( 0, 0, 0, 170 )

UltrakillBase.DefaultSecondaryBarColor = Color( 0, 255, 0, 255 )
UltrakillBase.DefaultSecondaryBarEnragedColor = Color( 255, 0, 0, 255 )
UltrakillBase.DefaultSecondaryBarBlackColor = Color( 0, 0, 0, 255 )
UltrakillBase.DefaultSecondaryBarYellowColor = Color( 255, 255, 0, 255 )

local DefaultSecondaryBarFunction = function( self )

  return 0, UltrakillBase.DefaultSecondaryBarColor

end


local MaxHealthBarsPerRender = 12

UltrakillBase.BossTable = UltrakillBase.BossTable or {}
UltrakillBase.BossEntityData = UltrakillBase.BossEntityData or {}

local BossTable = UltrakillBase.BossTable
local BossEntityData = UltrakillBase.BossEntityData


function UltrakillBase.AddBoss( self, Title, Splits, UseSecondary )

  if not isentity( self ) or not IsValid( self ) then return end

  if CLIENT then

    BossTable[ #UltrakillBase.BossTable + 1 ] = self
    BossEntityData[ self ] = {

      MainBar = { },
      SecondaryBar = { },
      Title = Title,
      Splits = Splits,
      UseSecondary = UseSecondary,

    }

    return

  end

  Title = isstring( Title ) and Title or self:GetClass()

  Splits = Splits or 1

  UltrakillBase.CallOnClient( "AddBoss", self, Title, Splits, UseSecondary )

  return true

end


function UltrakillBase.RemoveBoss( self )

  if not isentity( self ) or not IsValid( self ) then return end

  if CLIENT then

    local Key = table.KeyFromValue( BossTable, self )

    table.remove( BossTable, Key )
    BossEntityData[ self ] = nil

    return

  end

  UltrakillBase.CallOnClient( "RemoveBoss", self )

end



if CLIENT then

local HealthBarConVar = CreateConVar( "drg_ultrakill_healthbar", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Boss HP Bar" )

local Darken = {

  1,
  0.552941176,
  0.452941176,
  0.352941176,
  0.252941176,
  0.152941176,
  0.052941176,

}

  -- Hud Functions --


local function HudInitHealthBars( Ent )

  local EntityData = BossEntityData[ Ent ]
  local MainData = EntityData.MainBar

  if not IsValid( Ent ) or MainData.Initialized then return end

  local Splits = EntityData.Splits

  MainData.Intro = true
  MainData.DieTime = CurTime()
  MainData.HPGainedTime = 0
  MainData.LerpTime = 1.25
  MainData.LerpTime_Lost = 1.25
  MainData.CurHP = Ent:Health()
  MainData.CurHP_Lost = Ent:Health()
  MainData.PrevHP = 0
  MainData.PrevHP_Lost = 0
  MainData.Delay = 0
  MainData.Segmented = {}

  if Splits > 0 then

    for X = Splits, 1, -1 do

      MainData.Segmented[ #MainData.Segmented + 1 ] = {

        Threshold = X / Splits,
        Number = X,

      }

    end

  end

  timer.Simple( MainData.LerpTime, function( )

    if not MainData.Intro then return end

    MainData.Intro = false
    MainData.PrevHP = MainData.CurHP
    MainData.PrevHP_Lost = MainData.CurHP_Lost

  end )

  MainData.Initialized = true

end


local function HudHealthCalculations( Ent, HP, MaxHP, LerpHP, LerpHP_Lost, Gained )

  local EntityData = BossEntityData[ Ent ]
  local MainData = EntityData.MainBar

  -- Intro --
  
  if MainData.Intro then
  
    if HP ~= MaxHP then
  
      MainData.CurHP_Lost = HP
      MainData.CurHP = HP
  
    end
  
  end
  
  -- HP Calculation --
  
  if MainData.CurHP ~= HP then -- HP has Changed.
  
    if LerpHP ~= HP then -- HP Changed During Animation.

      MainData.CurHP = LerpHP -- Adjust HP Variable.

    end
  
    if not MainData.Intro then

      MainData.LerpTime = 0.1

    end

    if MainData.CurHP < HP then -- HP Gained?

      MainData.LerpTime = 0.2
      MainData.HPGainedTime = CurTime()

    end

    MainData.PrevHP = MainData.CurHP

    MainData.DieTime = CurTime()
    MainData.CurHP = HP

  end
  
  -- HP Lost Calculation --

  if MainData.CurHP_Lost ~= HP then -- HP has Changed.
  
    if LerpHP_Lost ~= HP then -- HP Changed During Animation.

      MainData.CurHP_Lost = LerpHP_Lost -- Adjust HP Variable.

    end
  
    if not MainData.Intro then

      MainData.LerpTime_Lost = math.Clamp( ( LerpHP_Lost - HP ) / ( 0.2 * MaxHP ), 0.1, 0.65 )
      MainData.Delay = math.Clamp( ( LerpHP_Lost - HP ) / ( 0.45 * MaxHP ), 0.25, 0.45 )

    end

    MainData.PrevHP_Lost = MainData.CurHP_Lost
    MainData.CurHP_Lost = HP

  end

end


local function HudRenderHealthBars( Ent, BarPos_X, BarPos_Y, BarScale_X, BarScale_Y, BarPos_Y_NoStacking, RandomShake, LerpHP, LerpHP_Lost, LerpGain, MaxHP, Gained )


  local EntityData = BossEntityData[ Ent ]
  local MainData = EntityData.MainBar
  local Splits = EntityData.Splits

  for X = Splits, 1, -1 do
  
    local Segment = MainData.Segmented[ X ] or {}
    local NextSegment = MainData.Segmented[ X + 1 ]
    local ColorMult = Darken[ Segment.Number ] or 0

    HealthColor.r = 255 * ( ColorMult ^ 1.2 )

    if NextSegment ~= Segment and NextSegment ~= nil then 

      Segment.Data = {

        HP = math.Clamp( LerpHP / MaxHP, NextSegment.Threshold, Segment.Threshold ),
        HP_Lost = math.Clamp( LerpHP_Lost / MaxHP, NextSegment.Threshold, Segment.Threshold ),

        Max = Segment.Threshold,
        Min = NextSegment.Threshold

      }

    else

      Segment.Data = {

        HP = math.Clamp( LerpHP / MaxHP , 0, Segment.Threshold ),
        HP_Lost = math.Clamp( LerpHP_Lost / MaxHP , 0, Segment.Threshold ),

        Max = Segment.Threshold,
        Min = 0

      }

    end

    local Delta = math.Remap( Segment.Data.HP, Segment.Data.Min, Segment.Data.Max, 0, 1 )
    local Delta_Lost = math.Remap( Segment.Data.HP_Lost, Segment.Data.Min, Segment.Data.Max, 0, 1 )
    local Delta_Gain = math.Remap( math.Clamp( LerpGain / MaxHP, Segment.Data.Min, Segment.Data.Max ), Segment.Data.Min, Segment.Data.Max, 0, 1 )

    if Delta <= 0 and Delta_Lost <= 0 then -- Stop Rendering. ( Little bit of optimization )

      continue

    end

    if Delta < Delta_Lost and Gained <= 0 then

      draw.RoundedBox( 6, BarPos_X, BarPos_Y + RandomShake, BarScale_X * Delta_Lost, BarScale_Y, HealthLostColor )

    end

    draw.RoundedBox( 6, BarPos_X, BarPos_Y + RandomShake, BarScale_X * Delta, BarScale_Y, HealthColor )

    local GainScaleMult = Lerp( Gained, 1, 1.3 )
    HealthGainedColor.a = Lerp( Gained ^ 0.65, 0, 255 )

    if Delta_Gain < 1 then

      draw.RoundedBox( 6, BarPos_X, BarPos_Y - ( BarPos_Y_NoStacking * ( GainScaleMult - 1 ) ) + RandomShake, BarScale_X * Delta, BarScale_Y * GainScaleMult, HealthGainedColor )

    end

  end

end


local function HudInitSecondaryBars( Ent )

  local EntityData = BossEntityData[ Ent ]
  local SecondaryData = EntityData.SecondaryBar

  if not IsValid( Ent ) or not EntityData.UseSecondary or SecondaryData.Initialized then return end

  local DeclareFunction = Ent.GetSecondaryBarValues or DefaultSecondaryBarFunction

  SecondaryData.DieTime = CurTime()
  SecondaryData.LerpTime = 0.2
  SecondaryData.CurValue = DeclareFunction( Ent ) -- Declare this Function on Client to set your way of determining values for the secondary bar.
  SecondaryData.PrevValue = 0

end

local function HudRenderSecondaryBars( Ent, RandomShake, PosX, PosY, ScaleW, ScaleH )

  local EntityData = BossEntityData[ Ent ]
  local SecondaryData = EntityData.SecondaryBar

  if not EntityData.UseSecondary then return end

  local DeclareFunction = Ent.GetSecondaryBarValues or DefaultSecondaryBarFunction

  local NowValue, BarCol = DeclareFunction( Ent )

  local Fraction = OutCubic( math.Clamp( ( CurTime() - SecondaryData.DieTime ) / SecondaryData.LerpTime, 0, 1 ) )
  local LerpValue = math.Clamp( Lerp( Fraction, SecondaryData.PrevValue, SecondaryData.CurValue ), 0, 1 )

  if SecondaryData.CurValue ~= NowValue then

    if LerpValue ~= NowValue then

      SecondaryData.CurValue = LerpValue

    end

    SecondaryData.PrevValue = SecondaryData.CurValue
    SecondaryData.DieTime = CurTime()
    SecondaryData.CurValue = NowValue

  end

  local BarPos_X = PosX - ScaleW * 0.483775937
  local BarPos_Y = PosY + ScaleH * 0.71

  local BarScale_X = ScaleW * 0.971276
  local BarScale_Y = ScaleH * 0.1

  draw.RoundedBox( 6, BarPos_X, BarPos_Y + RandomShake, BarScale_X, BarScale_Y, HealthBackgroundColor )
  draw.RoundedBox( 6, BarPos_X, BarPos_Y + RandomShake, BarScale_X * LerpValue, BarScale_Y, BarCol or DefaultSecondaryBarColor )

end


local function HudBarShaking( HP, LerpHP_Lost, MaxHP )

  local ShakeHPLost = math.Clamp( ( LerpHP_Lost - HP ) / ( MaxHP * 0.05 ), 0 , 8 )
  local ScreenAvgDelta = UltrakillBase.ScreenAverageClamped() / 1500
  local RandomShake = HP <= 0 and math.Clamp( math.random( -8, 8 ) * ScreenAvgDelta, -8, 8 ) or math.Clamp( math.random( -ShakeHPLost, ShakeHPLost ) * ScreenAvgDelta, -8, 8 )

  return RandomShake

end


  -- Hud Painting --

  
hook.Add( "HUDPaint", "UltrakillBase_HealthBar", function()

  if not HealthBarConVar:GetBool() then return end

  for Key, Ent in ipairs( BossTable ) do

    if not IsValid( Ent ) then

      table.remove( BossTable, Key ) -- Remove it.
      BossEntityData[ Ent ] = nil

      continue

    end

    HudInitHealthBars( Ent )
    HudInitSecondaryBars( Ent )

    local EntityData = BossEntityData[ Ent ]
    local MainData = EntityData.MainBar

    local HP = Ent:Health()
    local MaxHP = Ent:GetMaxHealth()

    local Fraction = OutCubic( math.Clamp( ( CurTime() - MainData.DieTime ) / MainData.LerpTime, 0, 1 ) )
    local Fraction_Lost = OutCubic( math.Clamp( ( CurTime() - ( MainData.DieTime + MainData.Delay ) ) / MainData.LerpTime_Lost, 0, 1 ) )
    local Fraction_Gained = OutCubic( 1 - math.Clamp( ( CurTime() - MainData.HPGainedTime ) / 0.6, 0, 1 ) )

    local LerpHP = Lerp( Fraction, MainData.PrevHP, MainData.CurHP )
    local LerpHP_Lost = Lerp( Fraction_Lost, MainData.PrevHP_Lost, MainData.CurHP_Lost )
    local LerpGain = Lerp( Fraction_Gained, MainData.PrevHP, MainData.CurHP )

    HudHealthCalculations( Ent, HP, MaxHP, LerpHP, LerpHP_Lost, Fraction_Gained )

    if Key > MaxHealthBarsPerRender then continue end

    local RandomShake = HudBarShaking( HP, LerpHP_Lost, MaxHP )

    local PosX = ScrW() * 0.5
    local PosY = ( ScrH() * 0.0333333333 ) + ( ( Key - 1 ) * ( ScrH() * 0.096153846 ))

    local ScaleW = ScrW() * 0.934579439
    local ScaleH = ScrH() * 0.0763491237

    local BackgroundPos_X = PosX - ScaleW * 0.5
    local BackgroundPos_Y = PosY - ScaleH * 0.25

    local BarPos_X = PosX - ScaleW * 0.483675937
    local BarPos_Y = PosY - ScaleH * 0.0952380952
    local BarPos_Y_NoStacking = ( ScrH() * 0.0333333333 ) - ScaleH * 0.0952380952

    local BarScale_X = ScaleW * 0.971276
    local BarScale_Y = ScaleH * 0.727848

    local TextPos_X = PosX * 1.005
    local TextPos_Y = PosY

    local Additive_BackgroundScale_H = EntityData.UseSecondary and ScrH() * 0.0125 or 0

    draw.RoundedBox( 2, BackgroundPos_X, BackgroundPos_Y, ScaleW, ScaleH + Additive_BackgroundScale_H, BackgroundColor )
    draw.RoundedBox( 6, BarPos_X, BarPos_Y + RandomShake, BarScale_X, BarScale_Y, HealthBackgroundColor )

    -- Secondary Bars --

    HudRenderSecondaryBars( Ent, RandomShake, PosX, PosY, ScaleW, ScaleH )

    -- Health Bars --

    HudRenderHealthBars( Ent, BarPos_X, BarPos_Y, BarScale_X, BarScale_Y, BarPos_Y_NoStacking, RandomShake, LerpHP, LerpHP_Lost, LerpGain, MaxHP, Fraction_Gained )

    -- Boss Name --
  
    draw.DrawText( EntityData.Title, "Ultrakill_Font", TextPos_X + RandomShake, TextPos_Y + RandomShake, color_white, TEXT_ALIGN_CENTER )
  
    end -- End of For K, V
  
  end ) -- End of HudPaint


    
end

