if not istable( ENT ) then return end

if SERVER then



local function CreateParticleEffect( String, Data ) -- Mostly the same as DrGBase.ParticleEffect with some changes.

  if not isstring( String ) or not istable( Data ) then return end

  local Main = ents.Create( "info_particle_system" )

  if not IsValid( Main ) then return NULL end

  Main:SetKeyValue( "effect_name", String )

  Main:SetName( "drg_info_particle_system_" .. Main:GetCreationID() )

  if isvector( Data.pos ) then Main:SetPos( Data.pos ) end
  if isangle( Data.ang ) then Main:SetAngles( Data.ang ) end
  if Data.active ~= false then Main:SetKeyValue( "start_active", "1" ) end

  local CPoints = {}

  for X, CPointData in ipairs( Data.cpoints or {} ) do

    local CPoint = CreateParticleEffect( String, CPointData )

    CPoint:SetName( "drg_info_particle_system_cpoint_" .. CPoint:GetCreationID() )

    Main:SetKeyValue( "cpoint"..tostring( X ), CPoint:GetName() )

    CPoint:Fire("Stop") -- Stops the CPoint from emitting.

    Main:DeleteOnRemove( CPoint )

    table.insert( CPoints, CPoint )

  end

  Main:Spawn()
  Main:Activate()

  if isentity( Data.parent ) and IsValid( Data.parent ) then

    if isstring( Data.attachment ) then

      Main:SetParent( Data.parent )

      if Data.keepoffset then

        Main:Fire( "SetParentAttachmentMaintainOffset", Data.attachment )

      else 

        Main:Fire( "SetParentAttachment", Data.attachment ) 

      end

    elseif not Data.keepoffset then

      Main:SetPos( Data.parent:GetPos() )

      Main:SetParent( Data.parent )

    else

      Main:SetParent( Data.parent ) 

    end

  end

  return Main, table.DrG_Unpack( CPoints, #CPoints ) -- Return Main Particle and CPoints as a VarArg.

end



function ENT:GetParticleEffectSlot( Slot )

  if not istable( self.ParticleTable ) or not istable( self.ParticleTable[ Slot ] ) then return end

  return self.ParticleTable[ Slot ].Main, self.ParticleTable[ Slot ].CPoints

end



function ENT:ClearParticleEffectSlot( Slot )

  if not istable( self.ParticleTable[ Slot ] ) or not istable( self.ParticleTable ) then return end

  SafeRemoveEntity( self.ParticleTable[ Slot ].Main ) -- Delete Main Particle. All CPoints will be deleted alongside this.

  table.Empty( self.ParticleTable[ Slot ] )

end



function ENT:ClearAllParticleEffectSlots()

  for Slot, v in pairs( self.ParticleTable or {} ) do
    
    self:ClearParticleEffectSlot( Slot )

  end

end



function ENT:ParticleEffectSlot( Slot, ... )

  local Pack = table.DrG_Pack( CreateParticleEffect( ... ) ) -- Pack all data together.

  -- Create Table --

  if not istable( self.ParticleTable ) then

    self.ParticleTable = {}

  end

  -- Clear Previous Data --

  if not table.IsEmpty( self.ParticleTable ) then

    self:ClearParticleEffectSlot( Slot )

  end

  -- Unpack Data to Table --

  local MainParticle = table.remove( Pack, 1 )

  if not IsValid( MainParticle ) then return end

  self.ParticleTable[ Slot ] = { Main = MainParticle, CPoints = Pack }

  return self.ParticleTable[ Slot ]

end



function ENT:ParticleEffectTimed( Time, ... )

  local P = CreateParticleEffect( ... )

  SafeRemoveEntityDelayed( P, Time )

  return P

end



end