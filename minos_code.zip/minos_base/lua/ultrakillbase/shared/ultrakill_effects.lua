if not istable( ENT ) then return end



if SERVER then



function ENT:CreateBlood( Dmg, HitGroup ) -- Networking Function.
  
  if not self.CanBleed or type( Dmg ) ~= "CTakeDamageInfo" then return end

  UltrakillBase.SoundScript( "Ultrakill_Blood", self:GetPos() )

  self:CallOnClient( "CreateBlood", util.DrG_SaveDmg( Dmg ), HitGroup )

end



function ENT:CreateGibs( ... )

  self:CallOnClient( "CreateGibs" , ... )
  
end



elseif CLIENT then



local BloodConVar = CreateConVar( "drg_ultrakill_blood", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enable Blood FX" )
local BloodAmountConVar = CreateConVar( "drg_ultrakill_bloodamount", 30, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Max Amount of Blood" )
local GibsConVar = CreateConVar( "drg_ultrakill_gibs", 1, { FCVAR_ARCHIVE, FCVAR_LUA_CLIENT }, "Enables Gibs" )



local render = render
local LerpVector = LerpVector

function ENT:RenderLine( Table )

  Table = Table or {}

  local Segments = Table.Segments or 1

  local Vec1 = Table.StartPos
  local Vec2 = Table.EndPos

  local Width = Table.Width or 10
  local Texture = Table.Material or Material( "particles/ultrakill/White_Trail" )
  local Stretch = Table.Stretch or 1

  local LineColor = Table.Color or color_white

  if not isvector( Vec1 ) or not isvector( Vec2 ) then return end

  render.SetMaterial( Texture )

  render.StartBeam( Segments + 1 )

    for X = 0, Segments do

      render.AddBeam( LerpVector( X / Segments, Vec1, Vec2), Width, ( X / Segments ) * Stretch, LineColor )

    end

  render.EndBeam()

end



function ENT:CreateBlood( Dmg, HitGroup )

  if BloodConVar:GetBool() and Dmg.damage > 0 then

    local Pos = Dmg.damagePosition

    -- Is Within A HitBox --

    local IsWithinHitBox = false
    local HitSet = self:GetHitboxSet()
    local Count = self:GetHitBoxCount( HitSet )

    for X = 0, Count - 1 do

      local Min, Max = self:GetHitBoxBounds( X, HitSet )

      local HitBoxPos = self:GetBonePosition( self:GetHitBoxBone( X, HitSet ) )

      if Pos:WithinAABox( HitBoxPos + Min * 3, HitBoxPos + Max * 3 ) then

        IsWithinHitBox = true

        break

      end

    end

    if not IsWithinHitBox then

      Pos = self:WorldSpaceCenter()

    end

    -- Create Effect --

    local Amount = math.Clamp( Dmg.damage * 0.0025, 1, BloodAmountConVar:GetInt() )

    local Effect = not self:GetSand() and "Ultrakill_Blood" or "Ultrakill_Sand"

    for I = 1, Amount do

      ParticleEffect( Effect, Pos, Angle( 0, 0, 0 ) )

    end

    -- Gibs --

    self:CreateGibs( {

      Position = Pos,
      Models = UltrakillBase.Gibs.Flesh,
      Amount = Amount * 0.5,
      Velocity = 150,
      ModelScale = 1.5,
    
    } )

  end

end



local function CreateClientPhysicsObject( Mdl, Pos, Velocity, Size, Trail )

  if istable( Mdl ) then

    Mdl = Mdl[ math.random( #Mdl ) ]

  end

  local Object = ents.CreateClientProp( Model( Mdl ) )

  Object:Spawn()

  -- Initalize --

  if Trail then

    ParticleEffectAttach( Trail, PATTACH_POINT_FOLLOW, Object, 0 )

  end

  Object:SetModelScale( Size )

  -- Physics --

  Object:PhysicsInit( SOLID_VPHYSICS )
  Object:SetSolid( SOLID_VPHYSICS )
  Object:SetMoveType( MOVETYPE_VPHYSICS )
  Object:SetCollisionGroup( COLLISION_GROUP_DEBRIS )

  local Phys = Object:GetPhysicsObject()

  if IsValid( Phys ) then

    Phys:Wake()
    Phys:EnableDrag( false )
    Phys:EnableGravity( true )

  end

  -- Pos / Ang --

  local Ang = Object:GetAngles()
  local RanPos = Vector()
  
  Ang:Random()
  RanPos:Random( -10, 10 )

  local Vec = Vector( 1, 1, 1 )

  Vec:Random( -Velocity, Velocity )
  Vec.z = math.Clamp( Vec.z, Velocity / 2.5, Velocity )

  Object:SetPos( RanPos + Pos )
  Object:SetAngles( Ang )

  -- Velocity --

  if IsValid( Phys ) then

    Phys:SetVelocity( Vec )

  end

  -- Collision Callback --

  Object:AddCallback( "PhysicsCollide", function( self, Data )

    local Phys = self:GetPhysicsObject()

    if IsValid( Phys ) and Data.OurNewVelocity:LengthSqr() <= 50 ^ 2 then

      Phys:Sleep() -- Force the PhysicsObject to sleep. 

    end

  end )

  Object:Activate()

  SafeRemoveEntityDelayed( Object, 6 )

end



function ENT:CreateGibs( Data )

  if not istable( Data ) or table.IsEmpty( Data ) or not GibsConVar:GetBool() then return end

  local Models = Data.Models

  -- Multi Table --

  if istable( Data[1] ) then

    for K, V in ipairs( Data ) do

      for X = 1, V.Amount do
    
        CreateClientPhysicsObject( istable( V.Models ) and V.Models[ math.random( #V.Models ) ] or V.Models, V.Position, V.Velocity, V.ModelScale, V.Trail )

      end

    end

    return true

  else

    -- No Multi Table --

    for X = 1, Data.Amount do

      CreateClientPhysicsObject( istable( Data.Models ) and Data.Models[ math.random( #Data.Models ) ] or Data.Models, Data.Position, Data.Velocity, Data.ModelScale, Data.Trail )

    end

    return true

  end

end



end