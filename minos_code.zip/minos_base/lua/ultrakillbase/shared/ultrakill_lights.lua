if not istable( ENT ) then return end



local DynamLights = {}

local LightConVar = CreateConVar( "drg_ultrakill_lights", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enable Dynamic Lights" )

function ENT:CreateProjectedLight( Pos, Ang, FarZ, Brightness, LightColor )

  if SERVER then return self:CallOnClient( "CreateProjectedLight", Pos, Ang, FarZ, Brightness, LightColor ) end

  if not LightConVar:GetBool() then return false end

  if not isstring( ID ) then ID = tostring( ID ) end 

  if isstring( Pos ) then Pos = self:GetBonePosition( self:DrG_SearchBone( Pos ) )
  elseif isentity( Pos ) then Pos = Pos:GetPos()
  elseif not isvector( Pos ) then Pos = Vector() end

  local ProjectedLight = ProjectedTexture()

  ProjectedLight:SetTexture( "effects/flashlight/soft" )
  ProjectedLight:SetFarZ( FarZ or 1000 )

  ProjectedLight:SetPos( Pos )
  ProjectedLight:SetAngles( Ang or angle_zero )

  ProjectedLight:SetBrightness( Brightness or 1 )

  ProjectedLight:SetEnableShadows( false )

  ProjectedLight:SetColor( LightColor or color_white )

  ProjectedLight:SetTargetEntity( self )

  ProjectedLight:Update()

  self:CallOnRemove( tostring( self ) .. "_UltrakillBase_ProjectedLightDeletion", function( self, ProjectedLight )

    ProjectedLight:Remove()

  end, ProjectedLight )

end

function ENT:AddDynamLight( ID, Pos, Col, Radius, Brightness, Style, Attachment )

  if not LightConVar:GetBool() then return false end

  if not isstring( ID ) then ID = tostring( ID ) end 

  if isstring( Attachment ) then Attachment = self:LookupAttachment( Attachment ) end

  if isstring( Pos ) then Pos = self:GetBonePosition( self:DrG_SearchBone( Pos ) )
  elseif isentity( Pos ) then Pos = Pos:GetPos()
  elseif not isvector( Pos ) then Pos = Vector() end

  if istable( self.DynamLights[ ID ] ) and not table.IsEmpty( self.DynamLights[ ID ] ) then

    self:RemoveDynamLight( ID ) -- Replace.

  end

  local Light = self:DynamicLight( Col, Radius, Brightness, Style, Attachment )

  Light:SetPos( Pos )

  Light:SetParent( self, Attachment )

  self.DynamLights[ ID ] = { Settings = { Pos, Col, Radius, Brightness, Style, Attachment }, Ent = Light }

  return Light, { Pos, Col, Radius, Brightness, Style, Attachment }

end



function ENT:RemoveDynamLight( ID )

  local Table = self.DynamLights[ ID ] 

  if not IsValid( Table.Ent ) or not isentity( Table.Ent ) then return false end

  SafeRemoveEntity( Table.Ent )
  table.Empty( self.DynamLights[ ID ] ) -- Empty the Table.

  return true -- Was deleted!

end



function ENT:GetDynamLight( ID )

  local Table = self.DynamLights[ ID ]

  if not istable( Table ) or table.IsEmpty( Table ) then return end

  return Table.Ent, Table.Settings

end

