if not istable( ENT ) then return end



function ENT:Ultrakill_Timer( ID, Delay, Rep, Func )

  if timer.Exists( ID ) then -- Check if this already exists.
    timer.Remove( ID ) -- Override the Timer!
  end 

  timer.Create( ID, Delay, Rep, function()

    Func( self )

  end)

  self:CallOnRemove( ID, function( Ent, ID)

    timer.Remove( ID )

  end, ID )

end



