if not istable( ENT ) then return end



  -- This Code is used to acquire an Entities Tick Interval. --



ENT.LastUpdateTime = nil
ENT.UpdateInterval = nil



function ENT:CalculateUpdateInterval()

  if self.LastUpdateTime then

    local Interval = CurTime() - self.LastUpdateTime

    if Interval > 0.0001 then

      self.UpdateInterval = Interval
      self.LastUpdateTime = CurTime()

    end

  else

    self.UpdateInterval = 0.033
    self.LastUpdateTime = CurTime() - self.UpdateInterval

  end

end



function ENT:GetUpdateInterval()

  return self.UpdateInterval

end


