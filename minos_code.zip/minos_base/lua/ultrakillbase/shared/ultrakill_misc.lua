if not istable( ENT ) or CLIENT then return end


function ENT:Height()

	local Min, Max = self:GetCollisionBounds()

	return math.max( Min.z, Max.z )

end

function ENT:GetGroundAngles( Pos )

  local HitNormal, HitPos

  if not isvector( Pos ) and self:IsNextBot() then

    HitNormal = self.loco:GetGroundNormal()
    HitPos = self:GetPos()

  else

    if not isvector( Pos ) then Pos = self:GetPos() end
  
    local Trace = self:TraceHull( nil, {
      
      start = Pos + Vector( 0, 0, self:Height() * 0.5 ),
      endpos = Pos - self:GetUp() * 10000,
      collisiongroup = COLLISION_GROUP_WORLD,
      filter = self,

    } )

    HitNormal = Trace.HitNormal
    HitPos = Trace.HitPos

  end

  HitNormal = HitNormal:Angle()

  HitNormal:RotateAroundAxis( HitNormal:Right(), 90 )
  HitNormal:RotateAroundAxis( HitNormal:Forward(), 180 )
  HitNormal:RotateAroundAxis( HitNormal:Up(), 180 + self:GetAngles().y )

  return HitNormal, HitPos

end



function ENT:Shockwave( Skin, Pos, Ang, Damage, Time, Radius, ScaleZ, IgnoreFilter )

  if not isvector( Pos ) then Pos = self:GetPos() end
  if not isangle( Ang ) then Ang = self:GetAngles() end

  local Shockwave = ents.Create( "Ultrakill_Shockwave" )
        
  Shockwave:SetOwner( self )
  Shockwave:SetPos( Pos )
  Shockwave:SetAngles( Ang )

  Shockwave:SetDamage( Damage )
  Shockwave:SetTime( Time )
  Shockwave:SetRadius( Radius )
  Shockwave:SetScaleZ( ScaleZ )

  Shockwave:SetSkin( Skin )

  Shockwave.IgnoreFilter = IgnoreFilter or {}

  Shockwave:Spawn()

  Shockwave:ScreenShake( 2500, 10, Time, 6500 )

  local SoundID = Time > 1 and "Ultrakill_Shockwave" or "Ultrakill_Shockwave_Short"

  UltrakillBase.SoundScript( SoundID, Shockwave:GetPos(), Shockwave )

  return Shockwave

end



function ENT:Explosion( Pos, Damage, Force, Radius, Time, Owner, Parry, IgnoreFilter )

  if isentity( Pos ) then Pos = Pos:WorldSpaceCenter() end

  Owner = IsValid( Owner ) and Owner or self

  local Explosion = ents.Create( "Ultrakill_Explosion" )

  Explosion:SetDamage( Damage )
  Explosion:SetForce( Force )
  Explosion:SetTime( Time )
  Explosion:SetRadius( Radius )

  Explosion:SetOwner( Owner )
  Explosion:SetPos( Pos )

  Explosion.IsParry = Parry
  Explosion.IgnoreFilter = IgnoreFilter or {}

  Explosion:Spawn()

  return Explosion

end



function ENT:RepelRockets( Rpg )

  local Dir = ( self:WorldSpaceCenter() - Rpg:WorldSpaceCenter() ):GetNormalized()

  local Random = { -1, 1 }

  Dir:Rotate( Angle( 0, 90 * Random[ math.random( #Random ) ], 0 ) )

  UltrakillBase.SoundScript( "Ultrakill_Deflect", self:GetPos() )

  -- Damage --

  local Dmg = DamageInfo()

  Dmg:SetDamage( 1000 )
  Dmg:SetDamageForce( Dir * 5000 )
  Dmg:SetDamageType( DMG_MISSILEDEFENSE )
  Dmg:SetAttacker( self )
  Dmg:SetInflictor( self )
  Rpg:TakeDamageInfo( Dmg )

  Rpg:SetPos( Rpg:GetPos() + Dir * 200 )
  Rpg:SetAngles( Dir:Angle() )

end

