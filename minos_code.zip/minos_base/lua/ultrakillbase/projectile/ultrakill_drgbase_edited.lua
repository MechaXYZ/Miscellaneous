if not istable( ENT ) or CLIENT then return end



function ENT:IsInRange_XY( Vec, Range )

  if isentity( Vec ) and not IsValid( Vec ) then return false end

  if isentity( Vec ) then Vec = Vec:GetPos() end

  return Vector( self:GetPos().x, self:GetPos().y, 0 ):DistToSqr( Vector( Vec.x, Vec.y, 0 ) ) <= ( Range * self:GetScale() ) ^ 2

end



function ENT:PushEntity( Ent, Force )

  if istable( Ent ) then

    local Vecs = {}

    for K, V in ipairs( Ent ) do

      if not IsValid( V ) then continue end

      Vecs[ V:EntIndex() ] = self:PushEntity( V, Force )

    end

    return Vecs

  elseif isentity( Ent ) and IsValid( Ent ) then

    local Direction = self:GetPos():DrG_Direction( Ent:GetPos() )

    if Ent:IsPlayer() and Ent:InVehicle() then return Vector() end

    local VecForward = Direction

    VecForward.z = 0

    VecForward:Normalize()

    local VecRight = Vector()

    VecRight:Set( VecForward )

    VecRight:Rotate( Angle( 0, -90, 0 ) )

    local VecUp = Vector( 0, 0, 1 )

    local Vec = VecForward * Force.x + VecRight * Force.y + VecUp * Force.z

    local Phys = Ent:GetPhysicsObject()
    
    if not UltrakillBase.GetWeightData( Ent ).Push then return Vec end

    if Ent.IsDrGNextbot then

      Ent:LeaveGround()

      Ent:SetVelocity( Ent:GetVelocity() + Vec )

    elseif Ent.Type == "nextbot" then

      local JumpHeight = Ent.loco:GetJumpHeight()

      Ent.loco:SetJumpHeight(1)

      Ent.loco:Jump()

      Ent.loco:SetJumpHeight( JumpHeight )

      Ent.loco:SetVelocity( Ent.loco:GetVelocity() + Vec )

    elseif IsValid( Phys ) and not Ent:IsPlayer() then

      Phys:AddVelocity( Vec )

    else

      Ent:SetVelocity( Ent:GetVelocity() + Vec )

    end

    return Vec

  end

end



function ENT:IsInRange( Pos, Range )

  if isentity( Pos ) and not IsValid( Pos ) then

    return false

  end

  return self:GetHullRangeSquaredTo( Pos ) <= ( Range * self:GetModelScale() ) ^ 2

end



function ENT:GetHullRangeSquaredTo( Pos )

  if isentity( Pos ) then Pos = Pos:NearestPoint( self:GetPos() ) end

  return self:GetPos():DistToSqr( Pos )

end

