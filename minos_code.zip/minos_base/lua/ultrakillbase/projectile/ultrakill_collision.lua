if not istable( ENT ) then return end



local function CollisionFilter( self, Ent )

  if self == Ent or Ent == self:GetOwner() or not IsValid( Ent:GetPhysicsObject() ) then return false end

  return true

end



function ENT:CollisionOptimization( Radius )

  for K, V in ipairs( ents.FindInSphere( self:GetPos(), Radius ) ) do

    if not CollisionFilter( self, V ) then 

      continue

    else 
      
      return #ents.FindInSphere( self:GetPos(), Radius ) > 0 

    end

    return false

  end

end



function ENT:ProjectileShouldCollide( Ent )

  if Ent:IsWorld() then return end

  if not CollisionFilter( self, Ent ) then return false end

  if Ent:GetClass() == "prop_physics" then return true end

  if self:GetParried() and Ent.IsUltrakillProjectile then return false end

  if UltrakillBase.CheckIFrames( Ent ) and UltrakillBase.GetWeightData( Ent ).Collision or ( Ent:IsPlayer() and ( Ent:HasGodMode() or Ent.Dashing ) or Ent.IsDrGNextbot and Ent:GetGodMode() ) then return false end

  if self.CustomDispCollisions[ self:GetRelationship( Ent ) ] ~= true then return false end

  return true

end

