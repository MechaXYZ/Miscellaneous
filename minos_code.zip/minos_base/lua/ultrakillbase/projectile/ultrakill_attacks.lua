if not istable( ENT ) or CLIENT then return end



function ENT:DamageFilter( Ent )
  
  local Owner = self:GetOwner()

  if Owner:IsPlayer() and Owner == Ent or Owner.IsUltrakillNextbot and not self.DamageRelationship[ self:GetRelationship( Ent ) ] then return false end

  return true

end



local function UltrakillScaleDamage( self, Ent )

  local Owner = self:GetOwner()

  if IsValid( Owner ) and Owner:IsPlayer() and Ent.IsUltrakillNextbot then

    return 40 * ( 1 / math.Clamp( UltrakillBase.ConVars.PlyDmgMult:GetFloat() * 10, 0, math.huge ) )

  elseif IsValid( Owner ) and Owner:IsPlayer() then
    
    return 1
    
  end

  if Ent:IsPlayer() then

    return math.max( GetConVar( "drg_ultrakill_plytakedmgmult" ):GetFloat(), 0 )

  elseif Ent.IsUltrakillNextbot then

    return 1

  else

    return math.max( GetConVar( "drg_ultrakill_dmgmult" ):GetFloat(), 0 )

  end

end



function ENT:DealDamage( Ent, Damage, Force, Type )

  if not self:DamageFilter( Ent ) or not UltrakillBase.CanAttack( Ent ) then return end

  local Dmg = DamageInfo()
  local Owner = self:GetOwner()

  local Radiance = ( IsValid( Owner ) and Owner.IsUltrakillNextbot and Owner:IsRadiant() ) and Owner.RadianceInfo.Damage or 1

  Dmg:SetDamage( Damage * UltrakillScaleDamage( self, Ent ) * Radiance )

  Dmg:SetDamageType( self:GetParried() and bit.bor( Type, DMG_DIRECT ) or Type )
  Dmg:SetDamagePosition( self:GetPos() )
  Dmg:SetAttacker( IsValid( Owner ) and Owner or self )
  Dmg:SetInflictor( self )

  UltrakillBase.SetIFrames( Ent, UltrakillBase.CalculateIFrameTime( Ent, Damage * Radiance ) )

  if Damage * Radiance > 500 then

    UltrakillBase.SoundScript( "Ultrakill_Hit_Low", Ent:GetPos() )

  else

    UltrakillBase.SoundScript( "Ultrakill_Hit", Ent:GetPos() )

  end

  if not Ent.IsUltrakillProjectile then

    Dmg:SetDamageForce( self:PushEntity( Ent, Force ) )

  end

  Ent:TakeDamageInfo( Dmg )
    
end



function ENT:TraceAttack( Trace, Attack )

  if not istable( Trace ) then return end

  Attack = Attack or {}
  Attack.Damage = Attack.Damage or 0
  Attack.Type = Attack.Type or DMG_GENERIC
  Attack.Force = Attack.Force or Vector( 100, 0, 0 )
  Attack.Viewpunch = Attack.Viewpunch or Angle( 10, 0, 0 )
  Attack.Angle = Attack.Angle or 90

  local Dist = Trace.StartPos:Distance( Trace.HitPos )

  for _, Ent in ipairs( ents.FindInCone( Trace.StartPos, Trace.Normal, Dist, math.cos( math.rad( Attack.Angle ) ) ) ) do

    if Ent == self or not UltrakillBase.CanAttack( Ent ) or not self:DamageFilter( Ent ) then continue end

    self:DealDamage( Ent, Attack.Damage, Attack.Force, Attack.Type )

    if Attack.Viewpunch and Ent:IsPlayer() then
      
      Ent:ViewPunch( Attack.Viewpunch )

    end


  end

end

