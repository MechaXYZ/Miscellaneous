if not istable( ENT ) then return end

function ENT:CalculateRate()

  local Owner = self:GetOwner()

  if not IsValid( Owner ) or not Owner.IsUltrakillNextbot then

    return UltrakillBase.DifficultyGetInformation( "Rate" ) or 1

  end

  local OwnerRate = Owner:CalculateAnimRate()

  return 1 * OwnerRate

end