if not istable( ENT ) then return end


local ParryProjConVar = CreateConVar( "drg_ultrakill_parry_projectile", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enables Parrying for players.")


  -- Parry --
  

function ENT:SetParryable( Bool )

  if not ParryProjConVar:GetBool() then 
    
    return self:SetNW2Bool( "UltrakillBase_Projectile_Parryable", false )

  end

  return self:SetNW2Bool( "UltrakillBase_Projectile_Parryable", Bool )

end


function ENT:GetParryable()

  if not ParryProjConVar:GetBool() then 

    return false

  end

  return self:GetNW2Bool("UltrakillBase_Projectile_Parryable")

end


function ENT:SetParried( Bool )

  return self:SetNW2Bool( "UltrakillBase_Projectile_Parried", Bool )

end


function ENT:GetParried( )

  return self:GetNW2Bool( "UltrakillBase_Projectile_Parried" )

end


function ENT:IsParried( )

  return self:GetParried( )

end


if SERVER then


function ENT:OnParry( Ply, Dmg )

  self:SetParried( true ) -- Make sure the projectile knows it got parried.

  self.Damage = self.Damage -- Adjust Damage.

  UltrakillBase.HitStop( 0.25 ) -- HitStop effect.

  self:SetOwner( Ply )

  UltrakillBase.SoundScript( "Ultrakill_Parry", self:GetPos() )

  local Aim = Ply:GetAimVector() -- Get Player's Aim

  self:SetAngles( Aim:Angle() )
  self:SetVelocity( Aim * 5000 ) -- Change Velocity to match Player's Aim.

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then

    Phys:SetAngleVelocity( vector_origin ) 
    Phys:EnableGravity( false )

  end

  UltrakillBase.OnParryPlayer( Ply )

end


function ENT:CheckParry( Dmg )

  if not ParryProjConVar:GetBool() then return end

  local Ply = Dmg:GetAttacker()

  if IsValid( Ply ) and Ply:IsPlayer() and self:GetParryable() and not self:GetParried() and self:IsInRange( Ply, 250 ) then

    if Dmg:IsDamageType( DMG_CLUB + DMG_SLASH ) then

      self:OnParry( Ply, Dmg )

    end

  end

end


function ENT:ParryCollide()

  UltrakillBase.SoundScript( "Ultrakill_Explosion_1", self:GetPos() )

  self:Explosion( self:GetPos(), self.Damage, Vector( 500, 0, 250 ), 150, 0.25, self:GetOwner(), true )

  ParticleSystem3D( "ultrakill_parry_explosion", self:GetPos(), self:GetAngles(), 1 )
  
  self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Shockwave", { pos = self:GetPos() + Vector( 0, 0, 5 ), ang = self:GetAngles(), cpoints = { { pos = Vector( 25, 325, 0.75 ) } } } )
  self:ParticleEffectTimed( 1, "Ultrakill_Explosion_Sparks", { pos = self:GetPos() + Vector( 0, 0, 5 ), ang = self:GetAngles() } )

  ParticleEffect( "Ultrakill_ExplosionSmoke", self:GetPos(), self:GetAngles() )
  ParticleEffect( "Ultrakill_ExplosionSmokeLinger", self:GetPos(), self:GetAngles() )

end


end -- End of SERVER