if not istable( ENT ) then return end



function ENT:AngleFollowVelocity() -- This function is shared.

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then

    if CLIENT then

      Phys:SetAngles( Phys:GetVelocity():Angle() ) -- Set Angles on Server fucks up the velocity.
  
    end

    Phys:SetAngleVelocity( Vector( 0, 0, 0 ) ) -- Stop Angle Velocity...
    Phys:SetAngleVelocityInstantaneous( Vector( 0 ,0, 0 ) )

  else

    self:SetAngles( self:GetVelocity():Angle() )

  end

end



function ENT:HaltAllVelocity() -- This function is shared.

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then

    Phys:SetAngleVelocity( vector_origin ) -- Stop Angle Velocity...
    Phys:SetVelocity( vector_origin )

  else

    self:SetVelocity( vector_origin )

  end

  if not Phys:IsAsleep() and IsValid( Phys ) then

    Phys:Sleep()
    
  end

end



function ENT:HaltVelocity() -- This function is shared.

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then

    Phys:SetAngleVelocity( vector_origin ) -- Stop Angle Velocity...
    Phys:SetVelocity( vector_origin )

  else

    self:SetVelocity( vector_origin )

  end

end

