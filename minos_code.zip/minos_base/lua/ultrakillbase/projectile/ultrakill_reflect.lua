if not istable( ENT ) or not SERVER then return end

function ENT:OnReflect( Attacker, Dmg )

  self:SetOwner( Attacker )

  local DamagePos = Dmg:GetDamagePosition()

  local Direction = ( self:GetPos() - DamagePos ):GetNormalized()

  local Velocity = self:GetVelocity():Length()

  self:SetAngles( Direction:Angle() )
  self:AddVelocity( Direction * math.max( Velocity * 0.9, 1000 ) ) -- Clamp this, to fix a bug with low velocity projs being reflected.

  self:SetHoming( false )

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then Phys:SetAngleVelocity( vector_origin ) end

end

function ENT:CheckReflect( Dmg )

  local Attker = Dmg:GetAttacker()

  if IsValid( Attker ) and Dmg:IsDamageType( DMG_BLAST, DMG_BLAST_SURFACE ) then

    self:OnReflect( Attker, Dmg )

  end

end