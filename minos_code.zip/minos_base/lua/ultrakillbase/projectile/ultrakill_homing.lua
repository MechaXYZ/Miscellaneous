if not istable( ENT ) then return end

function ENT:GetHoming( )

  return self.HomingInfo.Enabled

end

function ENT:SetHoming( Bool )

  self.HomingInfo.Enabled = Bool

end

function ENT:GetHomingSpeed( )

  return self.HomingInfo.Speed

end

function ENT:SetHomingSpeed( Float )

  self.HomingInfo.Speed = Float

end

function ENT:GetHomingTurnRate( )

  return self.HomingInfo.TurnSpeed

end

function ENT:SetHomingTurnRate( Float )

  self.HomingInfo.TurnSpeed = Float

end

function ENT:GetHomingType()

  return self.HomingInfo.Type

end

function ENT:SetHomingType( Int )

  self.HomingInfo.Type = Int

end

function ENT:GetHomingAngle( )

  return self.HomingInfo.Angle

end

function ENT:SetHomingAngle( Ang )

  self.HomingInfo.Angle = Ang

end

function ENT:HomingInitialize()

  self.HomingInfo = {}

  self:SetHoming( self.UseHoming )
  self:SetHomingSpeed( self.HomingSpeed )
  self:SetHomingTurnRate( self.HomingTurnRate )
  self:SetHomingType( self.HomingType or 1 )

  self.HomingInfo.Initialized = true

end

--[[ 
  
  Type 1

  This Homing Function follows the Linear Direction from Itself to the Target.
  Adjusting it's direction by a fixed speed.

--]]


function ENT:Homing( Target, Speed, Rate )

  if not IsValid( Target ) then return end

  if isentity( Target ) then Target = UltrakillBase.EyePos( Target ) end

  local Direction = ( Target - self:GetPos() ):Angle()
  local CurrentDirection = self:GetHomingAngle() and self:GetHomingAngle() or self:GetAngles()

  UltrakillBase.AngleApproach( CurrentDirection, Direction, Rate * self:GetUpdateInterval() )

  self:SetHomingAngle( CurrentDirection )

  self:SetVelocity( CurrentDirection:Forward() * Speed )

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then

    Phys:SetAngleVelocity( vector_origin )
    
  end

end


--[[ 
  
  Type 2

  Dunno yet.

--]]

function ENT:HomingType2() end

--[[ 
  
  Type 3

  This function will Calculate a Ballistic Direction for the Projectile to follow.

--]]

local function InitializeBallistics( self, Target )

  self.HomingInfo.Ballistics = {}
  self.HomingInfo.Ballistics.Origin = self:GetPos()
  self.HomingInfo.Ballistics.ZAxis = Target.z - self.HomingInfo.Ballistics.Origin.z
  self.HomingInfo.Ballistics.InitTime = CurTime()

end

local function CalculateBallistics( self, Origin, Target, Pitch, ForceZ )

  local Direction = Target - Origin

  Direction.z = 0

  local Gravity = physenv.GetGravity():Length()
  local LinearDistance = math.min( 1000, Direction:Length() )
  local ZAxis = ForceZ or ( Target.z - Origin.z )

  Pitch = math.rad( math.Clamp( Pitch, -90, 90 ) )

  local Magnitude

  if ZAxis >= math.tan( Pitch ) * LinearDistance then

    Direction.z = math.tan( Pitch ) * LinearDistance

    local Velocity = Direction:GetNormalized()

    local BallisticInfo = Origin:DrG_TrajectoryInfo( Velocity )

    BallisticInfo.duration = -1

    return Velocity * ( Target - Origin ):LengthSqr(), BallisticInfo

  else

    Magnitude = math.sqrt( ( -Gravity * LinearDistance ^ 2 ) / ( 2 * ( math.cos( Pitch ) ^ 2 ) * ( ZAxis - LinearDistance * math.tan( Pitch ) ) ) )

  end

  Direction.z = math.tan( Pitch ) * LinearDistance

  local Velocity = Direction:GetNormalized() * Magnitude

  local BallisticInfo = Origin:DrG_TrajectoryInfo( Velocity, true )
  local BallisticCalculation = math.sqrt( ( ( Velocity.z ^ 2 ) / ( Gravity ^ 2 ) ) - ( ( 2 * ZAxis ) / Gravity ) )

  local DurationPositive = ( Velocity.z / Gravity ) + BallisticCalculation
  local DurationNegative = ( Velocity.z / Gravity ) - BallisticCalculation

  local DistancePositive = BallisticInfo.Predict( DurationPositive ):DistToSqr( Target )
  local DistanceNegative = BallisticInfo.Predict( DurationNegative ):DistToSqr( Target )

  BallisticInfo.Duration = ( DistancePositive < DistanceNegative ) and DurationPositive or DurationNegative

  return Velocity, BallisticInfo

end

function ENT:BallisticHoming( Target, Pitch, Speed )

  if not IsValid( Target ) then return end

  if isentity( Target ) then Target = Target:GetPos() end

  if not self.HomingInfo.Ballistics then

    InitializeBallistics( self, Target )

  end

  local Origin = self.HomingInfo.Ballistics.Origin
  local ZAxis = self.HomingInfo.Ballistics.ZAxis
  local InitTime = self.HomingInfo.Ballistics.InitTime

  local Velocity, BallisticsInfo = CalculateBallistics( self, Origin, Target, Pitch, ZAxis )

  if BallisticsInfo.ballistic then

    Speed = BallisticsInfo.magnitude * Speed

    Desired = BallisticsInfo.Predict( ( CurTime() - InitTime ) * 1.5 * self:CalculateRate() )

    local Direction = ( Desired - self:GetPos() ):GetNormalized()

    self:SetVelocity( Direction * Speed )

  elseif not BallisticsInfo.ballistic and not self.HomingInfo.Ballistics.HasLinearLaunched then

    self.HomingInfo.Ballistics.HasLinearLaunched = true

    self:SetVelocity( Velocity )

    local Phys = self:GetPhysicsObject()

    if IsValid( Phys ) then

      Phys:EnableGravity( true )
    
    end

  end

  local Phys = self:GetPhysicsObject()

  if IsValid( Phys ) then

    Phys:SetAngleVelocity( vector_origin )
    
  end

end

--[[ 
  
  Homing Handler for all Types.

  This function is used to easily use homing.

--]]

function ENT:HandleHoming()

  if self:GetHomingType() == 1 then

    self:Homing( self:GetEnemy(), self:GetHomingSpeed() * self:CalculateRate(), self:GetHomingTurnRate() * self:CalculateRate() )

  elseif self:GetHomingType() == 2 then

  elseif self:GetHomingType() == 3 then

    self:BallisticHoming( self:GetEnemy(), self.HomingPitch, self:GetHomingSpeed() * self:CalculateRate() )

  end

end
