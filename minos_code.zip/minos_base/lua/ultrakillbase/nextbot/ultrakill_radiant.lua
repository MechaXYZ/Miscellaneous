if not istable( ENT ) or SERVER then return end

local render = render

local RadiantMaterial = Material( "models/ultrakill/vfx/Radiant" )
local RadiantMaterial2 = Material( "models/ultrakill/vfx/Radiant2" )
local ScaleVector = Vector()
local OutlineThickness = 1.135

ENT.RadiantUpdate = 0

local function ScaleBones( Ent, Size )

  for X = 0, Ent:GetBoneCount() - 1 do

    ScaleVector.x = Size
    ScaleVector.y = Size
    ScaleVector.z = Size

    Ent:ManipulateBoneScale( X, ScaleVector )

  end

end

local function UpdateRadiant( Ent, Model )

  if CurTime() > Ent.RadiantUpdate then

    Ent.RadiantUpdate = CurTime() + 0.05

    Model:SetParent( Ent )
    
    local Bodygroups = Ent:GetBodyGroups()
    
    for K, V in ipairs( Bodygroups ) do

      Model:SetBodygroup( V.id, Ent:GetBodygroup( V.id ) )

    end
    
  end

end


local function StencilOutline( self, DrawFunction )

  render.ClearStencil()
  
  render.SetStencilEnable( true )

  render.SetStencilWriteMask( 0xFF )
	render.SetStencilTestMask( 0xFF )
	render.SetStencilCompareFunction( STENCIL_ALWAYS )
	render.SetStencilPassOperation( STENCIL_KEEP )
	render.SetStencilFailOperation( STENCIL_KEEP )
	render.SetStencilZFailOperation( STENCIL_KEEP )
  render.SetStencilReferenceValue( 0xFF )

  render.SetStencilCompareFunction( STENCIL_EQUAL )
  render.SetStencilFailOperation( STENCIL_INCR )

  self:DrawModel()

  render.SetStencilEnable( false )

  render.SetStencilEnable( true )

  render.SetStencilReferenceValue( 0 )

  DrawFunction( self )

  render.SetStencilFailOperation( STENCIL_KEEP )
  
  render.SetStencilEnable( false )

  render.ClearStencil()

end


local function DrawOutline( self )

  if not self.RadiantOutline then

    self.RadiantOutline = ClientsideModel( self:GetModel(), RENDERGROUP_TRANSLUCENT )

    self:CallOnRemove( "UltrakillBase_Radiant_Remover", function( self ) 
    
      SafeRemoveEntity( self.RadiantOutline )

    end )

    self.RadiantOutline:SetPos( self:GetPos() )
    self.RadiantOutline:AddEffects( bit.bor( EF_BONEMERGE, EF_BONEMERGE_FASTCULL, EF_NODRAW ) )

    ScaleBones( self.RadiantOutline, OutlineThickness )

  end

  UpdateRadiant( self, self.RadiantOutline )

  render.MaterialOverride( RadiantMaterial )

  StencilOutline( self, function( self )

    render.CullMode( MATERIAL_CULLMODE_CW )

    self.RadiantOutline:DrawModel( STUDIO_TWOPASS )

    render.CullMode( MATERIAL_CULLMODE_CCW )

  end )

end


function ENT:DrawRadiant()

  DrawOutline( self )

  if self.AlternateRadiantStyle ~= true then

    render.SetBlend( 0.1 )

    render.MaterialOverride( RadiantMaterial2 )

    self:DrawModel()

    render.SetBlend( 1 )

  end

  render.MaterialOverride()

end