if not istable( ENT ) or CLIENT then return end

local NearGroundDist = Vector( 0, 0, 100 )

function ENT:EnemyNearGround()

  local Enemy = self:GetEnemy()

  if self:HasEnemy() then

    local GroundCheck = Enemy:DrG_TraceHull( nil, {
      start = Enemy:GetPos(),
      endpos = Enemy:GetPos() - NearGroundDist,
      collisiongroup = COLLISION_GROUP_WORLD,
    } )

    if GroundCheck.Hit then
      
      return true
    
    end

    return false

  else

    return self:IsOnGround()

  end

end

function ENT:HandleAttacking()

  local Enemy = self:GetEnemy()

  local Relationship = self:GetRelationship( Enemy )

  if Relationship == D_HT or Relationship == D_FR then

    local EnemyVisible = self:Visible( Enemy )

    if not self.AISight then

      EnemyVisible = true

    end

    if IsValid( Enemy ) and EnemyVisible then 

      self:AttackEntity( Enemy ) 

    end

  end

end

function ENT:HandleEnemyPathing()

  local ShouldMove = self.CantMove ~= true

  local Enemy = self:GetEnemy()

  local Relationship = self:GetRelationship( Enemy )

  if Relationship == D_HT then

    local EnemyVisible = self:Visible( Enemy )

    if ( not self:IsInRange( Enemy, self.ReachEnemyRange ) or not EnemyVisible ) and ShouldMove then

      if self:OnChaseEnemy( Enemy ) ~= true then

        if self:FollowPath( Enemy ) == "unreachable" then

          self:OnEnemyUnreachable( Enemy )

        end

      end

    elseif self:IsInRange( Enemy, self.AvoidEnemyRange ) and EnemyVisible and not self:IsInRange( Enemy, self.MeleeAttackRange ) and ShouldMove then

      if self:OnAvoidEnemy( Enemy ) ~= true then

        self:FollowPath( self:GetPos():DrG_Away( Enemy:GetPos() ) )

      end

    elseif self:OnIdleEnemy( Enemy ) ~= true then

      if self.BehaviourStrafe then

        self:Approach( self:GetPos() + ( self.BehaviourStrafeDirection * self:GetRight() ) )
        self:LookTowards( Enemy )

      else 

        self:LookTowards( Enemy ) 

      end

    end

  elseif relationship == D_FR then

    local EnemyVisible = self:Visible( Enemy )

    if self:IsInRange( Enemy, self.AvoidAfraidOfRange ) and EnemyVisible and ShouldMove then

      if self:OnAvoidAfraidOf( Enemy ) ~= true then

        self:FollowPath( self:GetPos():DrG_Away( Enemy:GetPos() ) )

      end

    elseif self:OnIdleAfraidOf( Enemy ) ~= true then 

      self:LookTowards( Enemy ) 

    end

  elseif relationship == D_LI then 

    self:OnAllyEnemy( Enemy )

  elseif relationship == D_NU then 

    self:OnNeutralEnemy( Enemy ) 

  end

end

function ENT:HandleEnemyFlyingPathing()

  local Enemy = self:GetEnemy()

  local Relationship = self:GetRelationship( Enemy )

  if Relationship == D_HT then

    local EnemyVisible = self:Visible( Enemy )

    if not self:IsInRange( Enemy, self.ReachEnemyRange ) or not EnemyVisible then

      if self:OnChaseEnemy( Enemy ) ~= true then

        if self:HandleFlying( Enemy ) == "unreachable" then

          self:OnEnemyUnreachable( Enemy )

        end

      end

    elseif self:IsInRange( Enemy, self.AvoidEnemyRange ) and EnemyVisible and not self:IsInRange( Enemy, self.MeleeAttackRange ) then

      if self:OnAvoidEnemy( Enemy ) ~= true then

        self:HandleFlying( self:GetPos():DrG_Away( Enemy:GetPos() ) )

      end

    elseif self:OnIdleEnemy( Enemy ) ~= true then

      if self.BehaviourStrafe then

        self:ApproachFlying( self:GetPos() + ( self.BehaviourStrafeDirection * self:GetRight() ) )
        self:LookTowards( Enemy )

      else 

        self:SetVelocity( vector_origin )
        self:LookTowards( Enemy ) 

      end

    end

  elseif relationship == D_FR then

    local EnemyVisible = self:Visible( Enemy )

    if self:IsInRange( Enemy, self.AvoidAfraidOfRange ) and EnemyVisible then

      if self:OnAvoidAfraidOf( Enemy ) ~= true then

        self:HandleFlying( self:GetPos():DrG_Away( Enemy:GetPos() ) )

      end

    elseif self:OnIdleAfraidOf( Enemy ) ~= true then 

      self:SetVelocity( vector_origin )
      self:LookTowards( Enemy ) 

    end

  elseif relationship == D_LI then 

    self:OnAllyEnemy( Enemy )

  elseif relationship == D_NU then 

    self:OnNeutralEnemy( Enemy ) 

  end

end

function ENT:UpdateEnemy()

  local Enemy

  if not self:IsPossessed() then

    if self:HasNemesis() then return self:GetNemesis() end

    Enemy = self:OnUpdateEnemy()

    if Enemy == nil then return self:GetEnemy() end

    if not IsValid( Enemy ) or self:GetRangeSquaredTo( Enemy ) > ( GetConVar("drgbase_ai_radius"):GetFloat() ^ 2 ) then

      Enemy = NULL

    end

    if self:IsAfraidOf( Enemy ) and not self:IsInRange( Enemy, self.WatchAfraidOfRange ) then

      Enemy = NULL

    end

  else 

    local LockedOn = self:PossessionGetLockedOn()

    if IsValid( LockedOn ) then Enemy = LockedOn
    else Enemy = NULL end

  end

  self:SetEnemy( Enemy )

  return Enemy

end

function ENT:AIBehaviour()

  if self:HasEnemy() then

    self:HandleAttacking() 

    if self:GetFlying() then

      self:HandleEnemyFlyingPathing()

    else

      self:HandleEnemyPathing()

    end

  elseif self:HadEnemy() then 

    self:UpdateEnemy()
    
  else

    if self:GetFlying() then

      self:SetVelocity( vector_origin )

    end

    self:OnIdle() 

  end

end

ENT.UltrakillBaseBehaviourHooks = {}

function ENT:AddBehaviourHook( ID, Function, ... )

  local VarPack = { ... };

  self.UltrakillBaseBehaviourHooks[ ID ] = function( self )

    Function( self, unpack( VarPack ) )

  end;

end

function ENT:RemoveBehaviourHook( ID )

  self.UltrakillBaseBehaviourHooks[ ID ] = nil;

end

function ENT:BehaveUpdate( fInterval )

  self.UpdateInterval = fInterval

  if not self.BehaveThread then return end

  if coroutine.status( self.BehaveThread ) ~= "dead" then

    local Ok, Args = coroutine.resume( self.BehaveThread )

    if not Ok then 

      self.BehaveThread = nil

      if not self:OnError( Args ) then

        ErrorNoHalt( self, " Error: ", Args, "\n" )

      else

        self:BehaveStart()

      end

    end

  else

    self.BehaveThread = nil

  end


  -- Customs Hooks --

  for K, V in pairs( self.UltrakillBaseBehaviourHooks ) do

    V( self );

  end


end

-- Generator --
-- Returns Cost of Nav --
-- This Generator Ignores Ladder & Climbing due to Ultrakill not having those. --

function UltrakillBase.NavGenerator( self, NavArea, NavFromArea, Ladder, Elevator, NavLength )

  if not IsValid( NavFromArea ) then return 0 end

  if self:IsNavAreaBlacklisted( NavArea ) or not self.loco:IsAreaTraversable( NavArea ) then return -1 end
  
  local NavDistance = NavLength > 0 and NavLength or ( NavArea:GetCenter() - NavFromArea:GetCenter() ):GetLength()

  local NavCost = NavFromArea:GetCostSoFar() + NavDistance

  local NavHeight = NavFromArea:ComputeAdjacentConnectionHeightChange( NavArea )

  if NavHeight > 0 then -- Climb

    if NavHeight < self.loco:GetStepHeight() then

      local CustomCost = self:OnComputePathStep( NavFromArea, NavArea, NavHeight )

      if CustomCost >= 0 then

        NavCost = NavCost + NavDistance * CustomCost

      else

        return -1

      end

    elseif UltrakillBase.EnableNextbotJumping and NavHeight < self.loco:GetStepHeight() then

      local CustomCost = self:OnComputePathJump( NavFromArea, NavArea, NavHeight )

      if CustomCost >= 0 then

        NavCost = NavCost + NavDistance * CustomCost

      else

        return -1

      end

    else

      return -1

    end

  elseif NavHeight < 0 then -- Drop

    local NavDrop = -NavHeight

    if NavDrop < self.loco:GetDeathDropHeight() then

      local CustomCost = self:OnComputePathDrop( NavFromArea, NavArea, NavDrop )

      if CustomCost >= 0 then

        NavCost = NavCost + NavDistance * CustomCost

      else

        return -1

      end

    else

      return -1

    end

  else

    local CustomCost = self:OnComputePathFlat( NavFromArea, NavArea )

    if CustomCost >= 0 then

      NavCost = NavCost + NavDistance * CustomCost

    else

      return -1

    end

  end

  if NavArea:IsUnderwater() then

    local CustomCost = self:OnComputePathUnderwater( NavFromArea, NavArea )

    if CustomCost >= 0 then

      NavCost = NavCost + NavDistance * CustomCost

    else

      return -1

    end

  end

  local TotalCost = self:OnComputePath( NavFromArea, NavArea )

  if TotalCost >= 0 then

    return NavCost + NavDistance * TotalCost

  else

    return -1

  end

end


function ENT:GetPathGenerator()

  return UltrakillBase.NavGenerator

end