if not istable( ENT ) or CLIENT then return end



function ENT:SetContinuousAttack( Bool )

  self.UltrakillBase_ContinuousAttack = Bool
  
end

function ENT:GetContinuousAttack( )

  return self.UltrakillBase_ContinuousAttack

end



function ENT:ContinuousAttack( Attack, Function )

  self.ContinuousAttacksTable = self.ContinuousAttacksTable or {}

  self.ContinuousAttacksTable = Attack

  self:Attack( Attack )

end



function ENT:IsInCone( Ent, Ang, Dist )

  if isnumber( Dist ) and not self:IsInRange( Ent, Dist ) then return false end

  local Dir = self:GetPitchFollow() and self:GetAimVector() or self:GetForward()

  local Center = self:WorldSpaceCenter() - Dir * 10
  local Feet = self:GetPos() - Dir * 10

  local IsBottom = ( Center + Dir ):DrG_Degrees( Ent:GetPos() + Ent:OBBMins(), Center ) <= Ang * 0.5
  local IsTop = ( Center + Dir ):DrG_Degrees( Ent:GetPos() + Ent:OBBMaxs(), Center ) <= Ang * 0.5
  local IsCenter = ( Center + Dir ):DrG_Degrees( Ent:WorldSpaceCenter(), Center ) <= Ang * 0.5
  local IsFeet = ( Feet + Dir ):DrG_Degrees( Ent:GetPos(), Feet ) <= Ang * 0.5

  return IsBottom or IsTop or IsCenter or IsFeet

end



local function EntitiesInCone( self, Angles, Dist, Disp, Spotted ) -- Cleaned up.

  local Entities = {}

  for Ent in self:EntityIterator( Disp, Spotted ) do

    if self:IsInCone( Ent, Angles, Dist ) then

      table.insert( Entities, Ent )

    end

  end

  return Entities

end



local function UltrakillScaleDamage( Ent )

  if Ent:IsPlayer() then

    return math.max( GetConVar( "drg_ultrakill_plytakedmgmult" ):GetFloat(), 0 )

  elseif Ent.IsUltrakillNextbot then

    return 1

  else

    return math.max( GetConVar( "drg_ultrakill_dmgmult" ):GetFloat(), 0 )

  end

end



function ENT:Attack( Attack, Callback ) -- Added IFrame Detection. and AutoScaling Damage.

    Attack = Attack or {}
    Attack.Damage = Attack.Damage or 0
    Attack.Delay = Attack.Delay or 0
    Attack.Type = Attack.Type or DMG_GENERIC
    Attack.Force = Attack.Force or Vector( 100, 0, 0 )
    Attack.Viewpunch = Attack.Viewpunch or Angle( 10, 0, 0 )
    Attack.Range = Attack.Range or self.MeleeAttackRange
    Attack.Angle = Attack.Angle or 90

    if Attack.Relationships == nil then

      if self:IsPossessed() and GetConVar( "drgbase_possession_targetall" ):GetBool() then

        Attack.Relationships = { D_LI, D_HT, D_FR, D_NU }

      else 

        Attack.Relationships = { D_HT, D_FR } 

      end

    end

    if not istable( Attack.Relationships ) then Attack.Relationships = { Attack.Relationships } end

    self:Timer( math.Clamp( Attack.Delay, 0, math.huge ), function( self )

      local Hit = {}

      for X, Ent in ipairs( EntitiesInCone( self, Attack.Angle, Attack.Range, Attack.Relationships ) ) do

        if Ent == self or not UltrakillBase.CanAttack( Ent ) or not self:Visible( Ent ) then continue end

        local Trace = false

        local Origin = self:WorldSpaceCenter()

        local AimAt = Ent:WorldSpaceCenter()

        if isfunction( Attack.AimAt ) then

          local Res = Attack.AimAt( Ent )

          if isvector( Res ) then AimAt = Res end

        elseif isstring( Attack.AimAt ) then

          local BoneId = Ent:DrG_SearchBone( Attack.AimAt )

          if BoneId then AimAt = Ent:GetBonePosition( BoneId ) end

        end

        local Dmg = DamageInfo()

        Dmg:SetAttacker( self )

        Dmg:SetInflictor( self )

        Dmg:SetDamageType( Attack.Type )

        if Attack.Push and ( not Attack.Groundforce or Ent:IsOnGround() ) then

          Dmg:SetDamageForce( self:PushEntity( Ent, Attack.Force ) )

        else

          Dmg:SetDamageForce( self:CalcOffset( Attack.Force ) ) 

        end

        if isstring( Attack.Attachment ) or isnumber( Attack.Attachment ) then

          if isstring( Attack.Attachment ) then

            Attack.Attachment = self:LookupAttachment( Attack.Attachment )

          end

          local Attachment = self:GetAttachment( Attack.Attachment )

          if Attachment then

            if Attack.Trace then

              Trace = self:TraceLine(nil, {
                endpos = Attachment.Pos + Attachment.Pos:DrG_Direction( AimAt ),
                start = Attachment.Pos
              })

            end

            Origin = Attachment.Pos

          end

        elseif isstring( Attack.Bone ) or isnumber( Attack.Bone ) then

          if isstring( Attack.Bone ) then Attack.Bone = self:LookupBone( Attack.Bone ) end

          if isnumber( Attack.Bone ) then

            local BonePos, BoneAngles = self:GetBonePosition( Attack.Bone )

            if Attack.Trace then
              Trace = self:TraceLine(nil, {
                endpos = BonePos + BonePos:DrG_Direction( AimAt ),
                start = BonePos
              })
            end

            Origin = BonePos

          end

        elseif Attack.Trace then

          Trace = self:TraceLine( Origin:DrG_Direction( AimAt ) )

        end

        Dmg:SetDamage( ( isfunction( Attack.Damage ) and Attack.Damage( Ent, Origin ) or Attack.Damage ) * UltrakillScaleDamage( Ent ) * ( self:IsRadiant() and self.RadianceInfo.Damage or 1 )  )
        
        if Attack.Trace and Trace and Trace.Entity == Ent then

          Dmg:SetReportedPosition( Trace.HitPos )
          Dmg:SetDamagePosition( Trace.HitPos )
          Ent:DispatchTraceAttack( Dmg, Trace )

        else

          Dmg:SetReportedPosition( Origin )
          Dmg:SetDamagePosition( Origin )
          Ent:TakeDamageInfo( Dmg )

        end

        if Attack.Viewpunch and Ent:IsPlayer() then

          Ent:ViewPunch( Attack.Viewpunch )
          
        end

        UltrakillBase.SetIFrames( Ent, UltrakillBase.CalculateIFrameTime( Ent, Attack.Damage * ( self:IsRadiant() and self.RadianceInfo.Damage or 1 ) ) )

        if Attack.Damage * ( self:IsRadiant() and self.RadianceInfo.Damage or 1 ) > 500 then

          UltrakillBase.SoundScript( "Ultrakill_Hit_Low", Ent:GetPos() )

        else

          UltrakillBase.SoundScript( "Ultrakill_Hit", Ent:GetPos() )

        end

        table.insert( Hit, Ent )

      end

      if isfunction( Callback ) then Callback( self, Hit ) end

    end)

end



function ENT:TraceAttack( Trace, Attack )

  if not istable( Trace ) then return end

  Attack = Attack or {}
  Attack.Damage = Attack.Damage or 0
  Attack.Type = Attack.Type or DMG_GENERIC
  Attack.Force = Attack.Force or Vector(100, 0, 0)
  Attack.Viewpunch = Attack.Viewpunch or Angle(10, 0, 0)
  Attack.Angle = Attack.Angle or 90

  if Attack.Relationships == nil then

    if self:IsPossessed() and GetConVar( "drgbase_possession_targetall" ):GetBool() then

      Attack.Relationships = {

        [ D_LI ] = true,
        [ D_HT ] = true,
        [ D_FR ] = true,
        [ D_NU ] = true

      }

    else 

      Attack.Relationships = {

        [ D_HT ] = true,
        [ D_FR ] = true

      }

    end

  end

  if not istable( Attack.Relationships ) then

    Attack.Relationships = { 

      [ Attack.Relationships ] = true

    }

  end

  local Dist = Trace.StartPos:Distance( Trace.HitPos )

  for _, Ent in ipairs( ents.FindInCone( Trace.StartPos, Trace.Normal, Dist, math.cos( math.rad( Attack.Angle ) ) ) ) do

    if Ent == self or not UltrakillBase.CanAttack( Ent ) or not Attack.Relationships[ self:GetRelationship( Ent ) ] then continue end

    local Damage = DamageInfo()

    Damage:SetDamage( ( isfunction( Attack.Damage ) and Attack.Damage( Ent ) or Attack.Damage ) * UltrakillScaleDamage( Ent ) * ( self:IsRadiant() and self.RadianceInfo.Damage or 1 ) )
    Damage:SetDamageType( Attack.Type )
    Damage:SetInflictor( self )
    Damage:SetAttacker( self )
    Damage:SetDamageForce( self:CalcOffset( Attack.Force ) )

    Ent:TakeDamageInfo( Damage )

    UltrakillBase.SetIFrames( Ent, UltrakillBase.CalculateIFrameTime( Ent, Attack.Damage * ( self:IsRadiant() and self.RadianceInfo.Damage or 1 ) ) ) 

    if Attack.Damage * ( self:IsRadiant() and self.RadianceInfo.Damage or 1 ) > 500 then
    
      UltrakillBase.SoundScript( "Ultrakill_Hit_Low", Ent:GetPos() )
  
    else
  
      UltrakillBase.SoundScript( "Ultrakill_Hit", Ent:GetPos() )
  
    end

    self:PushEntity( Ent, Attack.Force )

    if Attack.Viewpunch and Ent:IsPlayer() then
      Ent:ViewPunch( Attack.Viewpunch )
    end


  end

end

