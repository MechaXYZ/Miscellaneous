if not istable( ENT ) or CLIENT then return end



function ENT:GetFlying()
  
  return self.Flying

end

function ENT:SetFlying( Bool )

  self.Flying = isbool( Bool ) and Bool or false 

end



function ENT:InitializeFlying()

  if not self:GetFlying() then return end

  self.loco:SetGravity( 0 )
  self:SetVelocity( vector_origin )

  self:SetFlying( true )

end



local function FlyGround( self )
  
  if not self:IsOnGround() then return end
  
  local JumpHeight = self.loco:GetJumpHeight()
  
  self.loco:SetJumpHeight( 1 )
  
  local Seq = self:GetSequence()
  local Cycle = self:GetCycle()
  local Rate = self:GetPlaybackRate()

  self.loco:Jump()
  self:ResetSequence( Seq )
  self:SetPlaybackRate( Rate )
  self:SetCycle( Cycle )
  
  self.loco:SetJumpHeight( JumpHeight )
  
end



function ENT:ApproachFlying( Pos )

  if isentity( Pos ) then Pos = Pos:GetPos() end

  local Direction = ( Pos - self:GetPos() ):GetNormalized()

  if self:IsOnGround() and Direction:Dot( Vector( 0, 0, -1 ) ) < 0 then

    FlyGround( self )

  end

  if Direction:Dot( Vector( 0, 0, -1 ) ) >= 0 and self:IsOnGround() then

    return self:Approach( Pos )
  
  end

  self:SetVelocity( Direction * self:GetDesiredSpeed() )

end



function ENT:FlyTowards( Pos )

  if isentity( Pos ) then Pos = Pos:GetPos() end

  self:FaceTowards( Pos )
  self:ApproachFlying( Pos )

end



local function ShouldCompute( self, Path, Pos )

  if not IsValid( Path ) then return true end

  local Segments = #Path:GetAllSegments()

  if Path:GetAge() >= GetConVar("drgbase_compute_delay"):GetFloat()*Segments then

    return Path:GetEnd():DistToSqr( Pos ) > ( Path:GetGoalTolerance() ^ 2 )

  else 

    return false 

  end

end



local NavMeshFlyingOffset = Vector( 0, 0, 45 )

function ENT:FollowPathFlying( Pos, Tolerance, Generator )

  if isentity( Pos ) then

    if not IsValid( Pos ) then return "unreachable" end

    if Pos:GetClass() == "npc_barnacle" then

      Pos = util.DrG_TraceLine({

        start = Pos:GetPos(), endpos = Pos:GetPos() - Vector( 0, 0, 999999 ),

        collisiongroup = COLLISION_GROUP_DEBRIS

      }).HitPos

    else 

      Pos = Pos:GetPos() 

    end

  end

  Tolerance = isnumber( Tolerance ) and Tolerance or 20

  if navmesh.IsLoaded() then

    local NavPath = self:GetPath()

    NavPath:SetGoalTolerance( Tolerance )

    local Area = navmesh.GetNearestNavArea( Pos )

    if IsValid( Area ) then Pos = Area:GetClosestPointOnArea( Pos ) or Pos end

    if not IsValid( NavPath ) and self:GetRangeSquaredTo( Pos ) <= ( NavPath:GetGoalTolerance() ^ 2 ) then return "reached" end

    if ShouldCompute( self, NavPath, Pos ) then NavPath:Compute( self, Pos, Generator ) end

    if not IsValid( NavPath ) then return "unreachable" end

    local Current = NavPath:GetCurrentGoal()

    if not self:AvoidObstacles( true ) then

      if self:GetRangeSquaredTo( Pos ) > ( Tolerance ^ 2 ) then

        self:FlyTowards( NavPath:NextSegment().pos + NavMeshFlyingOffset )

        if self.loco:IsStuck() then

          self:HandleStuck()

          return "stuck"

        else return "moving" end

      else return "reached" end

    else return "obstacle" end

  end

end



function ENT:HandleFlying( Pos )

  if isentity( Pos ) then Pos = Pos:GetPos() end

  local Obstructed = not self:VisibleVec( Pos )
  
  if Obstructed then

    return self:FollowPathFlying( Pos )

  else

    return self:FlyTowards( Pos )

  end

end


