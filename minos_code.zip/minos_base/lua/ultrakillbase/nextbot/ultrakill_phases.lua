if not istable( ENT ) then return end



-- Getters & Setters --



function ENT:GetPhase()
  
  return self:GetNW2Int( "UltrakillBase_Phase" )
  
end


function ENT:SetPhase( Int )
  
  return self:SetNW2Int( "UltrakillBase_Phase", Int )
  
end





function ENT:GetTotalPhases()
  
  return self:GetNW2Int( "UltrakillBase_TotalPhases" )
  
end


function ENT:SetTotalPhases( Int )
  
  return self:SetNW2Int( "UltrakillBase_TotalPhases", Int )
  
end



-- Hook --



function ENT:OnPhaseChange( Phase ) end



-- Updates --




local CachedSegmentsTables = {} -- Cache Phase Tables




function ENT:PhaseCheck()

  if self:GetTotalPhases() <= 1 then return end

  local MaxHP = self:GetMaxHealth()

  local HP = self:Health()

  local Segmented = CachedSegmentsTables[ self:EntIndex() ] or {}

  local TotalPhases = self:GetTotalPhases()
  local CurrentPhase = self:GetPhase()

  if table.IsEmpty( Segmented ) then

    -- Write Segmented Data --

    for X = TotalPhases, 1, -1 do

      Segmented[ #Segmented + 1 ] = {

        Threshold = ( X / TotalPhases ),
        Phase = #Segmented+1

      }

    end

    -- Cache Segmented Data --

    CachedSegmentsTables[ self:EntIndex() ] = Segmented

  end

  -- Check for Updates -- 

  for X = math.max( CurrentPhase, 2 ) , #Segmented do -- Skip Phase 1

    local Data = Segmented[ X ]

    local NextData = Segmented[ ( X + 1 ) > #Segmented and X or ( X + 1 ) ] -- Clamp it.

    if CurrentPhase < Data.Phase then

      if HP <= MaxHP * NextData.Threshold and Data ~= NextData then continue -- Skip Phases.
      elseif HP <= MaxHP * Data.Threshold then

        self:SetPhase( Data.Phase ) -- Change Networked Phase Var.
        self:OnPhaseChange( Data.Phase ) -- Call Phase Hook.

      end

    end

  end

end