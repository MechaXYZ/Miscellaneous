if not istable( ENT ) then return end

if SERVER then

  function ENT:Ultrakill_Teleport( Data, Callback )

    return print( "DEFUNCT FUNCTION USE ULTRAKILLBASE.TELEPORT!!!!!" )

  end

  function ENT:Ultrakill_AimTeleport( Data, Callback )

    return print( "DEFUNCT FUNCTION USE ULTRAKILLBASE.TELEPORT!!!!!" )

  end

end

-- Legacy, Will probably delete after a couple days. --


/* if not istable( ENT ) then return end



if SERVER then

local TeleportMask = MASK_NPCSOLID_BRUSHONLY

local function CalculateCollisionRadius( self )

  local Mins = self:GetCollisionBounds()

  return ( math.sqrt( ( math.abs( Mins.x ) ^ 2 ) * 2 ) )

end


  -- Identify Bad Vectors --


local function IsBadVector( self, Vec, Step )

  local CollisionTrace = self:DrG_TraceHull( nil, {

    start = Vec,
    endpos = Vec,
    step = Step,

  } )

  return CollisionTrace.Hit, CollisionTrace.Entity

end


  -- Teleport Resolver. Used to correct Bad Vector Teleports --


local AngleSplits = 6
local MaxRecursions = 4
local ResolverCurrentVector = Vector()
local ResolverRotation = Angle()

local function Resolver( self, Pos, Grounded, SearchDistance, Recursion )

  if not IsValid( self ) or not isvector( Pos ) then return end
  if not isnumber( SearchDistance ) then SearchDistance = 25 + CalculateCollisionRadius( self ) * 2.5 end
  if not isnumber( Recursion ) then Recursion = 1 end

  for X = 0, AngleSplits do

    ResolverCurrentVector:Zero()
    ResolverCurrentVector.x = 1

    ResolverRotation:Zero()
    ResolverRotation.y = ( 360 / AngleSplits ) * X

    ResolverCurrentVector:Rotate( ResolverRotation )

    local OutTrace = self:TraceHull( nil, {

      start = Pos + self:OBBCenter(),
      endpos = Pos + ResolverCurrentVector * SearchDistance,
      collisiongroup = COLLISION_GROUP_WORLD,
      step = true,
      mask = MASK_NPCWORLDSTATIC,

    } )

    local InTrace = self:TraceHull( nil, {

      start = OutTrace.HitPos,
      endpos = Pos,
      step = true,
      ignoreworld = true,

    } )

    UltrakillBase.Debug( "Resolver Iteration:", X .. "/" .. AngleSplits, "Recursion:", Recursion .. "/" .. MaxRecursions )

    if IsBadVector( self, InTrace.HitPos, Grounded ) and X < AngleSplits then continue
    elseif IsBadVector( self, InTrace.HitPos, Grounded ) and X >= AngleSplits and Recursion < MaxRecursions then return Resolver( self, Pos, Grounded, SearchDistance * ( Recursion + 1 ), Recursion + 1 )
    else return InTrace.HitPos end

  end

end


  -- Predict a Teleport --


local function PredictTeleport( self, Ent, Predict, Grounded )

  -- Calculate Good Prediction Pos --

  local PredictionTrace = self:TraceHull( nil, {
    start = Ent:GetPos(),
    endpos = UltrakillBase.Predict( Ent, Predict, true ),
    mask = MASK_NPCSOLID_BRUSHONLY,
    step = Grounded
  } )

  return PredictionTrace.HitPos

end


  -- Ground a Teleport --


local GroundOffset = Vector( 0, 0, 10000 )

local function GroundTeleport( self, Vec )

  local CNavArea = navmesh.GetNearestNavArea( Vec, true, 1000 )

  if navmesh.IsLoaded() and IsValid( CNavArea ) then

    local CNavPos = CNavArea:GetClosestPointOnArea( Vec )

    return CNavPos

  else

    local CollisionTrace = self:TraceHull( nil, {

      start = Vec + self:OBBCenter(),
      endpos = Vec - GroundOffset,
      mask = MASK_NPCSOLID_BRUSHONLY,
      step = true,

    } )

    return CollisionTrace.HitPos

  end

end



function ENT:Ultrakill_Teleport( Data, Callback )

    if not Data or not istable( Data ) then return end

    Data.Vec = Data.Vec or Vector( 100, 0, 0 )

    if not isentity( Data.Ent ) or not IsValid( Data.Ent ) then 

      Data.Ent = self 

    end

    local Ent = Data.Ent
    local Vec = Data.Vec

    local Pos, Ang = Ent:GetPos(), Ent:GetAngles()
    local StartPos, StartAng = self:GetPos(), self:GetAngles()
    local Destination

    -- Prediction --

    if isnumber( Data.Predict ) and Data.Predict > 0 and Data.Ent ~= self then

      Pos = PredictTeleport( self, Ent, Data.Predict, Data.Ground )

    end

    -- Offsets --

    local VecForward, VecRight, VecUp

    if Ent ~= self then

      local Vec1 = self:WorldSpaceCenter()
      local Vec2 = Ent:WorldSpaceCenter()

      local Direction = ( Vec2 - Vec1 ):Angle()

      if Data.NoZ then

        Vec1.z = 0
        Vec2.z = 0

        Direction = ( Vec2 - Vec1 ):Angle() -- No Z Axis. ( Same Z Coords. )

      end

      VecForward = Direction:Forward()
      VecRight = Direction:Right()
      VecUp = Direction:Up()

    else

      local Direction = self:GetAimAngles()

      if Data.NoZ then

        Direction = self:GetAngles()

      end

      VecForward = -Direction:Forward()
      VecRight = Direction:Right()
      VecUp = Direction:Up()

    end

    -- Collision Hull Scaling --

    local Min, Max = Ent:GetCollisionBounds()

    Vec.x = Vec.x * math.Clamp( Max.x / 70, 1, math.huge )
    Vec.y = Vec.y * math.Clamp( Max.y / 70, 1, math.huge )
    Vec.z = Vec.z * math.Clamp( Max.z / 240, 1, math.huge )

    -- Create Destination --

    local DestinationTrace = self:TraceHull( nil, {

      start = Pos,
      endpos = Pos + ( -VecForward * Vec.x + VecRight * Vec.y + VecUp * Vec.z ),
      mask = MASK_NPCSOLID_BRUSHONLY,
      collisiongroup = COLLISION_GROUP_WORLD,
      step = Data.Ground,

    } )

    Destination = DestinationTrace.HitPos

    -- Ground Teleport --

    if Data.Ground then

      Destination = GroundTeleport( self, Destination )

    end

    -- Check if Destination is Safe --

    if IsBadVector( self, Destination, Data.Ground ) then

      Destination = Resolver( self, Destination, Data.Ground )
    
    end

    -- Finalize Teleport --

    self:SetPos( Destination )
    self:SetVelocity( vector_origin ) -- Reset Velocity.

    if isfunction( Callback ) then

      Callback( self, {

        Ent = Ent,
        Pos = Pos,
        Ang = Ang,
        EndPos = Destination,
        StartPos = StartPos,
        StartAng = StartAng

      } )

    end


end



function ENT:Ultrakill_AimTeleport( Data, Callback )

  if not Data or not istable( Data ) then return end

  Data.Direction = Data.Direction or self:GetAimVector()

  Data.Distance = Data.Distance or 5000

  local Desired = Data.Direction * Data.Distance

  local Pos, Ang = self:GetPos(), self:GetAngles()
  local Destination

  local HullTrace = self:TraceHull( nil, {
    start = Pos,
    endpos = Pos + Desired,
    mask = MASK_NPCSOLID_BRUSHONLY,
    step = true,
  } )

  -- Check if Destination is Safe --

  Destination = HullTrace.HitPos

  if IsBadVector( self, Destination, true ) then

    Destination = Resolver( self, Destination, true )

  end

  -- Teleport --

  self:SetPos( Destination )
  self:SetVelocity( vector_origin )

  if isfunction( Callback ) then

    Callback( self, {

      StartPos = Pos,
      StartAng = Ang,
      EndPos = Destination + Vector( 0, 0, self:GetStepHeight() ),
      HitPos = Destination,
      HitNormal = HullTrace.HitNormal,
      Normal = HullTrace.Normal

    })

  end

end



end

