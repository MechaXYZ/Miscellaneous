if not istable( ENT ) then return end



function ENT:SetPitchFollow( Bool )

  return self:SetNW2Bool( "UltrakillBase_PitchFollow", Bool )

end

function ENT:GetPitchFollow( )

  return self:GetNW2Bool( "UltrakillBase_PitchFollow" )

end



function ENT:ApproachPitchFollow( Bone, Orientation, Desired, Rate )

  if isstring( Bone ) then Bone = self:DrG_SearchBone( Bone ) end

  local Ang = UltrakillBase.AngleDifference( self:GetAngles(), Desired )

  local Pitch = Ang.p

  Ang:Zero()

  Ang[ Orientation ] = Pitch

  local CurrentAngle = self:GetManipulateBoneAngles( Bone )
  
  UltrakillBase.AngleApproach( CurrentAngle, Ang, Rate * self:GetUpdateInterval() )

  self:ManipulateBoneAngles( Bone, CurrentAngle, false )

end



function ENT:ResetPitchFollow( Bone )

  if isstring( Bone ) then Bone = self:DrG_SearchBone( Bone ) end

  self:ManipulateBoneAngles( Bone, angle_zero, false )

end



function ENT:Vibrate( Amp, Freq, Time )

  if not isnumber( Time ) then Time = math.huge end

  if SERVER then

    self.VibrateData = { Amp = Amp, Freq = Freq, Time = CurTime() + Time }

    self:CallOnClient( "Vibrate", Amp, Freq, Time )

  end

  self.VibrateData = { Amp = Amp, Freq = Freq, Time = CurTime() + Time }

end



function ENT:GetVibrate()

  return self.VibrateData or {}
  
end

