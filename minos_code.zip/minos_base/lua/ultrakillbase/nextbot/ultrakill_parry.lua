if not istable( ENT ) then return end

function ENT:SetParryable( Bool )

  return self:SetNW2Bool( "UltrakillBase_Parryable", Bool )

end

function ENT:GetParryable()

  return self:GetNW2Bool( "UltrakillBase_Parryable" )

end

function ENT:SetInterruptable( Bool )

  return self:SetNW2Bool( "UltrakillBase_Interruptable", Bool )

end

function ENT:GetInterruptable()

  return self:GetNW2Bool( "UltrakillBase_Interruptable" )
  
end

local ParryConVar = CreateConVar( "drg_ultrakill_parry", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Enables Parrying for players.")

if SERVER then

function ENT:OnParry( Ply, Dmg )

  if not Dmg:IsDamageType( DMG_DIRECT ) then
    
    Dmg:SetDamage( Dmg:GetDamage() + 5000 )
    Dmg:SetDamageType( bit.bor( Dmg:GetDamageType(), DMG_DIRECT ) )

  end

  UltrakillBase.SoundScript( "Ultrakill_Parry", self:GetPos() )

  UltrakillBase.HitStop( 0.25 )

  self:SetParryable( false )

  UltrakillBase.OnParryPlayer( Ply )

end

function ENT:CheckParry( Dmg )

  if not ParryConVar:GetBool() then return end

  local Ply = Dmg:GetAttacker()

  if IsValid( Ply ) and Ply:IsPlayer() and self:GetParryable() and self:IsInRange( Ply, 200 ) then

    if Dmg:IsDamageType( DMG_CLUB + DMG_SLASH ) or Dmg:IsDamageType( DMG_BUCKSHOT ) and self:IsInRange( Ply, 50 ) then

      self:OnParry( Ply, Dmg )

    end

  end

end

function ENT:CheckInterrupt( Dmg, Attachment )

  if isstring( Attachment ) then Attachment = self:GetAttachment( self:LookupAttachment( Attachment ) )
  elseif isnumber( Attachment ) then Attachment = self:GetAttachment( Attachment )
  elseif not isnumber( Attachment ) and not isstring( Attachment ) then return end

  local Pos = Dmg:GetDamagePosition()
  local Ply = Dmg:GetAttacker()

  if IsValid( Ply ) and Ply:IsPlayer() and Dmg:IsBulletDamage() and not Dmg:IsDamageType( DMG_BUCKSHOT ) and self:GetInterruptable() and Attachment.Pos:DistToSqr( Pos ) <= ( 30 * self:GetModelScale() ) ^ 2 then

    self:Explosion( self:GetPos(), ( Dmg:GetDamage() + 500 ), Vector( 450, 0, 150 ), 150, 0.25, Ply, true )

    UltrakillBase.SoundScript( "Ultrakill_Ricochet", self:GetPos() )
    UltrakillBase.SoundScript( "Ultrakill_Explosion_1", self:GetPos() )

    UltrakillBase.HitStop( 0.25 )

    Ply:ScreenFade( SCREENFADE.IN, Color( 255, 255, 255, 40 ), 0.1, 0.25 )

    self:SetInterruptable( false )

    ParticleSystem3D( "ultrakill_parry_explosion", Attachment.Pos, Attachment.Ang, 1 )

    self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Shockwave", { pos = Attachment.Pos + Vector( 0, 0, 5 ), ang = Attachment.Ang, cpoints = { { pos = Vector( 25, 325, 0.75 ) } } } )
    self:ParticleEffectTimed( 1, "Ultrakill_Explosion_Sparks", { pos = Attachment.Pos + Vector( 0, 0, 5 ), ang = Attachment.Ang } )

    ParticleEffect( "Ultrakill_ExplosionSmoke", Attachment.Pos, Attachment.Ang )
    ParticleEffect( "Ultrakill_ExplosionSmokeLinger", Attachment.Pos, Attachment.Ang )

  end

end

end