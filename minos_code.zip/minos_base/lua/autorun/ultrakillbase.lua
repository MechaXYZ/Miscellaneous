if not file.Exists( "autorun/drgbase.lua", "LUA" ) then return end

if not DrGBase then

    include( "drgbase.lua" )
    AddCSLuaFile( "drgbase.lua" )

end

UltrakillBase = UltrakillBase or {}
UltrakillBase.IsLinux = system.IsLinux()

function UltrakillBase.DelayNextTick( Function, ... )

    local Args = { ... }

    return timer.Simple( engine.TickInterval(), function()

      return Function( unpack( Args ) )

    end )

end

function UltrakillBase.EyePos( Ent )
  
    if not IsValid( Ent ) or not isentity( Ent ) then return end
    
    local EntUp = Ent:GetUp()
    
    local Pos = Ent:EyePos() - ( EntUp * 10 * Ent:GetModelScale() )
    
    if not isvector( Pos ) then
  
      return Ent:WorldSpaceCenter()
  
    end
    
    return Pos
    
end


function UltrakillBase.CanAttack( EntToAttack )

    if not DrGBase.CanAttack( EntToAttack ) then return false end
    if UltrakillBase.CheckIFrames( EntToAttack ) then return false end
    if EntToAttack:IsPlayer() and ( EntToAttack:HasGodMode() or EntToAttack.Dashing ) or EntToAttack.IsDrGNextbot and EntToAttack:GetGodMode() then return false end

    return true

end

UltrakillBase.UltrakillMechanicsInstalled = file.Exists( "autorun/sh_ultrakill_ability.lua", "LUA" )

local function RefreshStamina( Ply )

    local MaxStamina = GetConVar( "ultrakill_max_stamina" ):GetInt()
    local Stamina = Ply:GetNW2Int( "AbilityStamina" )

    if Stamina >= MaxStamina then return end

    Ply:SetNW2Int( "AbilityStamina", math.min( Stamina + 3, MaxStamina ) ) -- Cap Stamina Parry Regen at 3!
    Ply.StaminaRegenTime = nil

    net.Start( "ULTRAKILL_UpdateStaminaCount" )

        net.WriteUInt( Ply:GetNW2Int( "AbilityStamina", MaxStamina ), 31 )
        net.WriteBool( false )

    net.Send( Ply )

end

function UltrakillBase.OnParryPlayer( Ply )

    if UltrakillBase.UltrakillMechanicsInstalled then

        RefreshStamina( Ply )

    end

    Ply:ScreenFade( SCREENFADE.IN, Color( 255, 255, 255, 40 ), 0.1, 0.25 )
    Ply:SetHealth( Ply:Health() > Ply:GetMaxHealth() and Ply:Health() or math.Clamp( Ply:GetMaxHealth(), 0, Ply:GetMaxHealth() - Ply:GetNW2Int( "UltrakillBase_HardDamage" ) ) )

end
  

if SERVER then

    function UltrakillBase.CallOnClient( Function, ... )

        if not game.SinglePlayer() then

            UltrakillBase.DelayNextTick( net.DrG_Send, "UltrakillBase_CallOnClient", Function, ... )

        else

            net.DrG_Send( "UltrakillBase_CallOnClient", Function, ... )

        end

    end

else

    function UltrakillBase.CallOnClient( Function, ... )

        if not isstring( Function ) or not isfunction( UltrakillBase[ Function ] ) then return end

        UltrakillBase[ Function ]( ... )

    end

    net.DrG_Receive( "UltrakillBase_CallOnClient", function( Function, ... )

        if not game.SinglePlayer() then

            UltrakillBase.DelayNextTick( UltrakillBase.CallOnClient, Function, ... )

        else

            UltrakillBase.CallOnClient( Function, ... )

        end

    end )

end


    -- Debug --


function UltrakillBase.Debug( ... )

    if GetConVar( "developer" ):GetInt() <= 0 then return end

    local DebugString = ""

    for K, V in ipairs( { ... } ) do

        DebugString = DebugString .. tostring( V ) .. "\t"

    end

    DrGBase.Info( DebugString, { chat = true } )

end

function UltrakillBase.ScreenAverage()

    return ( ScrH() + ScrW() ) * 0.5

end

function UltrakillBase.ScreenAverageClamped()

    return UltrakillBase.ScreenAverage()

end


    -- PlaceHolder --


if CLIENT then

    language.Add( "ultrakill.minosprime.boss", "MINOS PRIME" )
    language.Add( "ultrakill.sisyphusprime.boss", "SISYPHUS PRIME" )
    language.Add( "ultrakill.gabriel.boss", "GABRIEL, JUDGE OF HELL" )
    language.Add( "ultrakill.swordsmachine.boss", "SWORDSMACHINE" )
    language.Add( "ultrakill.swordsmachine.tundra.boss", "SWORDSMACHINE \"TUNDRA\"" )
    language.Add( "ultrakill.swordsmachine.agony.boss", "SWORDSMACHINE \"AGONY\"" )
    language.Add( "ultrakill.maliciousface.boss", "MALICIOUS FACE" )
    language.Add( "ultrakill.cerberus.boss", "CERBERUS, GUARDIAN OF HELL" )
    language.Add( "ultrakill.mass.boss", "HIDEOUS MASS" )
    language.Add( "ultrakill.flesh-panopticon.boss", "FLESH PANOPTICON" )

end


    -- AutoRun --


DrGBase.IncludeFolder( "ultrakillbase/Modules" )
DrGBase.IncludeFolder( "ultrakillbase/Includes/CustomCode/UltrakillBase" )


    -- ConVars --


UltrakillBase.ConVars = UltrakillBase.ConVars or {}

UltrakillBase.ConVars.DmgMult = CreateConVar( "drg_ultrakill_dmgmult", 25, { FCVAR_ARCHIVE, FCVAR_REPLICATED } )
UltrakillBase.ConVars.TakeDmgMult = CreateConVar( "drg_ultrakill_takedmgmult", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED } )

UltrakillBase.ConVars.PlyDmgMult = CreateConVar( "drg_ultrakill_plydmgmult", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Ultrakill Player Damage Multiplier ( 4x for Balanced Damage( HL2 Weps ) )" )
UltrakillBase.ConVars.PlyTakeDmgMult = CreateConVar( "drg_ultrakill_plytakedmgmult", 0.1, { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Ultrakill Player Damage Multiplier ( Scalar of How much damage a Player should take. )" )


    -- Gibs --


UltrakillBase.Gibs = UltrakillBase.Gibs or {}

UltrakillBase.Gibs.Flesh = {

    "models/ultrakill/mesh/effects/gibs/Flesh_Gib1.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib2.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib3.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib4.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib5.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib6.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib7.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib8.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib9.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib10.mdl",
    "models/ultrakill/mesh/effects/gibs/Flesh_Gib11.mdl"

}

UltrakillBase.Gibs.Rubble = {

    "models/ultrakill/mesh/effects/rubble/Rubble_Chunk1.mdl",
    "models/ultrakill/mesh/effects/rubble/Rubble_Chunk2.mdl"

}

UltrakillBase.Gibs.Virtue = "models/ultrakill/mesh/effects/virtue/Virtue_Gib.mdl"


    -- Fonts --


if CLIENT then

    local function CreateFonts()

        -- Screen Res --

        local ResolutionDelta = UltrakillBase.ScreenAverage() / 1500

        if ResolutionDelta < 1 then

            ResolutionDelta = ResolutionDelta * 1.1

        end

        -- Normal --

        surface.CreateFont( "Ultrakill_Font", { font = "VCR OSD Mono",  size = 42 * ResolutionDelta, weight = 600, antialias = true } )
        surface.CreateFont( "Ultrakill_Font_Small", { font = "VCR OSD Mono",  size = 29 * ResolutionDelta, weight = 600, antialias = true } )

        -- Subtitles --

        surface.CreateFont( "Ultrakill_SubFont", { font = "VCR OSD Mono", size = 29 * ResolutionDelta, weight = 0, antialias = true } )

    end

    CreateFonts()

    
        -- Hook. --
    

    hook.Add( "OnScreenSizeChanged" , "UltrakillBase_DynamicTextSize", function(  ) 
        
        CreateFonts()

    end )

end


    -- Foolproof this by making Dummy functions if the addon isn't installed! --


if not file.Exists( "autorun/3d_particle_system_helpers.lua", "LUA" ) then

    ParticleSystem3D = function() end
    game.Add3DParticles = function() end

end


    -- Precaching --


function UltrakillBase.RecursiveSearch( Dir, DirPath, Ext ) -- Neat Function to Find what I want to precache.

    local Folders = select( 2, file.Find( Dir .. "/*", DirPath ) ) -- Find all Folders.
    local Files = file.Find( Dir .. "/*" .. Ext, DirPath )

    local Table = {}

    for I, File in ipairs( Files ) do
        
        Table [ Dir .. "/" .. File ] = File

    end

    for I, Folder in ipairs( Folders ) do

        table.Merge( Table, UltrakillBase.RecursiveSearch( Dir .. "/" .. Folder, DirPath, Ext ) )

    end

    return Table

end

local Particles3D = {
    "ultrakill_mp_explosion",
    "ultrakill_sp_explosion",
    "ultrakill_sp_sparklecharge",
    "ultrakill_sp_sparklecharge_hand",
    "ultrakill_sp_sparkleexplosion",
    "ultrakill_bigrubble",
    "ultrakill_bigrubble_sp",
    "ultrakill_rubble",
    "ultrakill_rubble_sp",
    "ultrakill_rock",
    "ultrakill_gab_intro",
    "ultrakill_vg_intro",
    "ultrakill_vg_slam_explosion",
    "ultrakill_vg_explosion",
    "ultrakill_parry_explosion",
    "ultrakill_virtueshatter",
    "ultrakill_virtueshatter_huge",
    "ultrakill_shotgun_charge",
    "ultrakill_stray_charge",
    "ultrakill_schism_charge",
    "ultrakill_stalker_explosion",
    "ultrakill_mindflayer_explosion",
    "ultrakill_malicious_explosion",
    "ultrakill_cerberus_explosion",
}

local Models = UltrakillBase.RecursiveSearch( "models/ultrakill", "GAME", ".mdl" )

for _, File in ipairs( Particles3D ) do

    game.Add3DParticles( "particles/" .. File .. ".lua", "LUA" )

end

for File, FileName in pairs( Models ) do

    util.PrecacheModel( File )

end

UltrakillBase.GabrielInstalled = file.Exists( "entities/ultrakill_gabriel.lua", "LUA" )
UltrakillBase.SisyphusPrimeInstalled = file.Exists( "entities/ultrakill_sisyphusprime.lua", "LUA" )
UltrakillBase.FleshPanopticonInstalled = file.Exists( "entities/ultrakill_fleshpanopticon.lua", "LUA" )
UltrakillBase.MinosPrimeInstalled = file.Exists( "entities/ultrakill_minosprime.lua", "LUA" )
UltrakillBase.PreludeInstalled = file.Exists( "entities/ultrakill_filth.lua", "LUA" )
UltrakillBase.Act1Installed = file.Exists( "entities/ultrakill_mindflayer.lua", "LUA" )

DrGBase.AddParticles( "Ultrakill_Gabriel.pcf", {

    "Ultrakill_Gabriel_ZweiTrail",
    "Ultrakill_Gabriel_KatanaTrail",
    "Ultrakill_Gabriel_SpearTrail",
    "Ultrakill_Gabriel_BladeTrail",
    "Ultrakill_Gabriel_WeaponSpawn",
    "Ultrakill_Gabriel_WeaponBreak",
    "Ultrakill_Gabriel_Sparkles",
    "Ultrakill_Gabriel_Dash",
    "Ultrakill_Gabriel_Break",
    "Ultrakill_Gabriel_BigBreak",

} )

DrGBase.AddParticles( "Ultrakill_Videogames.pcf", {

    "Ultrakill_VideogamesPhase",
    "Ultrakill_VideogamesPhase_Rings",
    "Ultrakill_VideogamesPhaseChange",
    "Ultrakill_VideogamesTeleport",
    "Ultrakill_VideogamesSwing_Ring",

} )

DrGBase.AddParticles( "Ultrakill_SisyphusPrime.pcf", {

    "Ultrakill_SisyphusPhase",
    "Ultrakill_SisyphusPhase_Rings",
    "Ultrakill_SisyphusPhaseChange",
    "Ultrakill_SisyphusProjectileCharge",
    "Ultrakill_SisyphusProjectileCharge_Huge",
    "Ultrakill_SisyphusSparkles",
    "Ultrakill_SisyphusTeleport",
    "Ultrakill_SisyphusBloodSwing_Ring",

} )
  
DrGBase.AddParticles( "Ultrakill_MinosPrime.pcf", {

    "Ultrakill_MinosPhase",
    "Ultrakill_MinosPhase_Rings",
    "Ultrakill_MinosPhaseChange",
    "Ultrakill_MinosHeavyTrail",
    "Ultrakill_PrimeOrb",
    "Ultrakill_MinosOutro",
    "Ultrakill_MinosSparks",
    "Ultrakill_MinosProjectileCharge",
    "Ultrakill_MinosSnakeBlue_Ring",
    "Ultrakill_MinosSnakeYel",
    "Ultrakill_MinosSnakeYel_Ring",

} )


-- Act 1 --

DrGBase.AddParticles( "Ultrakill_Act1.pcf", {

    "Ultrakill_ShotgunHusk_Trail",
    "Ultrakill_Portal_Mindflayer",
    "Ultrakill_Portal_HideousMass",
    "Ultrakill_Drone_Charge",
    "Ultrakill_Mindflayer_Beam",
    "Ultrakill_Mindflayer_Beam_End",
    "Ultrakill_Mindflayer",
    "Ultrakill_Mindflayer_Charging",
    "Ultrakill_Mindflayer_Trail",
    "Ultrakill_Mindflayer_Sparks",
    "Ultrakill_CyanProj",
    "Ultrakill_MortarTrail",
    "Ultrakill_CyanProj_Impact",
    "Ultrakill_HellProj_ChargeShotgun",
    "Ultrakill_StreetCleaner_Flames",

} )

DrGBase.AddParticles( "Ultrakill_Prelude.pcf", {

    "Ultrakill_Filth_Trail",
    "Ultrakill_Cerberus_OrbTrail",
    "Ultrakill_Cerberus_Dodge",
    "Ultrakill_Portal_Filth",
    "Ultrakill_Portal_Stray",
    "Ultrakill_Portal_SwordsMachine",
    "Ultrakill_Portal_Cerberus",
    "Ultrakill_Malicious_Charge",
    "Ultrakill_HellProj_Charge",
    "Ultrakill_HellProj_ChargeBig",
    "Ultrakill_SwordsMachine_Trail",
    "Ultrakill_Muzzleflash_Shotgun",
    "Ultrakill_Shotgun_Sparks",
    "Ultrakill_Shotgun_Trail",

} )
  
DrGBase.AddParticles( "Ultrakill_Shared.pcf", {

    "Ultrakill_AlertParryable",
    "Ultrakill_AlertUnparryable",
    "Ultrakill_AlertShotgun",
    "Ultrakill_Enraged",
    "Ultrakill_Enraged_Deactivate",
    "Ultrakill_Blood",
    "Ultrakill_ExplosionSmoke",
    "Ultrakill_ExplosionSmokeLinger",
    "Ultrakill_Explosion_Sparks",
    "Ultrakill_RubbleSmoke",
    "Ultrakill_RubbleSmoke_Big",
    "Ultrakill_Portal_Heavy",
    "Ultrakill_Portal_Red",
    "Ultrakill_HellProj_Trail",
    "Ultrakill_HellProj_Impact",
    "Ultrakill_Sand",
    "Ultrakill_Radiance",
    "Ultrakill_Sand_Drip",
    "Ultrakill_SandExplosion",
    "Ultrakill_SandExplosionStalker",
    "Ultrakill_VirtueShatter_Trail",
    "Ultrakill_VirtueShatter_Sparks",
    "Ultrakill_VirtueShatter_Shockwave",
    "Ultrakill_White_Trail",

} )


    -- Menus --


if CLIENT then



hook.Add( "PopulateToolMenu", "DrGBaseUltrakillMenu", function()

spawnmenu.AddToolMenuOption( "DrGBase", "ULTRAKILL", "drgbase_ultrakill_settings", "General Settings", "", "", function( Panel )

    Panel:Clear()

    Panel:Help("\nGeneral Settings")

    Panel:ControlHelp("\nServerside")

    if game.SinglePlayer() or LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then

        local Diff = Panel:ComboBox( "Difficulty", "drg_ultrakill_difficulty" )

        Panel:ControlHelp( "Difficulty Affects Speed of enemy attacks." )

        Diff:SetSortItems( false )

        Diff:AddChoice( "HIDDEN MANSION", nil, false, "models/ultrakill/vfx/Skull2_4" )
        Diff:AddChoice( "HARMLESS", nil, false, "models/ultrakill/vfx/Skull2_4" )
        Diff:AddChoice( "LENIENT", nil, false, "models/ultrakill/vfx/Skull2_4" )
        Diff:AddChoice( "STANDARD", nil, false, "models/ultrakill/vfx/Skull2" )
        Diff:AddChoice( "VIOLENT", nil, false, "models/ultrakill/vfx/Skull2" )
        Diff:AddChoice( "BRUTAL", nil, false, "models/ultrakill/vfx/Skull2_1" )
        Diff:AddChoice( "ULTRAKILL MUST DIE", nil, false, "models/ultrakill/vfx/Skull2_1" )

        Panel:Help("\nDamage Multipliers")

        Panel:NumSlider("Damage Multiplier", "drg_ultrakill_dmgmult", 0.001, 1000, 3 )
        Panel:ControlHelp("Multiplys the Damage the NextBots Deal to Non-Players.")

        Panel:NumSlider("Take Damage Multiplier", "drg_ultrakill_takedmgmult", 0.001, 1000, 3 )
        Panel:ControlHelp("Multiplys the Damage NextBots take fron Non-Players.")

        Panel:NumSlider("Player Damage Multiplier", "drg_ultrakill_plydmgmult", 0.001, 1000, 3 )
        Panel:ControlHelp("Multiplys the Damage the Player Deals to the NextBots. 4x makes HL2 Weapons deal a balanced amount of Damage.")

        Panel:NumSlider("Player Take Damage Multiplier", "drg_ultrakill_plytakedmgmult", 0.001, 1000, 3 )
        Panel:ControlHelp("Multiplys the Damage the NextBots Deal to Players. 0.1x is Recommended.")

        Panel:Help("\nMechanics")

        Panel:CheckBox( "Parrying", "drg_ultrakill_parry" )
        Panel:ControlHelp( "Enables Player Parrying. Enables for Melee Attacks." )

        Panel:CheckBox( "Parrying Projectiles", "drg_ultrakill_parry_projectile" )
        Panel:ControlHelp( "Enables Player Parrying. Enables for Projectiles." )

        Panel:Help("\nEffects")

        Panel:CheckBox("Enable Slow Motion Effect", "drg_ultrakill_slowmo")
        Panel:ControlHelp("Enables Slow Motion.")

        Panel:CheckBox("Enable HitStop Effect", "drg_ultrakill_hitstop")
        Panel:ControlHelp("Enables HitStop.")

        Panel:CheckBox("Enable Dynamic Lights", "drg_ultrakill_lights")
        Panel:ControlHelp("Enable/Disable Dynamic Lights for NextBots. May impact performance.")

    else

        Panel:Help("You are not an admin!")
        Panel:ControlHelp("Notice: Only admins can change this settings.")

    end

    Panel:ControlHelp("\nClientSide")

    Panel:CheckBox("Enable Gibs", "drg_ultrakill_gibs")
    Panel:ControlHelp("Enable/Disable Gibs. May impact performance.")

    Panel:CheckBox("Enable Blood Particles", "drg_ultrakill_blood")
    Panel:ControlHelp("Enable/Disable Blood Particles. Can impact performance when numerous particles are present.")

    Panel:NumSlider("Amount of Blood Particles", "drg_ultrakill_bloodamount", 1, 50, 0 )
    Panel:ControlHelp("Max Amount of Blood Particles per Instance. High Values will impact performance. Recommended is 5")

    Panel:CheckBox("Enable Subtitles", "drg_ultrakill_subtitles")
    Panel:ControlHelp("Enable/Disable Subtitles.")

    Panel:CheckBox("Enable Boss HP Bar", "drg_ultrakill_healthbar")
    Panel:ControlHelp("Enable/Disable Boss Healthbars")

end)

if UltrakillBase.MinosPrimeInstalled then

    spawnmenu.AddToolMenuOption( "DrGBase", "ULTRAKILL", "drgbase_ultrakill_minosprime", "Minos Prime Settings", "", "", function( Panel )

        Panel:Clear()

        Panel:Help("\nMinos Prime Settings")

        Panel:ControlHelp("\nServerSide")

        if game.SinglePlayer() or LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then

            Panel:CheckBox( "Enable Intro", "drg_ultrakill_minosintro" )
            Panel:ControlHelp( "Enable/Disable Minos Prime Intro." )

            Panel:CheckBox( "Enable Outro", "drg_ultrakill_minosoutro" )
            Panel:ControlHelp( "Enable/Disable Minos Prime Outro." )

        else

            Panel:Help( "You are not an admin!" )
            Panel:ControlHelp( "Notice: Only admins can change this settings." )

        end

    end )

end

if UltrakillBase.GabrielInstalled then

    spawnmenu.AddToolMenuOption( "DrGBase", "ULTRAKILL", "drgbase_ultrakill_gabriel", "Gabriel Settings", "", "", function( Panel )

        Panel:Clear()

        Panel:Help("\nGabriel Settings")

        Panel:ControlHelp("\nServerSide")

        if game.SinglePlayer() or LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then

            Panel:CheckBox( "Enable Intro", "drg_ultrakill_gabrielintro" )
            Panel:ControlHelp( "Enable/Disable Gabriel Intro." )

            Panel:CheckBox("Enable Outro", "drg_ultrakill_gabrieloutro" )
            Panel:ControlHelp( "Enable/Disable Gabriel Outro." )

        else

            Panel:Help( "You are not an admin!" )
            Panel:ControlHelp( "Notice: Only admins can change this settings." )

        end

    end )

end


if UltrakillBase.FleshPanopticonInstalled then

    spawnmenu.AddToolMenuOption( "DrGBase", "ULTRAKILL", "drgbase_ultrakill_fleshpanopticon", "Flesh Panopticon Settings", "", "", function( Panel )

        Panel:Clear()

        Panel:Help("\nFlesh Panopticon Settings")

        Panel:ControlHelp("\nServerSide")

        if game.SinglePlayer() or LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then

            Panel:CheckBox("Enable Outro", "drg_ultrakill_fleshpanopticonoutro")
            Panel:ControlHelp( "Enable/Disable Outro. Enabling this will spawn Sisyphus Prime on death." )

        else

            Panel:Help("You are not an admin!")
            Panel:ControlHelp("Notice: Only admins can change this settings.")

        end

    end )

end

if UltrakillBase.SisyphusPrimeInstalled then

    spawnmenu.AddToolMenuOption( "DrGBase", "ULTRAKILL", "drgbase_ultrakill_sisyphusprime", "Sisyphus Prime Settings", "", "", function( Panel )

        Panel:Clear()

        Panel:Help("\nSisyphus Prime Settings")

        Panel:ControlHelp("\nServerSide")

        if game.SinglePlayer() or LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then

            Panel:CheckBox("Enable Intro", "drg_ultrakill_sisyphusintro")
            Panel:ControlHelp("Enable/Disable Intro.")

            Panel:CheckBox("Enable Outro", "drg_ultrakill_sisyphusoutro")
            Panel:ControlHelp("Enable/Disable Outro.")

        else

            Panel:Help("You are not an admin!")
            Panel:ControlHelp("Notice: Only admins can change this settings.")

        end

    end )

end


spawnmenu.AddToolMenuOption( "DrGBase", "ULTRAKILL", "drgbase_ultrakill_healing", "Healing Settings", "", "", function( Panel )

    Panel:Clear()

    Panel:Help( "\nHealing" )

    if game.SinglePlayer() or LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then

        Panel:ControlHelp("\nDo not use this with the Blood is Fuel addon, as it will cause some issues.")

        Panel:CheckBox("Enable Healing", "drg_ultrakill_healing")
        Panel:ControlHelp("Enable/Disable Healing.")

        Panel:NumSlider("Healing Range", "drg_ultrakill_healing_range", 1, 10000, 0 )
        Panel:ControlHelp("Sets the Maximum range for Healing.")

        Panel:NumSlider("Max Healing", "drg_ultrakill_healing_maxheal", 0, 1000, 0 )
        Panel:ControlHelp("Sets the Maximum amount of Healing Per Damage Instance.")

        Panel:CheckBox("Ultrakill Only", "drg_ultrakill_healing_ultrakillonly")
        Panel:ControlHelp("Enable for only Healing against Ultrakill Enemies.")

        Panel:ControlHelp("\nHard Damage")

        Panel:CheckBox("Enable Hard Damage", "drg_ultrakill_healing_harddamage")
        Panel:ControlHelp("Enable/Disable Hard Damage.")

        Panel:NumSlider("Hard Damage Multiplier", "drg_ultrakill_healing_harddamage_multiplier",0.01,10,2)
        Panel:ControlHelp("Multiplys the amount of Hard Damage you receive.")

        Panel:NumSlider("Hard Damage Recovery Multiplier", "drg_ultrakill_healing_harddamage_recovery_multiplier",0.01,10,2)
        Panel:ControlHelp("Multiplys how quickly Hard Damage begins to recover.")

        Panel:CheckBox("Enable Hard Damage Enforce", "drg_ultrakill_healing_harddamage_enforce")
        Panel:ControlHelp("Enable/Disable Enforcing Hard Damage. Health under no cirumstance can be above the Hard Damage cap.")

    else

        Panel:Help("You are not an admin!")
        Panel:ControlHelp("Notice: Only admins can change this settings.")

    end

end )



spawnmenu.AddToolMenuOption("DrGBase", "ULTRAKILL", "drgbase_ultrakill_sound", "Sound Settings", "", "", function( Panel )

    Panel:Clear()

    Panel:Help( "\nSound Settings" )

    Panel:NumSlider( "Volume", "drg_ultrakill_sound_volume", 0, 10, 3 )
    Panel:ControlHelp( " Volume slider for all Sound effects. " )

    Panel:CheckBox( "Enable Dying Pitch", "drg_ultrakill_sound_dying_pitch" )
    Panel:ControlHelp( "Enable/Disable Sounds slowly pitching down into zero when dead." )

end)



spawnmenu.AddToolMenuOption("DrGBase", "ULTRAKILL", "drgbase_ultrakill_music", "Music Settings", "", "", function( Panel )

    Panel:Clear()

    Panel:Help( "\nMusic Settings" )

    Panel:NumSlider( "Volume", "drg_ultrakill_music_volume", 0, 10, 3 )
    Panel:ControlHelp( " Volume slider for all Music. " )

    if UltrakillBase.MinosPrimeInstalled then

        Panel:CheckBox( "Enable Minos Prime Music", "drg_ultrakill_minosmusic" )
        Panel:ControlHelp( "Enable/Disable Minos Prime's Music." )

    end

    if UltrakillBase.SisyphusPrimeInstalled then

        Panel:CheckBox( "Enable Sisyphus Prime Music", "drg_ultrakill_sisyphusmusic" )
        Panel:ControlHelp( "Enable/Disable Sisyphus Prime's Music." )

    end

    if UltrakillBase.FleshPanopticonInstalled then

        Panel:CheckBox( "Enable Flesh Panopticon Music", "drg_ultrakill_fleshpanopticonmusic" )
        Panel:ControlHelp( "Enable/Disable Flesh Panopticon's Music." )

    end

    if UltrakillBase.GabrielInstalled then

        Panel:CheckBox( "Enable Gabriel Music", "drg_ultrakill_gabrielmusic" )
        Panel:ControlHelp( "Enable/Disable Gabriel's Music." )

    end

    if UltrakillBase.PreludeInstalled then

        Panel:CheckBox( "Enable Cerberus Music", "drg_ultrakill_cerberusmusic" )
        Panel:ControlHelp( "Enable/Disable Cerberus' Music." )

        Panel:CheckBox( "Enable SwordsMachine Music", "drg_ultrakill_swordsmachinemusic" )
        Panel:ControlHelp( "Enable/Disable SwordsMachine's Music." )

        Panel:CheckBox( "Enable Malicious Face Music", "drg_ultrakill_maliciousfacemusic" )
        Panel:ControlHelp( "Enable/Disable Malicious Face's Music." )

    end

    if UltrakillBase.Act1Installed then

        Panel:CheckBox( "Enable Hideous Mass Music", "drg_ultrakill_hideousmassmusic" )
        Panel:ControlHelp( "Enable/Disable Hideous Mass' Music." )

    end

end )



end )



end



if SERVER then

    hook.Add( "PlayerInitialSpawn", "UltrakillBase_Requirements", function( Ply )

       if not file.Exists( "autorun/3d_particle_system_helpers.lua", "LUA" ) then

            timer.Simple( 2, function()

                PrintMessage( HUD_PRINTTALK, "[ULTRAKILLBase]\t3D Particle System Base is not Installed! Although you do not NEED 3D Particle System Base for UltrakillBase to work, not having it installed disables all 3D Particles." )

            end )

        end

        if not file.Exists( "autorun/drgbase.lua", "LUA" ) then

            timer.Simple( 2, function()

                Ply:PrintMessage( HUD_PRINTTALK, "[ULTRAKILLBase]\tDrGBase is not Installed! Please Install DrGBase to allow UltrakillBase to function." )

            end )

        end

    end )

end

