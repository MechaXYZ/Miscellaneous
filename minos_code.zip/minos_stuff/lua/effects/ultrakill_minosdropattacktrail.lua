
  -- Localize Libaries & Functions --


local table = table
local render = render
local CurTime = CurTime

-- Localized Vars --

local Dietime = 5

local Mat = Material( "particles/ultrakill/Snake_Trail" )

local UnitsPerPoint = 100

local KeyFrames = {
	{ Color = Color(255, 255, 255, 75 ), Size = 0 },
	{ Color = Color(100, 207, 255, 85 ), Size = 0.25 },
	{ Color = Color(45, 173.121024, 255, 105 ), Size = 0.3 },
	{ Color = Color(0, 113.121024, 255, 115 ), Size = 0.4 },
	{ Color = Color(0, 113.121024, 255, 125 ), Size = 0.6 },
	{ Color = Color(0, 113.121024, 255, 135 ), Size = 0.8 },
	{ Color = Color(0, 113.121024, 255, 145 ), Size = 1 },
	{ Color = Color(0, 113.121024, 255, 155 ), Size = 1 },
	{ Color = Color(0, 113.121024, 255, 165 ), Size = 1 },
	{ Color = Color(0, 113.121024, 255, 195 ), Size = 1 },
	{ Color = Color(0, 113.121024, 255, 225 ), Size = 1 },
}

function EFFECT:Init( Data ) 

	-- Since this Lua Effect is required to make this effect, tried multiple methods with the 3D particle base to no avail.
	-- So I'll just revamp the current one.

	self.Ent = Data:GetEntity()

	self.StartPos = Data:GetStart()
	self.EndPos = Data:GetOrigin()

	self.InitTime = CurTime()

	self:SetRenderBounds( Vector( 10000, 10000, 10000 ), -Vector( 10000, 10000, 10000 ) )

	self.Points = {}

	-- Create Points --

	local NumOfPoints = self.StartPos:Distance( self.EndPos ) / UnitsPerPoint

	for X = 1, NumOfPoints do

		local Vec = LerpVector( ( 1 / NumOfPoints ) * X , self.StartPos, self.EndPos )

		local Time = CurTime() + ( 0.225 * ( X / NumOfPoints ) )

		table.insert( self.Points, { Pos = Vec, Life = Time } )

	end

	ParticleEffect( "Ultrakill_MinosHeavyTrail", self.StartPos, Angle( 0, 0, 0 ) )

end

function EFFECT:Think()

	if CurTime() - self.InitTime > Dietime or not IsValid(self.Ent) then
		return false
	end

   	return true

end

function EFFECT:Render()

	render.SetMaterial( Mat )

	render.StartBeam( #self.Points )

		for X = 1, #self.Points do

			if not istable( self.Points[X] ) then continue end

   			local Frac = X / #self.Points

   			local Frame = KeyFrames[X] or KeyFrames[#KeyFrames]

   			local Col = Frame.Color

   			render.AddBeam( self.Points[X].Pos, 40 * Frame.Size, ( ( 1 / #self.Points ) * ( X + 1 ) ) * 17.5 , Col )

   			if istable( self.Points[X] ) and CurTime() > self.Points[X].Life then

   				table.remove( self.Points, X )

   			end

		end

	render.EndBeam()

end
