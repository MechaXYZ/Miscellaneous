
  -- Localize Libaries & Functions --


local table = table
local render = render
local CurTime = CurTime

-- Localized Vars --

local DieTime = 0.75

local Spacing = 25
local EmissionRate = 200  -- Points / Second

local Mat = Material( "particles/ultrakill/Snake_Trail" )

local Offset = Vector( 0, 0, 35 ) * 1.5
local OffsetAngle = Angle( 0, 0, 0 )
local ColorObject = Color( 255, 255, 255, 255 )

local Offsets = {
	{ Vector( -25, -10, 25 ) * 1.5, Angle( -90, 90, 0 ) }, -- Boxing #1
	{ Vector( 40, -5, 25 ) * 1.5, Angle( -90, 90, 90 ) }, -- Boxing #2
	{ Vector( 0, 35, 8 ) * 1.5, Angle( 0, 90, 180 ) }, -- Boxing #3
	{ Vector( -5, 35, 20 ) * 1.5, Angle( 0, 0, 0 ) }, -- Boxing #4
	{ Vector( 0, 50, -35 ) * 1.5, Angle( 0, -90, 90 ) }, -- Combo #1
	{ Vector( 0, 50, -15 ) * 1.5, Angle( -90, -90, 0 ) }, -- Combo #2
	{ Vector( 0, 5.35, 41 ) * 1.5, Angle( 0, 0, 0 ) }, -- Downswing
	{ Vector( -28, -28, 6 ) * 1.5, Angle( -120, -30, -5 ), 0.5 }, -- Uppercut
}

local function OutEase( x )

	return x == 1 && 1 || 1 - ( 2 ^ ( -7 * x ) )

end

function EFFECT:Init( Data ) 

	-- Since this Lua Effect is required to make this effect, tried multiple methods with the 3D particle base to no avail.
	-- So I'll just revamp the current one.

	self.ParentBoneAttach = Data:GetAttachment()
	self.ParentTime = ( Data:GetRadius() / 100 ) -- CEffectData:SetRadius() has bad networking for float precision, so...
	self.Ent = Data:GetEntity()

	self.InitTime = CurTime()

	if not IsValid( self.Ent ) then return end

	self.Sequence = self.Ent:GetSequence()

	self.Points = {}

	local Flag = Data:GetFlags()

	self.Offset = Offsets[ Flag ][1] or Offset
	self.OffsetAngle = Offsets[ Flag ][2] or OffsetAngle
	self.DieTime = Offsets[ Flag ][3] or 0

	if IsValid(self.Ent) then

		self:SetParent( self.Ent )

		self.Snake = ClientsideModel("models/ultrakill/mesh/effects/minosprime/SnakeHead.mdl")

		self.Snake:SetPos( self.Ent:WorldSpaceCenter() )
		self.Snake:SetAngles( self.Ent:GetAngles() )
		self.Snake:SetModelScale( 1.2 )
		self.Snake:AddEffects( EF_NODRAW )

	end

	timer.Simple( engine.TickInterval(), function()

		if not IsValid( self.Snake ) then return end

		ParticleEffect("Ultrakill_MinosSnakeBlue_Ring", self.Snake:GetPos(), self.Snake:GetAngles() )

	end )

	self:SetRenderBounds( Vector( 1000, 1000, 1000 ), -Vector( 1000, 1000, 1000 ) )

end

function EFFECT:Think()

	if CurTime() - self.InitTime > ( DieTime + self.ParentTime ) or not IsValid( self.Ent ) then

		SafeRemoveEntity( self.Snake )

		return false

	end

	if isentity( self.Ent ) and IsValid( self.Ent ) and self.Sequence == self.Ent:GetSequence() then

		local BoneMatrix = self.Ent:GetBoneMatrix( self.ParentBoneAttach )

		BoneMatrix:Translate( self.Offset )
		BoneMatrix:Rotate( self.OffsetAngle )

		if CurTime() - self.InitTime < self.ParentTime then

			self.Snake:SetPos( BoneMatrix:GetTranslation() )
			self.Snake:SetAngles( BoneMatrix:GetAngles() )

			self:SetPos( self.Snake:GetPos() )

		end

	end

   	return IsValid( self.Snake )

end

function EFFECT:Render()

	if not IsValid( self.Snake ) then return false end

	self.Points = self.Points or {}

	if not isnumber( self.LastCurTime ) or ( CurTime() - self.LastCurTime > ( 1 / EmissionRate ) and CurTime() - self.InitTime < self.ParentTime ) and self.LastPos:DistToSqr( self.Snake:GetPos() ) > Spacing ^ 2 then

		table.insert( self.Points, { Pos = self.Snake:GetPos(), Life = CurTime() + self.DieTime } )

		self.LastCurTime = CurTime()
		self.LastPos = self.Snake:GetPos()

	end

	render.SetMaterial( Mat )

	render.StartBeam( #self.Points + 1 )

		for X = 1, #self.Points do

			if not istable( self.Points[X] ) then continue end

			local Delta = OutEase( ( X - 1 ) / ( #self.Points - 1 ) ) 

			ColorObject.r = Lerp( Delta, 255, 80.5896135 )
			ColorObject.g = Lerp( Delta, 255, 198.915121 )
			ColorObject.b = Lerp( Delta, 255, 255 )
			ColorObject.a = Lerp( Delta, 0, 255)

   			render.AddBeam( self.Points[X].Pos, 26 * Delta, ( 1 / #self.Points ) * ( X + 1 ) * 20, ColorObject )

   			if istable( self.Points[X] ) and self.DieTime > 0 and CurTime() > self.Points[X].Life then
				
   				table.remove( self.Points, X )

   			end

		end

		ColorObject.r = 80.5896135
		ColorObject.g = 198.915121
		ColorObject.b = 255
		ColorObject.a = 255

		render.AddBeam( self.Snake:GetPos(), 22, ( 1 / #self.Points ) * ( #self.Points + 1 ) * 20, ColorObject )

	render.EndBeam()

	self.Snake:DrawModel()

end
