if not DrGBase or not UltrakillBase then return end -- return if DrGBase or UltrakillBase isn't installed
ENT.Base = "ultrakillbase_projectile"

-- Misc --

ENT.PrintName = "Prime Orb"
ENT.Category = "UltrakillBase"
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.Models = {"models/ultrakill/mesh/effects/minosprime/Prime_Orb.mdl"}
ENT.ModelScale = 1.35
ENT.Spawnable = false

-- Physics --

ENT.Gravity = false
ENT.Physgun = false
ENT.Gravgun = false

-- Parry --

ENT.Ultrakill_Parryable = false

if SERVER then

  AddCSLuaFile()

function ENT:CustomInitialize()

  ParticleEffectAttach( "Ultrakill_PrimeOrb", PATTACH_POINT_FOLLOW, self, 1 )

  UltrakillBase.SoundScript( "Ultrakill_Checkpoint_Ambiance", self:GetPos(), self ,0 )

  self:AddDynamLight( "Outro_Light", self, Color( 0, 75, 255 ), 600, 4, 1, 1 )

  self.DieTime = CurTime() + 8.48333333

  self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )

  self:SetSequence( "Intro" )
  self:SetPlaybackRate( 1 )
  self:SetCycle( 0 )

end

function ENT:CustomThink()

  if CurTime() > self.DieTime then
    
    ParticleSystem3D( "ultrakill_virtueshatter_huge", self:GetPos(), self:GetAngles(), 1 )
    self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Shockwave", { pos = self:GetPos() + Vector( 0, 0, 5 ), ang = self:GetAngles(), cpoints = { { pos = Vector( 75, 1000, 1 ) } } } )
    self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Sparks", { pos = self:GetPos() + Vector( 0, 0, 5 ), ang = self:GetAngles() } )

    self:CreateGibs( { 

      Position = self:GetPos(),
      Models = UltrakillBase.Gibs.Virtue,
      Amount = 8,
      Velocity = 1000,
      ModelScale = 3.5,
      Trail = "Ultrakill_VirtueShatter_Trail",

    } )

    self:ScreenShake( 450, 10, 1, 3550 )

    for X, Ent in ipairs( ents.FindInSphere( self:GetPos(), 500 ) ) do

      if not IsValid( Ent ) or Ent == self or Ent:GetOwner() == self then continue end

      local Dir = ( Ent:GetPos() - self:GetPos() ):GetNormalized()

      self:PushEntity( Ent, Vector( 700, 0, 500 ) )

    end

    SafeRemoveEntity( self )

    return false

  end

  self:FrameAdvance()

end

end
