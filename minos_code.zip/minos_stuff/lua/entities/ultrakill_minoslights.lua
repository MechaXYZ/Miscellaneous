if not DrGBase or not UltrakillBase then return end -- return if DrGBase or UltrakillBase isn't installed
ENT.Base = "ultrakillbase_projectile"

-- Misc --

ENT.PrintName = "Minos_OutroLights"
ENT.Category = "UltrakillBase"
ENT.RenderGroup = RENDERGROUP_BOTH
ENT.Models = {"models/ultrakill/mesh/effects/vol_lights/Outro_Light.mdl"}
ENT.ModelScale = 1.35
ENT.Spawnable = false

-- Physics --

ENT.Gravity = false
ENT.Physgun = false
ENT.Gravgun = false

-- Parry --

ENT.Ultrakill_Parryable = false

if SERVER then

  AddCSLuaFile()

function ENT:CustomInitialize()

  self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )

  self.Light = self:AddDynamLight( "Outro_Light", vector_origin, Color(255,255,255), 400, 3, 1, 0 )

  if IsValid( self.Light ) then

    self.Light:SetParent()

  end

  local Angles = self:GetAngles()

  Angles:RotateAroundAxis( Angles:Right(), -90 )

  self:ParticleEffectTimed( 10, "Ultrakill_MinosOutro", { pos = self:GetPos(), ang = Angles, parent = self, keepoffset = true } )

end

function ENT:CustomThink()

  if IsValid( self.Light ) then

    local Trace = util.QuickTrace( self:GetPos(), -self:GetUp() * 5000, self )

    self.Light:SetPos( Trace.HitPos )

    if not IsValid( self:GetOwner() ) then

      SafeRemoveEntity(self)

    end

  end

end

end
