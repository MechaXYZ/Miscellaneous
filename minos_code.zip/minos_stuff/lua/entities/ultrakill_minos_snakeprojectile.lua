if not DrGBase or not UltrakillBase then return end -- return if DrGBase or UltrakillBase isn't installed
ENT.Base = "ultrakillbase_projectile"

-- Misc --

ENT.PrintName = "SnakeHead_Projectile"
ENT.Category = "UltrakillBase"
ENT.RenderGroup = RENDERGROUP_OPAQUE
ENT.Models = { "models/ultrakill/mesh/effects/minosprime/SnakeHead.mdl" }
ENT.ModelScale = 1.2
ENT.Spawnable = false

-- Physics --

ENT.Gravity = false
ENT.Physgun = false
ENT.Gravgun = false

-- Contact --

ENT.OnContactDelay = 0
ENT.OnContactDelete = 0

-- Damage --

ENT.Damage = 300

-- Homing --

ENT.UseHoming = true
ENT.HomingTurnRate = 350
ENT.HomingSpeed = 1700

-- Collision --

ENT.UseCustomCollision = true
ENT.CustomCollisionBounds = Vector( 10, 10, 10 )

if SERVER then


  AddCSLuaFile()


function ENT:CustomInitialize()

  ParticleEffectAttach( "Ultrakill_MinosSnakeYel", PATTACH_POINT_FOLLOW, self, 0 )
  ParticleEffectAttach( "Ultrakill_MinosSnakeYel_Ring", PATTACH_POINT, self, 0 )

  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_SnakeLoop", self:GetPos(), self )

  self:SetSkin( 1 )

  SafeRemoveEntityDelayed( self, 5 )

end


function ENT:OnTakeDamage( Dmg )

  self:CheckReflect( Dmg )
  self:CheckParry( Dmg )

end


function ENT:OnContact( Ent )

  if not self:GetParried() then

    UltrakillBase.SoundScript("Ultrakill_MinosPrime_SnakeShatter",self:GetPos())

    self:DealDamage( Ent, self.Damage, Vector( 350, 0, 300 ), DMG_BLAST )

    ParticleSystem3D( "ultrakill_virtueshatter", self:GetPos(), self:GetAngles(), 1 )
    self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Shockwave", { pos = self:GetPos() + Vector( 0, 0, 5 ), ang = self:GetAngles(), cpoints = { { pos = Vector( 100, 750, 1 ) } } } )
    self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Sparks", { pos = self:GetPos() + Vector( 0, 0, 5 ), ang = self:GetAngles() } )

    -- Gibs --

    self:CreateGibs( {

      Position = self:GetPos(),
      Models = UltrakillBase.Gibs.Virtue,
      Amount = 5,
      Velocity = 1000,
      ModelScale = 3.5,
      Trail = "Ultrakill_VirtueShatter_Trail",

    } )

  else

    self:ParryCollide()

  end

end


else


function ENT:CustomThink() 

  self:AngleFollowVelocity()

end


end
