if not DrGBase or not UltrakillBase then return end -- return if DrGBase or UltrakillBase isn't installed
ENT.Base = "ultrakillbase_nextbot" -- DO NOT TOUCH (obviously)

local OutroConVar = CreateConVar( "drg_ultrakill_minosoutro", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_LUA_SERVER }, "Enables Boss Outro" )
local IntroConVar = CreateConVar( "drg_ultrakill_minosintro", 1, { FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_LUA_SERVER }, "Enables Boss Intro" )

-- Misc --

ENT.PrintName = "Minos Prime"
ENT.Category = "ULTRAKILL - Bosses"
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT

ENT.Models = { "models/ultrakill/characters/bosses/mp/minos_prime.mdl" }
ENT.ModelScale = 1

ENT.CollisionBounds = Vector( 6, 6, 78 ) * 1.5
ENT.SurroundingBounds = Vector( 60, 60, 145 ) * 1.5

-- Stats --

ENT.SpawnHealth = 130000 -- Game HP is 130

-- Sounds --

ENT.RestartVoiceLine = "Ultrakill_MinosPrime_Useless"

-- AI --

ENT.Omniscient = true
ENT.AISight = false
ENT.SpotDuration = 120
ENT.MeleeAttackRange = math.huge
ENT.ReachEnemyRange = 55
ENT.AvoidEnemyRange = 0

-- Detection --

ENT.EyeBone = "Head"
ENT.EyeOffset = Vector( 0, 0, 3 )
ENT.EyeAngle = Angle( 0, 0, 0 )
ENT.SightRange = 15000
ENT.MinLuminosity = 0
ENT.MaxLuminosity = 1
ENT.HearingCoefficient = 1

-- Relationships --

ENT.Factions = { "FACTION_ULTRAKILL_MINOS" }
ENT.DefaultRelationship = D_HT
ENT.PlayerRelationship = D_HT
ENT.AllyDamageTolerance = 0

-- Locomotion --

ENT.Acceleration = 5500
ENT.Deceleration = 5500
ENT.JumpHeight = 1500
ENT.StepHeight = 25
ENT.MaxYawRate = 650
ENT.DeathDropHeight = math.huge

-- Animations --

ENT.WalkAnimation = "Walk"
ENT.WalkAnimRate = 1
ENT.RunAnimation = "Walk"
ENT.RunAnimRate = 1
ENT.IdleAnimation = "Idle"
ENT.IdleAnimRate = 1
ENT.JumpAnimation = "Jump"
ENT.JumpAnimRate = 1
ENT.FallingAnimation = "Falling"
ENT.FallingAnimRate = 1

-- Movements --

ENT.UseWalkframes = false
ENT.WalkSpeed = 115
ENT.RunSpeed = 115

-- Aiming --

ENT.PitchOrientation = 3
ENT.PitchBone = "Spine"
ENT.PitchFollow = false

-- Variables --

ENT.Phases = 2
ENT.Phase = 1
ENT.Gravity = true
ENT.WeightClass = "Heavy"

ENT.ProjectilePunchRange = 150
ENT.DropAttackRange = 75
ENT.DropAttackThreshold = -0.275
ENT.DropAttackCrushThreshold = -0.925
ENT.UppercutLeapRange = 250
ENT.DownSwingThreshold = -0.575
ENT.DownSwingComboRange = 75

-- Tables --

ENT.DamageTable = {
  [ "Boxing" ] = { 300, 140, DMG_CLUB, 30 },
  [ "Combo"  ] = { 300, 140, DMG_CLUB, 30 },
  [ "DownSwing" ] = { 300, 140, DMG_CLUB, 60, Vector( 0, 0, -3500 ) },
  [ "DropAttack_Recovery" ] = { 500, 220, DMG_BLAST, 360, Vector( 1200, 0, 1200 ) },
  [ "Dropkick" ] = { 500, 230, DMG_BLAST, 360, Vector( 1500, 0, 1200 ) },
  [ "Uppercut" ] = { 300, 140, DMG_CLUB, 35, Vector( -100, 0, 1550 ) },
}

ENT.AnimRateTable = {
  [ "Boxing" ] = 0.65,
  [ "Combo" ] = 0.65,
  [ "Outro" ] = 0.17,
  [ "Intro" ] = 0.21,
}

ENT.IntroTable = {
  "Intro",
  "Outro"
}

ENT.EventTable = {

  [ "Boxing" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 0" },
    { 0, "Flag Parry 0"  },
    { 0, "Flag Turning 1"  },

    { 30, "Flag Turning 0"  },
    { 30, "Teleport Ground"  },

    { 39, "SnakeSwing 18 0.25 1"  },
    { 39, "Damage Start"  },

    { 44, "Damage Stop" },

    { 57, "UppercutCancel"  },

    { 62, "Teleport Ground 35"  },

    { 73, "SnakeSwing 24 0.25 2"  },
    { 73, "Damage Start"  },

    { 80, "Damage Stop" },

    { 87, "UppercutCancel"  },

    { 90, "Teleport Ground -35"  },

    { 104, "SnakeSwing 18 0.3 3"  },
    { 104, "Damage Start"  },

    { 111, "Damage Stop" },

    { 120, "UppercutCancel"  },

    { 126, "Teleport Ground"  },

    { 132, "UppercutCancel"  },
    { 132, "Alert Parry"  },
    { 132, "Flag Parry 1" },

    { 139, "SnakeSwing 24 0.2 4"  },
    { 139, "Damage Start"  },

    { 145, "Damage Stop" },
    { 145, "Flag Parry 0" },

    { 174, "BigRubble"  },
    { 174, "Flag Turning 1"  },

  },

  [ "Combo" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 0" },
    { 0, "Flag Turning 1"  },
    { 0, "Flag Parry 0"  },

    { 22, "Flag Turning 0"  },
    { 22, "Teleport Ground"  },

    { 29, "SnakeSwing 9 0.2 5"  },
    { 29, "Damage Start"  },

    { 32, "Damage Stop" },

    { 42, "UppercutCancel"  },

    { 56, "Teleport Ground"  },

    { 63, "SnakeSwing 9 0.2 6"  },
    { 63, "Damage Start"  },

    { 67, "Damage Stop" },

    { 70, "ProjectileCharge Create"  },

    { 75, "Flag Turning 1"  },

    { 88, "Teleport Ground"  },

    { 96, "ProjectileCharge Destroy"  },
    { 96, "SnakeProjectile"  },

  },

  [ "DownSwing" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 1" },
    { 0, "Flag Parry 0"  },
    { 0, "Flag Turning 1"  },

    { 5, "Alert UnParry"  },

    { 29, "SnakeSwing 24 0.2 7"  },
    { 29, "Damage Start"  },

    { 35, "Damage Stop" },

    { 37, "PitchFollow 0" },

  },

  [ "DropAttack" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 0" },
    { 0, "Flag Turning 1"  },
    { 0, "Flag Parry 0"  },
    { 0, "Alert UnParry"  },

  },

  [ "DropAttack_Recovery" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 0" },
    { 0, "Flag Turning 0"  },
    { 0, "Flag Parry 0"  },

  },

  [ "ProjectilePunch" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 0" },
    { 0, "Flag Turning 1"  },
    { 0, "Flag Parry 0"  },
    { 0, "ProjectileCharge Create"  },

    { 30, "ProjectileCharge Destroy"  },
    { 30, "SnakeProjectile"  },

  },

  [ "Riderkick" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 1" },
    { 0, "Flag Turning 1"  },
    { 0, "Alert UnParry"  },
    { 0, "Flag Parry 0"  },

  },

  [ "Uppercut" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 0" },
    { 0, "Flag Turning 1"  },
    { 0, "Flag Gravity 1"  },
    { 0, "Flag Parry 0"  },

    { 15, "Alert UnParry"  },
    { 15, "Teleport Ground"  },

    { 25, "Flag Turning 0"  },

    { 31, "SnakeSwing 24 0.4 8"  },
    { 31, "Damage Start"  },

    { 34, "UppercutJump"  },

    { 51, "Damage Stop" },

  },

  [ "Dropkick" ] = {

    { 0, "Damage Stop" },
    { 0, "PitchFollow 0" },
    { 0, "Flag Turning 1"  },
    { 0, "Flag Gravity 1"  },
    { 0, "Flag Parry 0"  },

    { 65, "PitchFollow 1" },
    { 65, "Teleport Air"  },
    { 65, "Flag Gravity 0"  },

    { 74, "Flag Parry 1" },
    { 74, "Alert Parry"  },

    { 80, "Flag Turning 0"  },

    { 83, "Explosion"  },
    { 83, "Flag Parry 0" },

    { 92, "Flag Gravity 1"  },

    { 100, "PitchFollow 0" },

    { 125, "Flag Turning 1"  },

  },

  [ "Outro" ] = {

    { 0, "Damage Stop" },
    { 0, "Flag Turning 0"  },

    { 129, "Vibrate" },

    { 165, "OutroScream" },
    { 165, "OutroRay" },

    { 235, "End" },

  },

  [ "Intro" ] = {

    { 0, "Damage Stop" },

    { 1, "PitchFollow 0" }

  },

  [ "Walk" ] = {

    { 0, "Damage Stop" },

    { 1, "PitchFollow 0" }

  },

  [ "Jump" ] = {

    { 0, "Damage Stop" },

    { 1, "PitchFollow 0" }

  },

  [ "Falling" ] = {

    { 0, "Damage Stop" },

    { 1, "PitchFollow 0" }

  },

  [ "Idle" ] = {

    { 0, "Damage Stop" },

    { 1, "PitchFollow 0" }

  },

}

ENT.AttackTable = {

  "Boxing",
  "Combo",
  "DownSwing",
  "DropAttack",
  "Dropkick",
  "ProjectilePunch",
  "Riderkick",
  "Uppercut"

}

ENT.InterruptionTable = {

  ["HARMLESS"] = {

    ["Boxing"] = true,
    ["Dropkick"] = true,

  },

  ["LENIENT"] = {

    ["Boxing"] = true,
    ["Dropkick"] = true,

  },

  ["STANDARD"] = {

    ["Boxing"] = true,
    ["Dropkick"] = true,

  },

}

local Outro_RayTable = {
  0,
  1.5,
  3,
  4,
  5,
  5.5,
  6,
  6.25,
  6.5,
  6.75,
  6.775,
  6.8,
  6.825,
  6.85,
  6.875,
  6.9,
  6.925,
  6.95,
  6.975,
}

-- Possession --

ENT.PossessionCrosshair = true

ENT.PossessionEnabled = true

ENT.PossessionViews = {

  {

    offset = Vector( 0, 15, 45 ),
    distance = 150,
    eyepos = false

  },

  {

    offset = Vector( 7.5, 0, 0 ),
    distance = 0,
    eyepos = true
    
  }

}

ENT.PossessionBinds = {

  [ IN_ATTACK ] = { { coroutine = true, onkeydown = function( self, Possessor )

    local LockedOn = self:PossessionGetLockedOn()

    if self:IsOnGround() then

      if Possessor:KeyDown( IN_FORWARD ) then

      self:MinosPrepareThy( LockedOn )

      elseif Possessor:KeyDown( IN_BACK ) then

      self:MinosUppercut( LockedOn )

      elseif not Possessor:KeyDown( IN_FORWARD ) and not Possessor:KeyDown( IN_BACK ) then

        self:MinosThyEnd( LockedOn )

      end

    else

      self:MinosDownSwing( LockedOn )

    end

  end } },

  [ IN_ATTACK2 ] = { { coroutine = true, onkeydown = function( self, Possessor )

    local LockedOn = self:PossessionGetLockedOn()

    if self:IsOnGround() then

      self:MinosJudgement( LockedOn )

    elseif not self:IsOnGround() then

      self:MinosDropAttack( LockedOn )

    end

  end } },

  [ IN_RELOAD ] = { { coroutine = true, onkeydown = function( self, Possessor )

    self:MinosProjectilePunch( self:PossessionGetLockedOn() )

  end } },

  [ IN_JUMP ] = { { coroutine = true, onkeydown = function( self )

    self:MinosJumpAttack()

  end } },

}

if SERVER then

function ENT:CustomInitialize()

  self:SetStaminaMax( UltrakillBase.DifficultyGetInformation( "MinosPrime" ).Stamina )
  self:RefillStamina( )

end

function ENT:OnAnimEvent( Options )

  local Event = string.Explode( " ", Options )

  if Event[1] == "SnakeSwing" then

    if self.ParryInterrupted then return end

    UltrakillBase.SoundScript("Ultrakill_MinosPrime_SnakeSwing", self:GetPos() )

    local Data = EffectData()
    Data:SetEntity(self)
    Data:SetRadius( ( tonumber( Event[3] ) / self:CalculateAnimRate() ) * 100 ) -- Workaround for bad float precision.
    Data:SetAttachment( tonumber( Event[2] ) )
    Data:SetFlags( tonumber( Event[4] or 0 ) )

    util.Effect( "Ultrakill_MinosSnakeSwing", Data, true, true )

  elseif Event[1] == "BigRubble" then

    local Ang, Pos = self:GetGroundAngles( self:GetPos() + self:GetForward() * 65 )

    UltrakillBase.SoundScript( "Ultrakill_BigRockBreak", self:GetPos() )
    self:ParticleEffectTimed( 1, "Ultrakill_RubbleSmoke_Big", { pos = Pos, ang = Ang } )
    ParticleSystem3D( "ultrakill_bigrubble", Pos, Ang, 2 )

    self:CreateGibs( {

      Position = Pos,
      Models = UltrakillBase.Gibs.Rubble,
      Amount = 6,
      Velocity = 600,
      ModelScale = 1.2,
      Trail = "Ultrakill_White_Trail",

    } )

    self:ScreenShake( 2500, 10, 1, 6500 )

  elseif Event[1] == "Explosion" then

    if self.ParryInterrupted then return end

    UltrakillBase.SoundScript( "Ultrakill_Minos_Prime_Explosion", self:GetPos() )

    self:ParticleEffectTimed( 1.5, "Ultrakill_ExplosionSmoke", { pos = self:WorldSpaceCenter(), ang = self:GetAimAngles() } )
    self:ParticleEffectTimed( 5, "Ultrakill_ExplosionSmokeLinger", { pos = self:WorldSpaceCenter(), ang = self:GetAimAngles() } )
    self:ParticleEffectTimed( 1, "Ultrakill_MinosSparks", { pos = self:WorldSpaceCenter(), ang = self:GetAimAngles() } )

    self:Explosion( self:WorldSpaceCenter(), 500, Vector( 1500, 0, 650 ), 350, 0.125 )

    ParticleSystem3D( "ultrakill_mp_explosion", self:WorldSpaceCenter(), self:GetAimAngles(), 1 )

    self:ScreenShake( 2500, 10, 1, 6500 )

  elseif Event[1] == "OutroScream" then

    UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Scream", self:GetPos(), self )

  elseif Event[1] == "Vibrate" then

    self:Vibrate( 1, 6 )

  elseif Event[1] == "OutroRay" then

    for X = 1, #Outro_RayTable do

      local Time = Outro_RayTable[X]

      self:Timer( Time, function( self )

        if not IsValid( self ) then return end

        local Ray = self:CreateProjectile( "Ultrakill_MinosLights", true )
        local Bpos , Bang = self:GetBonePosition( self:DrG_SearchBone( "Spine02" ) )
        local RanAng = Angle( 0, 0, 0 )
        RanAng:Random( -145, 145 )
        Ray:SetOwner( self )
        Ray:SetPos( Bpos )
        Ray:SetAngles( Bang + RanAng )
        Ray:SetParent( self, 2 )

        UltrakillBase.SoundScript( "Ultrakill_Prime_OutroRay", self:GetPos(), self )
        UltrakillBase.SoundScript( "Ultrakill_Prime_OutroAmbiance", self:GetPos(), self )

        self:ScreenShake( 150, 0.3, 0.3, 2000 )

      end )


    end

  elseif Event[1] == "Alert" then

    if Event[2] == "Parry" then

      if self:GetPhase() ~= 2 or UltrakillBase.DifficultyGetInformation( "MinosPrime" ).ParryablePhase2 then

        local Angles = self:GetAimAngles()
        Angles:RotateAroundAxis( Angles:Right(), 90 )

        self:ParticleEffectTimed( 2, "Ultrakill_AlertParryable", { pos = self:GetAttachment( 1 ).Pos + self:GetAimVector() * 30, ang = Angles, cpoints = { { pos = Vector( 1.1, 0, 0 ) } } } )

        UltrakillBase.SoundScript( "Ultrakill_AlertParryable", self:GetPos(), self )

      end

    else

      local Angles = self:GetAimAngles()
      Angles:RotateAroundAxis( Angles:Right(), 90 )

      self:ParticleEffectTimed( 2, "Ultrakill_AlertUnParryable", { pos = self:GetAttachment( 1 ).Pos + self:GetAimVector() * 30, ang = Angles, cpoints = { { pos = Vector( 1.1, 0, 0 ) } } } )

      UltrakillBase.SoundScript( "Ultrakill_AlertUnParryable", self:GetPos(), self )

    end

  elseif Event[1] == "ProjectileCharge" then

    if Event[2] == "Create" then

      UltrakillBase.SoundScript( "Ultrakill_MinosPrime_SnakeCharge", self:GetPos(), self )

      self:ParticleEffectSlot( "ProjectileCharge", "Ultrakill_MinosProjectileCharge", { pos = self:GetPos(), parent = self, attachment = "RHand_Attach" } )

    elseif Event[2] == "Destroy" then

      self:ClearParticleEffectSlot( "ProjectileCharge" )

    end

  elseif Event[1] == "Damage" then

    local Seq = self:GetSequenceName( self:GetSequence() )

    if Event[2] == "Start" and not self.ParryInterrupted then

      self:ContinuousAttack({
        Damage = self.DamageTable[ Seq ][1],
        Range = self.DamageTable[ Seq ][2],
        Type = self.DamageTable[ Seq ][3],
        Angle = self.DamageTable[ Seq ][4],
        Force = self.DamageTable[ Seq ][5],
        Push = true,
      })

      self:SetContinuousAttack( true )

    else

      table.Empty( self.ContinuousAttacksTable )

      self:SetContinuousAttack( false )

    end

  elseif Event[1] == "Teleport" then

    local Rotation = Angle( 0, Event[3], 0 ) or angle_zero
    local StartPos, StartAngle = self:GetPos(), self:GetAngles()

    UltrakillBase.Teleport( self, self:GetEnemy(), Rotation, Event[2] == "Ground", function( self, RayCast, EndPos )

      UltrakillBase.SoundScript( "Ultrakill_Dodge2F", EndPos )
      UltrakillBase.SoundScript( "Ultrakill_RockBreak", EndPos )
  
      local Dist = math.Clamp( StartPos:Distance( EndPos ) / 45 , 1 , 30 )
  
      local RandomAngle = Angle( 0, 0, 90 )
      local BCenter = self:OBBCenter()
      local EndVecOffset = Vector( 0, 0, self:Height() * 1.2 )
      local Angles = self:GetAngles()
  
      for X = 1, Dist do
  
        local LerpPos = LerpVector( X / Dist, StartPos, EndPos )
  
        local Trace = self:TraceLine( nil, {
          start = LerpPos + BCenter,
          endpos = LerpPos - EndVecOffset,
          collisiongroup = COLLISION_GROUP_WORLD,
        } )
  
        if not Trace.Hit then continue end
  
        local FinalPos = Trace.HitPos
        local FinalAng = Trace.HitNormal
  
        RandomAngle.y = math.random( -360, 360 )
  
        FinalAng:Rotate( Angles + RandomAngle )
  
        FinalAng = FinalAng:Angle()
  
        self:ParticleEffectTimed( 1, "Ultrakill_RubbleSmoke", { pos = FinalPos, ang = FinalAng } )
        ParticleSystem3D( "ultrakill_rubble", FinalPos, FinalAng, 2 )
  
      end
  
      local DistGibs = math.Clamp( StartPos:Distance( EndPos ) / 90 , 1 , 15 )
  
      local PhysObjTable = {}
  
      for I = 1, DistGibs do
  
        local LerpPos = LerpVector( I / DistGibs, StartPos, EndPos )
  
        local Trace = self:TraceLine( nil, {
          start = LerpPos + BCenter,
          endpos = LerpPos - EndVecOffset,
          collisiongroup = COLLISION_GROUP_WORLD,
        } )
  
        if not Trace.Hit then continue end

        PhysObjTable[ #PhysObjTable + 1 ] = {
          Position = Trace.HitPos,
          Models = UltrakillBase.Gibs.Rubble,
          Amount = 2,
          Velocity = 600,
          ModelScale = 1.2,
          Trail = "Ultrakill_White_Trail",
        }

      end
  
      self:CreateGibs( PhysObjTable )
  
      self:ScreenShake( 650, 7, 0.5, 2550 )
    
    end )

    self:FaceEnemyInstant()
    self:PossessionFaceForwardInstant()

  elseif Event[1] == "UppercutCancel" then

    local Enemy = self:GetEnemy()

    if self:HasEnemy() and not Enemy:IsOnGround() then

      self:CallOverCoroutine( function( self )

        self:MinosUppercut( Enemy )

      end )

    end

  elseif Event[1] == "UppercutJump" then

    self:Jump( 800 )

  elseif Event[1] == "SnakeProjectile" then

    local Snake = self:CreateProjectile( "Ultrakill_Minos_SnakeProjectile", true )

    Snake:SetOwner( self )

    Snake:SetPos( self:WorldSpaceCenter() )

    Snake:SetAngles( self:GetAimAngles() )

    UltrakillBase.SoundScript( "Ultrakill_MinosPrime_SnakeSpawn", Snake:GetPos() )

    self:AimProjectile( Snake, 2000 )

  elseif Event[1] == "PitchFollow" then

    self:SetPitchFollow( tobool( tonumber( Event[2] ) ) )

  elseif Event[1] == "Stamina" then

    self:Stamina( tonumber( Event[2] ) )

  elseif Event[1] == "Flag" then

    if Event[2] == "Parry" then

      if self:GetPhase() >= 2 and not UltrakillBase.DifficultyGetInformation( "MinosPrime" ).ParryablePhase2 and tobool( tonumber( Event[3] ) ) then return end

      self:SetParryable( tobool( tonumber( Event[3] ) ) )

    elseif Event[2] == "Turning" then

      self:SetTurning( tobool( tonumber( Event[3] ) ) )

    elseif Event[2] == "Gravity" then

      self.Gravity = tobool( tonumber( Event[3] ) )

    end

  end

end

function ENT:MinosPrepareThy( Enemy )

  if self:GetCooldown( "Combo" ) > 0 or self:GetStamina() < 3 then return end

  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Prepare", self:GetPos(), self )

  self:Stamina( "Combo", 3 ) -- Prepare thyself costs 3 Stamina.

  self:PlaySequenceAndMove( "Combo", { gravity = true, collisions = true, multiply = Vector( 1.3, 1.3, 1.3 ) }, function( self, Cycle )

    if Cycle > 0.962075814 then

      return true

    end

  end )

end


function ENT:MinosThyEnd( Enemy )

  if self:GetCooldown( "Boxing" ) > 0 or self:GetStamina() < 2 then return end

  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_ThyEnd", self:GetPos(), self )

  self:Stamina( "Boxing", 2 )

  self:PlaySequenceAndMove( "Boxing", { gravity = true, collisions = true }, function( self, Cycle )

    if Cycle > 0.954091809 then

      return true

    end

  end)

end

function ENT:MinosUppercut( Enemy )

  if self:GetCooldown( "Uppercut" ) > 0 or self:GetStamina() < 1 then return end

  self:Stamina( "Uppercut", 1 )

  self:PlaySequenceAndMove( "Uppercut", { gravity = true, collisions = true }, function( self, Cycle )

    local UppercutTrace = self:TraceHull( nil, {

      start = self:WorldSpaceCenter(),
      endpos = self:WorldSpaceCenter() + Vector(0, 0, self:Height() * 0.5 ),
      collisiongroup = COLLISION_GROUP_WORLD,

    } )

    if Cycle > 0.576271186 and UppercutTrace.Hit then

      self:SetCooldown( "Attack", 0.25 )

      return true

    end

  end )

  local UppercutTrace = self:TraceHull( nil, {

    start = self:WorldSpaceCenter(),
    endpos = self:WorldSpaceCenter() + Vector(0, 0, self:Height() * 0.5 ),
    collisiongroup = COLLISION_GROUP_WORLD,

  } )

  if self:IsInRange( Enemy, self.UppercutLeapRange ) and not UppercutTrace.Hit and not self:IsStaminaDepleted() then

    UltrakillBase.SoundScript( "Ultrakill_Dodge2F", self:GetPos() )

    self:AirLeap( self:GetPos() + Vector( 0, 0, 1150 ), 1100 * 1, function( self )

      self:FaceEnemy()
      self:PossessionFaceForward()

      if IsValid( Enemy ) and not self:IsInRange( Enemy, self.UppercutLeapRange ) then

        return true

      end

    end )

    if self:IsInRange( Enemy, self.DownSwingComboRange * 1.25 ) then

      self:MinosDownSwing( Enemy, true )

    end

  end

end


function ENT:MinosJudgement( Enemy )

  if self:GetCooldown( "Dropkick" ) > 0 or self:GetStamina() < 2 then return end

  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Judgement", self:GetPos(), self )

  self:Stamina( "Dropkick", 2 )

  local Options = { gravity = true, collisions = true }

  self:PlaySequenceAndMove( "Dropkick", Options, function( self, Cycle )

    if Options.gravity ~= self.Gravity then
      
      Options.gravity = self.Gravity

    end

    if Cycle > 0.547169811 and not self:TraceHull( Vector( 0, 0, -50 - self:GetStepHeight() ), { collisiongroup = COLLISION_GROUP_WORLD }  ).HitWorld and not self:IsStaminaDepleted() then
      
      return true

    end

    if self:GetPhase() >= 2 and Cycle > 0.868263509 then
      
      return true

    end

  end)

end


function ENT:MinosDownSwing( Enemy, NoTeleport )

  if self:GetCooldown( "DownSwing" ) > 0 or not self:IsLookingDown( self.DownSwingThreshold, self:GetAimEnemy() ) or self:GetStamina() < 1 then return end

  self:Stamina( "DownSwing", 1 )

  if NoTeleport ~= true then

    UltrakillBase.Teleport( self, self:GetEnemy(), angle_zero, false )

    UltrakillBase.SoundScript( "Ultrakill_Dodge2F", self:GetPos() )
    UltrakillBase.SoundScript( "Ultrakill_RockBreak", self:GetPos() )

    self:ScreenShake( 650, 7, 0.5, 2550 )

    self:FaceEnemyInstant()
    self:PossessionFaceForwardInstant()

  end

  self:PlaySequenceAndMove( "DownSwing", { gravity = false, collisions = false }, function( self, Cycle )

    if Cycle > 0.886227551 then

      return true

    end

  end)

  -- Combo -- 

  local GroundTrace = self:TraceHull( nil, { 
    start = self:WorldSpaceCenter(), 
    endpos = self:WorldSpaceCenter() - Vector(0, 0, self:Height() ), 
    collisiongroup = COLLISION_GROUP_WORLD 
  } )

  if self:IsInRange( Enemy, self.DownSwingComboRange ) and not GroundTrace.Hit and self:GetStamina() >= 1 then

    UltrakillBase.Teleport( self, self:GetEnemy(), angle_zero, false )

    UltrakillBase.SoundScript( "Ultrakill_Dodge2F", self:GetPos() )
    UltrakillBase.SoundScript( "Ultrakill_RockBreak", self:GetPos() )

    self:ScreenShake( 650, 7, 0.5, 2550 )

    self:Stamina( "DownSwing", 1 )

    self:FaceEnemyInstant()
    self:PossessionFaceForwardInstant()

    self:PlaySequenceAndMove( "DownSwing", { gravity = false, collisions = false }, function( self, Cycle )

      if Cycle > 0.886227551 then

        return true

      end

    end )

    self:SetCooldown( "Attack", 0.25 )

  end

end

function ENT:MinosProjectilePunch( Enemy )

  if self:GetPhase() < 2 and not self:IsOnGround() or self:IsInRange_XY( Enemy, self.ProjectilePunchRange ) or self:GetCooldown( "ProjectilePunch" ) > 0 then return end

  self:PlaySequenceAndMove( "ProjectilePunch", { gravity = false, collisions = true }, function( self, Cycle )

    if Cycle > 0.746900354 then
      
      return true

    end

  end )

  self:OnStaminaLost( "ProjectilePunch", 1 )

end

function ENT:MinosDie( Enemy )

  if self:GetCooldown( "Riderkick" ) > 0 or self:GetStamina() < 1 then return end

  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Die", self:GetPos(), self )

  self:Stamina( "Riderkick", 1 )

  self.CancelRecovery = false

  local PreviousPos = self:GetPos()

  self:PlaySequenceAndLoop( 0.766666667 / self:CalculateAnimRate( "Riderkick" ), "Riderkick", 1, function( self, Cycle, Time )
  
    self:SetPos( PreviousPos )
    self:SetVelocity( vector_origin )

    if Time >= 0.566666667 and self:GetTurning() then

      self:SetTurning( false )

    end

  end )

  local AimTrace = self:TraceHull( nil, {

    start = self:WorldSpaceCenter(),
    endpos = self:WorldSpaceCenter() + self:GetAimVector() * 100000,
    mask = MASK_NPCSOLID_BRUSHONLY,

  } )

  UltrakillBase.BypassRayCastTeleport( self, AimTrace.HitPos, function( self, RayCast, RayPos )

    local HitNormal = AimTrace.HitNormal
    local StartPos = AimTrace.StartPos
    local Pos = AimTrace.HitPos

    local ZAxis = HitNormal:Dot( Vector( 0, 0, 1 ) )

    if ZAxis > -0.5 and ZAxis < 0.5 then self.CancelRecovery = true end

    HitNormal = HitNormal:Angle()

    HitNormal:RotateAroundAxis( HitNormal:Right(), 90 )
    HitNormal:RotateAroundAxis( HitNormal:Forward(), 180 )
    HitNormal:RotateAroundAxis( HitNormal:Up(), 180 + self:GetAngles().y )

    local Effect = EffectData()

    Effect:SetEntity( self )
    Effect:SetOrigin( Pos )
    Effect:SetStart( StartPos + self:OBBCenter() )

    util.Effect( "Ultrakill_MinosDropAttackTrail", Effect, true, true )

    self:ParticleEffectTimed( 1, "Ultrakill_RubbleSmoke_Big", { pos = Pos, ang = HitNormal } )
    ParticleSystem3D( "ultrakill_bigrubble", Pos, HitNormal, 2 )

    self:Shockwave( 0, Pos, HitNormal, 250, 2, 100, 0.1 )

    self:CreateGibs( {

      Position = Pos,
      Models = UltrakillBase.Gibs.Rubble,
      Amount = 6,
      Velocity = 600,
      ModelScale = 1.2,
      Trail = "Ultrakill_White_Trail",

    } )
  
    UltrakillBase.SoundScript( "Ultrakill_BigRockBreak", Pos )
    UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Launch", StartPos )
  
    self:Attack( {

      Damage = self.DamageTable["DropAttack_Recovery"][1] * 0.6,
      Range = self.DamageTable["DropAttack_Recovery"][2] * 0.6,
      Type = self.DamageTable["DropAttack_Recovery"][3],
      Angle = self.DamageTable["DropAttack_Recovery"][4],
      Force = self.DamageTable["DropAttack_Recovery"][5],
      Push = true

    } )
  
    self:TraceAttack( AimTrace, {

      Damage = self.DamageTable["DropAttack_Recovery"][1] * 0.6,
      Type = self.DamageTable["DropAttack_Recovery"][3],
      Force = self.DamageTable["DropAttack_Recovery"][5],
      Angle = 10,
      Push = true

    } )

  end )

  self:PlaySequenceAndMove( "DropAttack_Recovery", { collisions = false }, function( self, Cycle )

    if Cycle > 0.674650729 or self.CancelRecovery then

      return true

    end

  end )

end

function ENT:MinosCrush( Enemy )

  if self:GetCooldown( "DropAttack" ) > 0 or self:GetStamina() < 1 then return end

  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Crush", self:GetPos(), self )

  self:Stamina( "DropAttack", 1 )

  local PreviousPos = self:GetPos()

  self:PlaySequenceAndLoop( 0.766666667 / self:CalculateAnimRate( "DropAttack" ), "DropAttack", 1, function( self, Cycle, Time )
  
    self:SetPos( PreviousPos )
    self:SetVelocity( vector_origin )

  end )

  local DownTrace = self:TraceHull( nil, {

    start = self:WorldSpaceCenter(),
    endpos = self:WorldSpaceCenter() - self:GetUp() * 100000,
    mask = MASK_NPCSOLID_BRUSHONLY,

  } )

  UltrakillBase.BypassRayCastTeleport( self, DownTrace.HitPos, function( self, RayCast, RayPos )
  
    local StartPos = DownTrace.StartPos
    local Ang, Pos = self:GetGroundAngles( RayPos )

    local Effect = EffectData()

    Effect:SetEntity( self )
    Effect:SetOrigin( Pos )
    Effect:SetStart( StartPos + self:OBBCenter() )

    util.Effect( "Ultrakill_MinosDropAttackTrail", Effect, true, true )

    self:ParticleEffectTimed( 1, "Ultrakill_RubbleSmoke_Big", { pos = Pos, ang = Ang } )
    ParticleSystem3D( "ultrakill_bigrubble", Pos, Ang, 2 )

    self:Shockwave( 0, Pos, Ang, 250, 2, 100, 0.1 )

    self:CreateGibs( {

      Position = Pos,
      Models = UltrakillBase.Gibs.Rubble,
      Amount = 6,
      Velocity = 600,
      ModelScale = 1.2,
      Trail = "Ultrakill_White_Trail",

    } )

    UltrakillBase.SoundScript( "Ultrakill_BigRockBreak", Pos )
    UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Launch", StartPos )

    self:ParticleEffectTimed( 1.5, "Ultrakill_ExplosionSmoke", { pos = Pos, ang = self:GetAngles() } )
    self:ParticleEffectTimed( 5, "Ultrakill_ExplosionSmokeLinger", { pos = Pos, ang = self:GetAngles() } )
    self:ParticleEffectTimed( 1, "Ultrakill_MinosSparks", { pos = Pos, ang = self:GetAngles() } )
    ParticleSystem3D( "ultrakill_mp_explosion", Pos, Ang, 1 )

    UltrakillBase.SoundScript( "Ultrakill_Minos_Prime_Explosion", Pos )

    self:Explosion( Pos, 500, Vector( 1500, 0, 300 ), 350, 0.125 )

    self:ScreenShake( 2500, 10, 1.5, 6500 )

    self:TraceAttack( DownTrace, {

      Damage = self.DamageTable["DropAttack_Recovery"][1],
      Type = self.DamageTable["DropAttack_Recovery"][3],
      Force = self.DamageTable["DropAttack_Recovery"][5],
      Angle = 10,
      Push = true

    } )
  
  end )

  self:PlaySequenceAndMove( "DropAttack_Recovery", { collisions = false }, function( self, Cycle )

    if Cycle > 0.674650729 then
      
      return true

    end

  end )

end


function ENT:MinosDropAttack( Enemy )

  if self:IsLookingUp( self.DropAttackThreshold, self:GetAimEnemy() ) then return end

  if self:IsInRange( Enemy, self.DropAttackRange ) or not self:IsLookingUp( self.DropAttackCrushThreshold, self:GetAimEnemy() ) then

    self:MinosCrush( Enemy )

  else

    self:MinosDie( Enemy )

  end

end

function ENT:MinosJumpAttack( Enemy )

  if not self:IsOnGround() or self:GetCooldown( "Jump" ) > 0 then return end

  UltrakillBase.SoundScript( "Ultrakill_Dodge2F", self:GetPos() )

  self:Jump( 1000, function( self, Time )

    local JumpTrace = self:TraceHull( nil, {

      start = self:WorldSpaceCenter(),
      endpos = self:WorldSpaceCenter() + Vector( 0, 0, self:Height() / 2 ),
      collisiongroup = COLLISION_GROUP_WORLD

    } )

    if Time > 0.75 or JumpTrace.Hit then

      return true

    end


  end )

  self:SetCooldown( "Jump", 1.5 )

end

function ENT:OnMeleeAttack( Enemy )

if not self:IsStaminaDepleted() and self:GetCooldown( "Attack" ) <= 0 then

  if self:IsOnGround() then

    local Random = math.random( 6 )

    if Random == 1 then

      self:MinosPrepareThy( Enemy )

    elseif Random == 2 then

      self:MinosThyEnd( Enemy )

    elseif Random == 3 then

      self:MinosUppercut( Enemy )

    elseif Random == 4 then

      self:MinosJudgement( Enemy )

    elseif Random == 5 then

      self:MinosProjectilePunch( Enemy )

    elseif Random == 6 then

      self:MinosJumpAttack( Enemy )

    end

  else

    local Random = math.random( 3 )

    if Random == 1 then

      self:MinosDropAttack( Enemy )

    elseif Random == 2 then

      self:MinosProjectilePunch( Enemy )

    elseif Random == 3 then

      self:MinosDownSwing( Enemy )

    end

  end

end

end

function ENT:OnRemove()

  UltrakillBase.StopMusic( self, "ORDER_Intro" )
  UltrakillBase.StopMusic( self, "ORDER" )

end

function ENT:OnStaminaDepleted()

  self:Timer( UltrakillBase.DifficultyGetInformation( "MinosPrime" ).StaminaRecovery, function( self )

    if self:GetStamina() > 0 then return end

    self:RefillStamina( )

  end )

end

function ENT:OnStaminaLost( ID, Lost )

  if UltrakillBase.DifficultyCompare( "HIDDEN MANSION" ) then return end

  self:SetCooldown( ID, Lost * 1.333 )

end

function ENT:OnPhaseChange( Phase )

  if Phase ~= 2 then return end

  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Weak", self:GetPos(), self )
  UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Phase", self:GetPos(), self )

  ParticleEffectAttach( "Ultrakill_MinosPhase", PATTACH_ABSORIGIN_FOLLOW, self, 0 )
  ParticleEffectAttach( "Ultrakill_MinosPhase_Rings", PATTACH_POINT_FOLLOW, self, 2 )
  ParticleEffectAttach( "Ultrakill_MinosPhaseChange", PATTACH_POINT, self, 2 )

  self:ScreenShake( 150, 10, 0.6, 1550 )

  -- Change Minos Stats! --

  self:SetStaminaMax( UltrakillBase.DifficultyGetInformation( "MinosPrime" ).Stamina * UltrakillBase.DifficultyGetInformation( "MinosPrime" ).Phase2Mult )
  self:RefillStamina( )

end

function ENT:OnParry( Ply, Dmg )

  if not Dmg:IsDamageType( DMG_DIRECT ) then
    
    Dmg:SetDamage( Dmg:GetDamage() + 5000 )
    Dmg:SetDamageType( bit.bor( Dmg:GetDamageType(), DMG_DIRECT ) )

  end

  UltrakillBase.SoundScript( "Ultrakill_Parry", self:GetPos() )

  UltrakillBase.HitStop( 0.25 )

  self:SetParryable( false )

  self:AddStamina( 5 )

  self:OnTookDamage( Dmg )

  -- Interruption --

  if istable( self.InterruptionTable[ UltrakillBase.ConVars.Difficulty:GetString() ] ) and self.InterruptionTable[ UltrakillBase.ConVars.Difficulty:GetString() ][ self:GetSequenceName( self:GetSequence() ) ] then

    self.ParryInterrupted = true

    self:CallInCoroutine( function( self ) 

      self.ParryInterrupted = false

    end )

  end

  UltrakillBase.OnParryPlayer( Ply )

end

function ENT:OnSpawn()

  if IntroConVar:GetBool() or self.ForceIntro then

    self:SetNoTarget( true )
    self:SetGodMode( true )
    self:SetNoDraw( true )
    self:SetSandable( false )
    self:SetTurning( false )

    local Orb = self:CreateProjectile( "Ultrakill_PrimeOrb", true )

    Orb:SetPos( self:GetPos() )
    Orb:SetAngles( self:GetAngles() )

    self:PauseCoroutine( 8.48333333 ) 

    UltrakillBase.SlowMotion( 1.2 )

    UltrakillBase.SoundScript( "Ultrakill_VirtueShatter", self:GetPos() )
    
    self:SetNoDraw( false )

    self:AddDynamLight( "MinosPrime", "Spine03", Color( 0, 75, 255 ), 350, 10, 0, 2 )

    self:Timer( 1, function()

      UltrakillBase.PlayMusic( self, "ORDER_Intro" )

    end )

    self:Timer( 2, function()

      UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Intro", self:GetPos(), self, 0 )

    end )

    self:PlaySequenceAndMove( "Intro", {} )

  end

  self:SetNoDraw( false )
  self:SetNoTarget( false )

  self:AddDynamLight( "MinosPrime", "Spine03", Color( 0, 75, 255 ), 350, 10, 0, 2 )

  self:SetGodMode( false )
  self:SetSandable( true )

  UltrakillBase.SoundScript( "Ultrakill_Spotlight", self:GetPos() )
  UltrakillBase.ChangeMusic( self, "ORDER_Intro", "ORDER" )
  UltrakillBase.AddBoss( self, "#ultrakill.minosprime.boss", 1 )

  -- Brief Walk --

  self:SetCooldown( "Attack", 2 )

end

function ENT:OnTookDamage(  )

  if self:GetCooldown( "Minos_Hurt" ) <= 0 then

    UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Hurt", self:GetPos(), self )

    self:SetCooldown( "Minos_Hurt", self.DamageSoundDelay )

  end

end

function ENT:OnTakeDamage( Dmg, Hitgroup )

  self:DamageMultiplier( Dmg, Hitgroup )

  self:CheckParry( Dmg )

  self:CreateBlood( Dmg, Hitgroup )

  self:SpotEntity( Dmg:GetAttacker() )

end

function ENT:OnDeath( Dmg, HitGroup )

  UltrakillBase.SoundScript( "Ultrakill_Death", self:GetPos() )

  if OutroConVar:GetBool() then

    self:ClearAllParticleEffectSlots()

    self:SetParryable( false )

    UltrakillBase.StopMusic( self, "ORDER_Intro" )
    UltrakillBase.StopMusic( self, "ORDER" )

    UltrakillBase.SlowMotion( 2 )

    UltrakillBase.SoundScript( "Ultrakill_MinosPrime_Outro", self:GetPos(), self )

    self:Timer( 4, function( self )

      UltrakillBase.RemoveBoss( self ) 

    end )

    self:PlaySequenceAndMove( "Outro", { gravity = false, collisions = false } )

  end

  ParticleSystem3D( "ultrakill_virtueshatter_huge", self:WorldSpaceCenter(), self:GetAngles(), 1 )
  self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Shockwave", { pos = self:WorldSpaceCenter() + Vector( 0, 0, 5 ), ang = self:GetAngles(), cpoints = { { pos = Vector( 75, 1000, 1 ) } } } )
  self:ParticleEffectTimed( 1, "Ultrakill_VirtueShatter_Sparks", { pos = self:WorldSpaceCenter() + Vector( 0, 0, 5 ), ang = self:GetAngles() })

  -- Screen Fade --

  for I, Ent in ipairs( ents.FindInSphere( self:GetPos(), 50000 ) ) do

    if Ent:IsPlayer() then

      Ent:ScreenFade( SCREENFADE.IN, nil, 1.5, 0 )

    end

  end

  UltrakillBase.SoundScript( "Ultrakill_Prime_Death", self:GetPos() )

  UltrakillBase.SlowMotion( 3 )

end

end


-- DO NOT TOUCH --

AddCSLuaFile()
DrGBase.AddNextbot( ENT )